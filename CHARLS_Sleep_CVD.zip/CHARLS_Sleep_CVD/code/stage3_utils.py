from __future__ import annotations

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
from patsy import dmatrices

import config
from analysis_utils import _patsy_compatible_copy, make_person_period, exponentiated_table
from stage2_utils import FULL_COVARIATES

# Adjustment sets are intentionally labelled by purpose rather than implying
# that a formal causal DAG has already identified a unique sufficient set.
DEMOGRAPHIC_COVARIATES = [
    'age_2015',
    'C(b11_gender_harmonized)',
]

CORE_CONFOUNDER_COVARIATES = [
    'age_2015',
    'C(b11_gender_harmonized)',
    'C(b11_marry_harmonized)',
    'C(b11_rural)',
    'C(b11_edu)',
    'C(b11_smoken)',
    'C(b11_drinkl)',
    'b11_cesd9_derived',
]

EXTENDED_RISK_FACTOR_COVARIATES = FULL_COVARIATES


def ensure_stage3_dirs():
    config.ensure_output_dirs()
    paths = [
        config.OUTPUT_DIR / '06_stage3',
        config.OUTPUT_DIR / '06_stage3' / '11_model_specification',
        config.OUTPUT_DIR / '06_stage3' / '12_multiple_imputation',
        config.OUTPUT_DIR / '06_stage3' / '13_weighting',
        config.OUTPUT_DIR / '06_stage3' / '14_temporal_death',
        config.OUTPUT_DIR / '06_stage3' / '15_summary',
    ]
    for p in paths:
        p.mkdir(parents=True, exist_ok=True)
    return paths


def fit_cloglog_weighted(
    formula: str,
    data: pd.DataFrame,
    weight_col: str,
    cluster_col: str = 'ID',
    cluster_override_col: str | None = None,
):
    """Weighted grouped-time cloglog model via GEE with aligned complete cases.

    Patsy first builds the formula design matrix and determines the exact rows
    retained after missing-value exclusion. We then align weights, offset and
    clusters to those rows before fitting GEE with an independence working
    correlation and robust sandwich covariance.
    """
    model_data = _patsy_compatible_copy(data)
    model_data[weight_col] = pd.to_numeric(model_data[weight_col], errors='coerce')
    cluster_use = cluster_override_col or cluster_col
    base_mask = (model_data[weight_col].notna() & (model_data[weight_col] > 0) &
                 model_data[cluster_use].notna() & model_data['log_interval_years'].notna())
    model_data = model_data.loc[base_mask].copy()

    y, X = dmatrices(formula, model_data, return_type='dataframe', NA_action='drop')
    used = model_data.loc[X.index].copy().reset_index(drop=True)
    y = y.reset_index(drop=True)
    X = X.reset_index(drop=True)
    result = sm.GEE(
        endog=y.iloc[:, 0].to_numpy(), exog=X.to_numpy(), groups=used[cluster_use].to_numpy(),
        family=sm.families.Binomial(link=sm.families.links.CLogLog()),
        cov_struct=sm.cov_struct.Independence(),
        offset=used['log_interval_years'].to_numpy(), weights=used[weight_col].to_numpy(),
    ).fit()
    # Restore formula-design labels for downstream extraction.
    result.params = pd.Series(np.asarray(result.params), index=X.columns)
    cov = pd.DataFrame(np.asarray(result.cov_params()), index=X.columns, columns=X.columns)
    result._stage3_cov = cov
    result._stage3_pvalues = pd.Series(np.asarray(result.pvalues), index=X.columns)
    result._stage3_bse = pd.Series(np.asarray(result.bse), index=X.columns)
    result._used_analysis_data = used
    return result


def normalize_positive_weight(x: pd.Series) -> pd.Series:
    w = pd.to_numeric(x, errors='coerce')
    w = w.where(w > 0)
    return w / w.mean(skipna=True)


def truncate_weight(x: pd.Series, lower_q: float = 0.01, upper_q: float = 0.99):
    w = pd.to_numeric(x, errors='coerce').copy()
    valid = w.dropna()
    if valid.empty:
        return w, np.nan, np.nan
    lo = valid.quantile(lower_q)
    hi = valid.quantile(upper_q)
    return w.clip(lower=lo, upper=hi), float(lo), float(hi)


def rubin_pool(estimates: list[float], variances: list[float], alpha: float = 0.05) -> dict:
    q = np.asarray(estimates, dtype=float)
    u = np.asarray(variances, dtype=float)
    mask = np.isfinite(q) & np.isfinite(u) & (u >= 0)
    q = q[mask]
    u = u[mask]
    m = len(q)
    if m == 0:
        return {'m': 0, 'beta': np.nan, 'se': np.nan, 'df': np.nan,
                'HR': np.nan, 'CI_low': np.nan, 'CI_high': np.nan, 'p_value': np.nan}

    qbar = float(q.mean())
    ubar = float(u.mean())
    b = float(q.var(ddof=1)) if m > 1 else 0.0
    total = ubar + (1.0 + 1.0 / m) * b
    se = math_sqrt(total)

    if b <= 1e-15 or ubar <= 1e-15:
        df = np.inf
        crit = stats.norm.ppf(1 - alpha / 2)
        p = 2 * stats.norm.sf(abs(qbar / se)) if se > 0 else np.nan
    else:
        r = ((1.0 + 1.0 / m) * b) / ubar
        df = (m - 1) * (1.0 + 1.0 / r) ** 2
        crit = stats.t.ppf(1 - alpha / 2, df)
        p = 2 * stats.t.sf(abs(qbar / se), df) if se > 0 else np.nan

    return {
        'm': m,
        'beta': qbar,
        'se': se,
        'within_var': ubar,
        'between_var': b,
        'total_var': total,
        'df': float(df),
        'HR': float(np.exp(qbar)),
        'CI_low': float(np.exp(qbar - crit * se)),
        'CI_high': float(np.exp(qbar + crit * se)),
        'p_value': float(p),
    }


def math_sqrt(x):
    return float(np.sqrt(max(float(x), 0.0)))


def weighted_model_table(result, model_name: str, outcome: str, weight_name: str):
    params = result.params
    cov = result._stage3_cov
    se = np.sqrt(np.diag(cov))
    p = result._stage3_pvalues
    tab = pd.DataFrame({
        'term': params.index, 'beta': params.values, 'HR': np.exp(params.values),
        'CI_low': np.exp(params.values - 1.96 * se),
        'CI_high': np.exp(params.values + 1.96 * se),
        'p_value': p.values,
    })
    tab.insert(0, 'outcome', outcome)
    tab.insert(1, 'model', model_name)
    tab.insert(2, 'weighting', weight_name)
    used = getattr(result, '_used_analysis_data', None)
    if used is not None:
        tab['n_interval_rows'] = int(len(used))
        tab['n_people'] = int(used['ID'].nunique())
        tab['n_events'] = int(used['event'].sum())
    return tab


def fit_weighted_exposure_model(
    cohort: pd.DataFrame,
    outcome: str,
    exposure_term: str,
    covariates: list[str],
    weight_col: str,
    model_name: str,
    cluster_override_col: str | None = None,
):
    pp = make_person_period(cohort, outcome)
    formula = 'event ~ C(interval) + ' + exposure_term
    if covariates:
        formula += ' + ' + ' + '.join(covariates)
    res = fit_cloglog_weighted(
        formula, pp, weight_col=weight_col,
        cluster_override_col=cluster_override_col,
    )
    tab = weighted_model_table(res, model_name, outcome, weight_col)
    tab.insert(3, 'formula', formula)
    return res, tab
