from pathlib import Path
import os

# Project root:
# 1) SLEEP_CVD_PROJECT_ROOT, if explicitly set;
# 2) otherwise the parent directory of this code folder.
PROJECT_ROOT = Path(
    os.environ.get("SLEEP_CVD_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).expanduser().resolve()

CODE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("SLEEP_CVD_DATA_DIR", PROJECT_ROOT / "data")).expanduser().resolve()
OUTPUT_DIR = Path(os.environ.get("SLEEP_CVD_OUTPUT_DIR", PROJECT_ROOT / "output")).expanduser().resolve()

OUT_QC = OUTPUT_DIR / "00_qc"
OUT_COHORT = OUTPUT_DIR / "01_cohort"
OUT_DESC = OUTPUT_DIR / "02_descriptive"
OUT_MODELS = OUTPUT_DIR / "03_models"
OUT_FIG = OUTPUT_DIR / "04_figures"
OUT_SENS = OUTPUT_DIR / "05_sensitivity"

# The analysis was documented against harmonized v0.2.
# Do not silently fall back to v0.1 or choose an arbitrary CSV.
DATA_FILENAME_EXPLICIT = bool(os.environ.get("SLEEP_CVD_DATA_FILENAME", "").strip())
DATA_FILENAME = os.environ.get(
    "SLEEP_CVD_DATA_FILENAME", "charls_sleep_cvd_harmonized_v0.2.csv"
)
DATA_GLOB = os.environ.get(
    "SLEEP_CVD_DATA_GLOB", "charls_sleep_cvd_harmonized_v0.2*.csv"
)
DATA_FILE = os.environ.get("SLEEP_CVD_DATA_FILE", "").strip()

# Study design
AGE_MIN_WAVE1 = 45
EXPOSURE_WAVES = (1, 2, 3)  # 2011, 2013, 2015
LANDMARK_WAVE = 3            # 2015
FOLLOWUP_WAVES = (4, 5)      # 2018, 2020

# Prespecified multidimensional sleep-health thresholds
SHORT_SLEEP_H = 6.0
LONG_SLEEP_H = 8.0
LONG_NAP_MIN = 60.0
RESTLESS_POOR_THRESHOLD = 3.0

# Restricted cubic spline settings
RCS_QUANTILES = (0.05, 0.35, 0.65, 0.95)
RCS_REFERENCE_SLEEP_H = 7.0
RCS_PLOT_QUANTILES = (0.01, 0.99)

RANDOM_SEED = 20260826


def ensure_output_dirs():
    paths = [
        OUTPUT_DIR, OUT_QC, OUT_COHORT, OUT_DESC, OUT_MODELS, OUT_FIG, OUT_SENS,
        OUTPUT_DIR / "06_stage3",
        OUTPUT_DIR / "07_stage4",
        OUTPUT_DIR / "08_targeted_sensitivity",
        OUTPUT_DIR / "09_incremental_value",
    ]
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)
