from __future__ import annotations

import numpy as np
import pandas as pd

import config
from analysis_utils import make_person_period, fit_cloglog, exponentiated_table, lr_test

YEARS = (2011, 2013, 2015)

# Same prespecified full covariate set as stage-1 M3.
FULL_COVARIATES = [
    'age_2015',
    'C(b11_gender_harmonized)',
    'C(b11_marry_harmonized)',
    'C(b11_rural)',
    'C(b11_edu)',
    'C(b11_smoken)',
    'C(b11_drinkl)',
    'b11_srh',
    'b11_adlab_c',
    'b11_iadl',
    'b11_cesd9_derived',
    'b11_bmi_harmonized',
    'C(b11_hibpe_1)',
    'C(b11_diabe_1)',
    'C(b11_dyslipe)',
]

REDUCED_COVARIATES = [
    'age_2015',
    'C(b11_gender_harmonized)',
    'C(b11_marry_harmonized)',
    'C(b11_rural)',
    'C(b11_edu)',
    'C(b11_smoken)',
    'C(b11_drinkl)',
    'b11_srh',
    'b11_cesd9_derived',
]


def read_person_cohort() -> pd.DataFrame:
    path = config.OUT_COHORT / 'analysis_cohort_personlevel.csv'
    if not path.exists():
        raise FileNotFoundError(
            f'{path} not found. Run 01_prepare_analysis_cohort.py first.'
        )
    return pd.read_csv(path, low_memory=False)


def _binary_with_missing(x: pd.Series, condition) -> pd.Series:
    out = pd.Series(np.nan, index=x.index, dtype=float)
    mask = x.notna()
    out.loc[mask] = condition(x.loc[mask]).astype(int)
    return out


def _transition_label(start: pd.Series, end: pd.Series) -> pd.Series:
    out = pd.Series(np.nan, index=start.index, dtype=object)
    valid = start.notna() & end.notna()
    s = start.loc[valid].astype(int)
    e = end.loc[valid].astype(int)
    idx = s.index
    out.loc[idx[(s == 0) & (e == 0)]] = 'persistent unfavorable'
    out.loc[idx[(s == 0) & (e == 1)]] = 'improved'
    out.loc[idx[(s == 1) & (e == 0)]] = 'deteriorated'
    out.loc[idx[(s == 1) & (e == 1)]] = 'persistent favorable'
    return out


def derive_dynamic_sleep_features(
    cohort: pd.DataFrame,
    duration_low: float = 6.0,
    duration_high: float = 8.0,
    nap_max: float = 60.0,
    restless_max: float = 2.0,
    suffix: str = '',
) -> pd.DataFrame:
    """
    Construct CHARLS-derived multidimensional sleep-health features.

    Low-risk components at each wave:
      1) nighttime sleep duration in [duration_low, duration_high]
      2) midday nap <= nap_max minutes/day
      3) restless-sleep frequency <= restless_max (harmonized 1-4 scale)

    The score is not presented as a validated universal sleep-health instrument;
    it is a study-specific composite based on the three harmonized CHARLS domains.
    """
    d = cohort.copy()
    tag = f'_{suffix}' if suffix else ''

    for y in YEARS:
        ns = pd.to_numeric(d[f'night_sleep_{y}'], errors='coerce')
        nap = pd.to_numeric(d[f'nap_{y}'], errors='coerce')
        rest = pd.to_numeric(d[f'restless_sleep_{y}'], errors='coerce')

        d[f'healthy_duration_{y}{tag}'] = _binary_with_missing(
            ns, lambda z: z.between(duration_low, duration_high, inclusive='both')
        )
        d[f'healthy_nap_{y}{tag}'] = _binary_with_missing(
            nap, lambda z: z <= nap_max
        )
        d[f'healthy_restless_{y}{tag}'] = _binary_with_missing(
            rest, lambda z: z <= restless_max
        )

        comps = [
            f'healthy_duration_{y}{tag}',
            f'healthy_nap_{y}{tag}',
            f'healthy_restless_{y}{tag}',
        ]
        complete = d[comps].notna().all(axis=1)
        score = d[comps].sum(axis=1, min_count=3)
        d[f'mdsh_score_{y}{tag}'] = score
        d[f'mdsh_complete_{y}{tag}'] = complete.astype(int)

        # Strict favorable = all 3 observed components are low risk.
        strict = pd.Series(np.nan, index=d.index, dtype=float)
        strict.loc[complete] = (score.loc[complete] == 3).astype(int)
        d[f'mdsh_favorable_strict_{y}{tag}'] = strict

        # Lenient definition is retained as a sensitivity analysis only.
        lenient = pd.Series(np.nan, index=d.index, dtype=float)
        lenient.loc[complete] = (score.loc[complete] >= 2).astype(int)
        d[f'mdsh_favorable_lenient_{y}{tag}'] = lenient

    score_cols = [f'mdsh_score_{y}{tag}' for y in YEARS]
    strict_cols = [f'mdsh_favorable_strict_{y}{tag}' for y in YEARS]
    lenient_cols = [f'mdsh_favorable_lenient_{y}{tag}' for y in YEARS]

    d[f'mdsh_complete_all3{tag}'] = d[score_cols].notna().all(axis=1).astype(int)
    d[f'mdsh_cumulative_total{tag}'] = d[score_cols].sum(axis=1, min_count=3)
    d[f'mdsh_cumulative_mean{tag}'] = d[score_cols].mean(axis=1)
    d.loc[d[f'mdsh_complete_all3{tag}'] != 1, f'mdsh_cumulative_mean{tag}'] = np.nan
    d[f'mdsh_n_favorable_strict_waves{tag}'] = d[strict_cols].sum(axis=1, min_count=3)
    d[f'mdsh_n_favorable_lenient_waves{tag}'] = d[lenient_cols].sum(axis=1, min_count=3)

    d[f'mdsh_delta_2015_2011{tag}'] = (
        d[f'mdsh_score_2015{tag}'] - d[f'mdsh_score_2011{tag}']
    )
    d[f'mdsh_transition_strict{tag}'] = _transition_label(
        d[f'mdsh_favorable_strict_2011{tag}'],
        d[f'mdsh_favorable_strict_2015{tag}'],
    )
    d[f'mdsh_transition_lenient{tag}'] = _transition_label(
        d[f'mdsh_favorable_lenient_2011{tag}'],
        d[f'mdsh_favorable_lenient_2015{tag}'],
    )

    # Dimension-specific persistence counts. Require all 3 waves for that dimension.
    ns_cols = [f'night_sleep_{y}' for y in YEARS]
    nap_cols = [f'nap_{y}' for y in YEARS]
    rest_cols = [f'restless_sleep_{y}' for y in YEARS]

    def count_condition(cols, cond, name):
        complete = d[cols].notna().all(axis=1)
        arr = pd.concat([cond(pd.to_numeric(d[c], errors='coerce')).astype(float) for c in cols], axis=1)
        count = arr.sum(axis=1)
        count = count.where(complete)
        d[f'{name}{tag}'] = count
        persistent = pd.Series(np.nan, index=d.index, dtype=float)
        persistent.loc[complete] = (count.loc[complete] >= 2).astype(int)
        d[f'persistent_{name.replace("n_", "")}{tag}'] = persistent

    count_condition(ns_cols, lambda z: z < duration_low, 'n_short_sleep_waves')
    count_condition(ns_cols, lambda z: z > duration_high, 'n_long_sleep_waves')
    count_condition(rest_cols, lambda z: z > restless_max, 'n_poor_restless_waves')
    count_condition(nap_cols, lambda z: z > nap_max, 'n_long_nap_waves')

    return d


def person_event_table(d: pd.DataFrame, exposure: str, outcome: str = 'cvd') -> pd.DataFrame:
    outcol = f'incident_{outcome}'
    x = d[[exposure, outcol]].dropna().copy()
    tab = (
        x.groupby(exposure, dropna=False)[outcol]
        .agg(['count', 'sum', 'mean'])
        .reset_index()
        .rename(columns={'sum': 'events', 'mean': 'event_fraction'})
    )
    tab['event_percent'] = tab['event_fraction'] * 100
    tab.insert(0, 'outcome', outcome)
    return tab


def fit_exposure_model(
    cohort: pd.DataFrame,
    outcome: str,
    exposure_term: str,
    model_name: str,
    covariates=None,
    robust: bool = True,
):
    if covariates is None:
        covariates = FULL_COVARIATES
    pp = make_person_period(cohort, outcome)
    formula = 'event ~ C(interval) + ' + exposure_term + ' + ' + ' + '.join(covariates)
    res = fit_cloglog(formula, pp, robust=robust)
    tab = exponentiated_table(res, model_name, outcome)
    tab.insert(2, 'formula', formula)
    return res, tab


def extract_term_rows(tab: pd.DataFrame, contains: str, exposure_label: str) -> pd.DataFrame:
    hit = tab[tab['term'].astype(str).str.contains(contains, regex=False)].copy()
    if not hit.empty:
        hit.insert(2, 'exposure_analysis', exposure_label)
    return hit


def category_formula(var: str, reference) -> str:
    if isinstance(reference, str):
        return f'C({var}, Treatment(reference="{reference}"))'
    return f'C({var}, Treatment(reference={reference}))'


def fit_lr_interaction(
    pp: pd.DataFrame,
    reduced_formula: str,
    full_formula: str,
) -> dict:
    reduced = fit_cloglog(reduced_formula, pp, robust=False)
    full = fit_cloglog(full_formula, pp, robust=False)
    return lr_test(reduced, full)
