from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))

import pandas as pd
import numpy as np

import config
from analysis_utils import (
    read_harmonized,
    build_person_level_cohort,
    make_person_period,
    validate_cesd9_reconstruction,
    save_json,
)


def main():
    config.ensure_output_dirs()
    df, source_path = read_harmonized()

    # Core dataset QC
    qc = {
        'source_file': str(source_path),
        'rows': int(len(df)),
        'columns': int(df.shape[1]),
        'unique_ID': int(df['ID'].nunique()),
        'duplicate_ID_wave': int(df.duplicated(['ID', 'wave']).sum()),
        'wave_counts': {str(k): int(v) for k, v in df['wave'].value_counts().sort_index().items()},
        'cesd9_reconstruction_validation_wave5': validate_cesd9_reconstruction(df),
    }
    save_json(qc, config.OUT_QC / 'dataset_qc.json')

    cohort, flow = build_person_level_cohort(df)

    # Add outcome-specific complete flags.
    for outcome in ['cvd', 'heart', 'stroke']:
        cohort[f'{outcome}_outcome_observed'] = cohort[f'incident_{outcome}'].notna().astype(int)

    cohort.to_csv(config.OUT_COHORT / 'analysis_cohort_personlevel.csv', index=False, encoding='utf-8-sig')
    flow.to_csv(config.OUT_COHORT / 'refined_sample_flow.csv', index=False, encoding='utf-8-sig')

    # Exposure summaries used to decide/freeze later cut points.
    exposure_vars = [
        'exp_mean_night_sleep', 'exp_sd_night_sleep', 'exp_cv_night_sleep',
        'exp_arv_night_sleep', 'exp_mean_nap_minutes', 'exp_mean_restless_sleep',
        'night_sleep_2011', 'night_sleep_2013', 'night_sleep_2015',
        'nap_2011', 'nap_2013', 'nap_2015',
        'restless_sleep_2011', 'restless_sleep_2013', 'restless_sleep_2015',
    ]
    exposure_vars = [v for v in exposure_vars if v in cohort.columns]
    q = [0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99]
    desc = cohort[exposure_vars].describe(percentiles=q).T
    desc.to_csv(config.OUT_DESC / 'sleep_exposure_distribution.csv', encoding='utf-8-sig')

    # Baseline missingness after all primary cohort restrictions.
    baseline_cols = [c for c in cohort.columns if c.startswith('b11_')]
    missing = pd.DataFrame({
        'variable': baseline_cols,
        'missing_n': [int(cohort[c].isna().sum()) for c in baseline_cols],
        'missing_pct': [float(cohort[c].isna().mean() * 100) for c in baseline_cols],
    }).sort_values(['missing_pct', 'variable'], ascending=[False, True])
    missing.to_csv(config.OUT_QC / 'baseline_missingness_primary_cohort.csv', index=False, encoding='utf-8-sig')

    # Event summary.
    rows = []
    for outcome in ['cvd', 'heart', 'stroke']:
        s = cohort[f'incident_{outcome}']
        rows.append({
            'outcome': outcome,
            'n_people_total': len(cohort),
            'n_outcome_observed': int(s.notna().sum()),
            'n_events': int((s == 1).sum()),
            'event_percent_among_observed': float((s == 1).sum() / s.notna().sum() * 100),
        })
    pd.DataFrame(rows).to_csv(config.OUT_DESC / 'event_summary.csv', index=False, encoding='utf-8-sig')

    # Person-period datasets.
    for outcome in ['cvd', 'heart', 'stroke']:
        pp = make_person_period(cohort, outcome)
        pp.to_csv(config.OUT_COHORT / f'person_period_{outcome}.csv', index=False, encoding='utf-8-sig')

    print('Finished 01_prepare_analysis_cohort.py')
    print(f'Source: {source_path}')
    print(f'Primary cohort N = {len(cohort):,}')
    print(flow.to_string(index=False))


if __name__ == '__main__':
    main()
