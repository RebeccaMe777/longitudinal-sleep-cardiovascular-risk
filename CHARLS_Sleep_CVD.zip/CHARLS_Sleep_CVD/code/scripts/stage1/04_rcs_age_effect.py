from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from patsy import build_design_matrices

import config
from analysis_utils import fit_cloglog, lr_test


ADJ_TERMS = [
    'C(interval)',
    'age_2015',
    'C(b11_gender_harmonized)',
    'C(b11_marry_harmonized)',
    'C(b11_rural)',
    'C(b11_edu)',
    'C(b11_smoken)',
    'C(b11_drinkl)',
    'b11_srh',
    'b11_adlab_c',
    'b11_iadl',
    'b11_cesd9_derived',
    'b11_bmi_harmonized',
    'C(b11_hibpe_1)',
    'C(b11_diabe_1)',
    'C(b11_dyslipe)',
]


def typical_row(d: pd.DataFrame) -> dict:
    row = {}
    continuous = ['age_2015', 'b11_srh', 'b11_adlab_c', 'b11_iadl', 'b11_cesd9_derived', 'b11_bmi_harmonized']
    categorical = ['interval', 'b11_gender_harmonized', 'b11_marry_harmonized', 'b11_rural', 'b11_edu', 'b11_smoken', 'b11_drinkl', 'b11_hibpe_1', 'b11_diabe_1', 'b11_dyslipe']
    for c in continuous:
        row[c] = float(pd.to_numeric(d[c], errors='coerce').median())
    for c in categorical:
        row[c] = d[c].dropna().mode().iloc[0]
    return row


def contrast_hr(result, new_rows: pd.DataFrame, ref_rows: pd.DataFrame):
    design_info = result.model.data.design_info
    X_new = np.asarray(build_design_matrices([design_info], new_rows, return_type='dataframe')[0])
    X_ref = np.asarray(build_design_matrices([design_info], ref_rows, return_type='dataframe')[0])
    delta = X_new - X_ref
    beta = np.asarray(result.params)
    cov = np.asarray(result.cov_params())
    log_hr = delta @ beta
    var = np.einsum('ij,jk,ik->i', delta, cov, delta)
    se = np.sqrt(np.clip(var, 0, None))
    return pd.DataFrame({
        'HR': np.exp(log_hr),
        'CI_low': np.exp(log_hr - 1.96 * se),
        'CI_high': np.exp(log_hr + 1.96 * se),
    })


def main():
    config.ensure_output_dirs()
    pp = pd.read_csv(config.OUT_COHORT / 'person_period_cvd.csv', low_memory=False)
    x = pd.to_numeric(pp['exp_mean_night_sleep'], errors='coerce').dropna()
    q05, q35, q65, q95 = x.quantile(config.RCS_QUANTILES).tolist()
    q01, q99 = x.quantile(config.RCS_PLOT_QUANTILES).tolist()

    spline = (
        f'cr(exp_mean_night_sleep, knots=({q35:.10g},{q65:.10g}), '
        f"lower_bound={q05:.10g}, upper_bound={q95:.10g}, constraints='center')"
    )
    common = ' + '.join(ADJ_TERMS)
    f_linear = f'event ~ exp_mean_night_sleep + {common}'
    f_spline = f'event ~ {spline} + {common}'

    # Robust model for CIs; conventional fits for LR nonlinearity test.
    robust_spline = fit_cloglog(f_spline, pp, robust=True)
    linear_nr = fit_cloglog(f_linear, pp, robust=False)
    spline_nr = fit_cloglog(f_spline, pp, robust=False)
    nonlinear_test = lr_test(linear_nr, spline_nr)

    test = pd.DataFrame([{
        'analysis': 'RCS mean nighttime sleep -> incident CVD',
        'knots_percentiles': str(config.RCS_QUANTILES),
        'knots_values_hours': f'{q05:.3f}, {q35:.3f}, {q65:.3f}, {q95:.3f}',
        'reference_hours': config.RCS_REFERENCE_SLEEP_H,
        'LR_nonlinearity': nonlinear_test['LR'],
        'df_difference': nonlinear_test['df'],
        'p_nonlinearity': nonlinear_test['p_value'],
        'n_interval_rows': int(robust_spline.nobs),
    }])
    test.to_csv(config.OUT_MODELS / 'rcs_sleep_cvd_nonlinearity_test.csv', index=False, encoding='utf-8-sig')

    base = typical_row(pp)
    grid_sleep = np.linspace(max(q01, 2.0), min(q99, 12.0), 180)
    new = pd.DataFrame([{**base, 'exp_mean_night_sleep': s} for s in grid_sleep])
    ref = pd.DataFrame([{**base, 'exp_mean_night_sleep': config.RCS_REFERENCE_SLEEP_H} for _ in grid_sleep])
    pred = contrast_hr(robust_spline, new, ref)
    pred.insert(0, 'sleep_hours', grid_sleep)
    pred.to_csv(config.OUT_MODELS / 'rcs_sleep_cvd_curve.csv', index=False, encoding='utf-8-sig')

    fig, ax = plt.subplots(figsize=(6.4, 4.6))
    ax.plot(pred['sleep_hours'], pred['HR'], linewidth=2)
    ax.fill_between(pred['sleep_hours'], pred['CI_low'], pred['CI_high'], alpha=0.18)
    ax.axhline(1.0, linewidth=1)
    ax.axvline(config.RCS_REFERENCE_SLEEP_H, linewidth=1, linestyle='--')
    ax.set_xlabel('Mean nighttime sleep, h/night (2011-2015)')
    ax.set_ylabel('Hazard ratio for incident CVD')
    ax.set_title('Restricted cubic spline: mean nighttime sleep and incident CVD')
    ax.spines[['top', 'right']].set_visible(False)
    fig.tight_layout()
    fig.savefig(config.OUT_FIG / 'Fig_RCS_mean_night_sleep_CVD.png', dpi=600, bbox_inches='tight')
    fig.savefig(config.OUT_FIG / 'Fig_RCS_mean_night_sleep_CVD.pdf', bbox_inches='tight')
    plt.close(fig)

    # ------------------------------------------------------------------
    # Age-varying analysis: parsimonious continuous interaction.
    # We intentionally start with spline(sleep) x linear age rather than a full
    # spline-by-spline tensor interaction. With ~1,500 CVD events this is more
    # stable, easier to interpret, and avoids manufacturing complex age patterns.
    # A full RCS(age) x RCS(sleep) surface can be added later only if justified.
    # ------------------------------------------------------------------
    pp = pp.copy()
    pp['age_c60'] = pp['age_2015'] - 60.0
    other_adj = [x for x in ADJ_TERMS if x != 'age_2015']
    other = ' + '.join(other_adj)
    f_add = f'event ~ {spline} + age_c60 + {other}'
    f_int = f'event ~ {spline} * age_c60 + {other}'

    int_robust = fit_cloglog(f_int, pp, robust=True)
    add_nr = fit_cloglog(f_add, pp, robust=False)
    int_nr = fit_cloglog(f_int, pp, robust=False)
    interaction_test = lr_test(add_nr, int_nr)
    pd.DataFrame([{
        'analysis': 'RCS sleep x continuous age interaction -> incident CVD',
        'LR_interaction': interaction_test['LR'],
        'df_difference': interaction_test['df'],
        'p_interaction': interaction_test['p_value'],
        'sleep_knots_hours': f'{q05:.3f}, {q35:.3f}, {q65:.3f}, {q95:.3f}',
        'age_center_years': 60,
        'n_interval_rows': int(int_robust.nobs),
    }]).to_csv(config.OUT_MODELS / 'age_varying_sleep_interaction_test.csv', index=False, encoding='utf-8-sig')

    age = pd.to_numeric(pp['age_2015'], errors='coerce').dropna()
    a01, a99 = age.quantile(config.RCS_PLOT_QUANTILES).tolist()

    # Curves at representative ages, if inside the analytic support.
    requested_ages = [50, 60, 70, 80]
    rep_ages = [a for a in requested_ages if a01 <= a <= a99]
    curve_rows = []
    for a in rep_ages:
        new = pd.DataFrame([{**base, 'age_2015': a, 'age_c60': a - 60.0, 'exp_mean_night_sleep': s} for s in grid_sleep])
        ref = pd.DataFrame([{**base, 'age_2015': a, 'age_c60': a - 60.0, 'exp_mean_night_sleep': config.RCS_REFERENCE_SLEEP_H} for _ in grid_sleep])
        p = contrast_hr(int_robust, new, ref)
        p.insert(0, 'age', a)
        p.insert(1, 'sleep_hours', grid_sleep)
        curve_rows.append(p)
    curves = pd.concat(curve_rows, ignore_index=True)
    curves.to_csv(config.OUT_MODELS / 'age_specific_sleep_CVD_curves.csv', index=False, encoding='utf-8-sig')

    fig, ax = plt.subplots(figsize=(6.7, 4.8))
    for a, g in curves.groupby('age'):
        ax.plot(g['sleep_hours'], g['HR'], linewidth=2, label=f'Age {int(a)}')
    ax.axhline(1.0, linewidth=1)
    ax.axvline(config.RCS_REFERENCE_SLEEP_H, linewidth=1, linestyle='--')
    ax.set_xlabel('Mean nighttime sleep, h/night (2011-2015)')
    ax.set_ylabel('Hazard ratio for incident CVD')
    ax.set_title('Age-varying sleep-CVD association')
    ax.legend(frameon=False)
    ax.spines[['top', 'right']].set_visible(False)
    fig.tight_layout()
    fig.savefig(config.OUT_FIG / 'Fig_age_specific_sleep_CVD_curves.png', dpi=600, bbox_inches='tight')
    fig.savefig(config.OUT_FIG / 'Fig_age_specific_sleep_CVD_curves.pdf', bbox_inches='tight')
    plt.close(fig)

    # 2D relative-HR surface from the parsimonious continuous-age interaction.
    # Each age is referenced to 7 h/night at the same age.
    age_grid = np.linspace(max(a01, 45), min(a99, 90), 90)
    sleep_grid = np.linspace(max(q01, 2.0), min(q99, 12.0), 110)
    pairs = [(a, s) for a in age_grid for s in sleep_grid]
    new = pd.DataFrame([{**base, 'age_2015': a, 'age_c60': a - 60.0, 'exp_mean_night_sleep': s} for a, s in pairs])
    ref = pd.DataFrame([{**base, 'age_2015': a, 'age_c60': a - 60.0, 'exp_mean_night_sleep': config.RCS_REFERENCE_SLEEP_H} for a, s in pairs])
    surf = contrast_hr(int_robust, new, ref)
    surf.insert(0, 'age', [a for a, s in pairs])
    surf.insert(1, 'sleep_hours', [s for a, s in pairs])
    surf.to_csv(config.OUT_MODELS / 'age_sleep_relative_HR_surface.csv', index=False, encoding='utf-8-sig')

    z = surf['HR'].to_numpy().reshape(len(age_grid), len(sleep_grid))
    fig, ax = plt.subplots(figsize=(7.0, 5.0))
    mesh = ax.pcolormesh(sleep_grid, age_grid, z, shading='auto')
    cb = fig.colorbar(mesh, ax=ax)
    cb.set_label('Relative HR vs 7 h at the same age')
    ax.set_xlabel('Mean nighttime sleep, h/night (2011-2015)')
    ax.set_ylabel('Age at 2015 landmark, y')
    ax.set_title('Age × sleep relative-hazard surface for incident CVD')
    fig.tight_layout()
    fig.savefig(config.OUT_FIG / 'Fig_age_sleep_CVD_surface.png', dpi=600, bbox_inches='tight')
    fig.savefig(config.OUT_FIG / 'Fig_age_sleep_CVD_surface.pdf', bbox_inches='tight')
    plt.close(fig)

    print('Finished 04_rcs_age_effect.py')
    print(test.to_string(index=False))
    print('Interaction test:', interaction_test)


if __name__ == '__main__':
    main()
