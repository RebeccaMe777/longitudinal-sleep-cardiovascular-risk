from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd

import config
from analysis_utils import fit_cloglog, exponentiated_table


COVARIATES = [
    'age_2015',
    'C(b11_gender_harmonized)',
    'C(b11_marry_harmonized)',
    'C(b11_rural)',
    'C(b11_edu)',
    'C(b11_smoken)',
    'C(b11_drinkl)',
    'b11_srh',
    'b11_adlab_c',
    'b11_iadl',
    'b11_cesd9_derived',
    'b11_bmi_harmonized',
    'C(b11_hibpe_1)',
    'C(b11_diabe_1)',
    'C(b11_dyslipe)',
]


def main():
    config.ensure_output_dirs()
    pp = pd.read_csv(config.OUT_COHORT / 'person_period_cvd.csv', low_memory=False)

    # Quartiles of long-term ARV are data-derived and explicitly reported.
    # We do not label these as a clinical 'regularity' threshold.
    q = pp.drop_duplicates('ID')['exp_arv_night_sleep'].quantile([0.25, 0.50, 0.75]).tolist()
    q1, q2, q3 = q
    pp['arv_quartile'] = pd.cut(
        pp['exp_arv_night_sleep'],
        bins=[-np.inf, q1, q2, q3, np.inf],
        labels=['Q1 lowest variability', 'Q2', 'Q3', 'Q4 highest variability'],
        include_lowest=True,
    )

    # Candidate mean-sleep categories are kept explicitly exploratory/configurable.
    xmean = pp['exp_mean_night_sleep']
    pp['mean_sleep_cat_candidate'] = np.select(
        [
            xmean < config.SHORT_SLEEP_H,
            (xmean >= config.SHORT_SLEEP_H) & (xmean <= config.LONG_SLEEP_H),
            xmean > config.LONG_SLEEP_H,
        ],
        [
            f'<{config.SHORT_SLEEP_H:g} h',
            f'{config.SHORT_SLEEP_H:g}-{config.LONG_SLEEP_H:g} h',
            f'>{config.LONG_SLEEP_H:g} h',
        ],
        default=None,
    )
    # Keep formula-facing categorical variables as ordinary object dtype.
    # pandas StringDtype (string[python]) is not reliably supported by patsy.
    pp['mean_sleep_cat_candidate'] = pd.Series(
        pp['mean_sleep_cat_candidate'], index=pp.index, dtype=object
    ).where(pd.notna(pp['mean_sleep_cat_candidate']), np.nan)
    pp['arv_quartile'] = pp['arv_quartile'].astype(object)
    pp['joint_mean_ARV'] = np.where(
        pp['mean_sleep_cat_candidate'].notna() & pp['arv_quartile'].notna(),
        pp['mean_sleep_cat_candidate'].astype(str) + ' | ' + pp['arv_quartile'].astype(str),
        np.nan,
    )

    # Descriptive event rates at person level.
    people = pp.sort_values('interval_end_wave').drop_duplicates('ID', keep='last')
    # Recover person-level event from incident_cvd, not last interval event.
    tab = (
        people.groupby('joint_mean_ARV', dropna=False)['incident_cvd']
        .agg(['count', 'sum', 'mean'])
        .reset_index()
        .rename(columns={'sum': 'events', 'mean': 'event_fraction'})
    )
    tab['event_percent'] = tab['event_fraction'] * 100
    tab['ARV_quartile_cutpoints_hours'] = f'{q1:.4f}, {q2:.4f}, {q3:.4f}'
    tab.to_csv(config.OUT_DESC / 'joint_mean_sleep_ARV_event_rates.csv', index=False, encoding='utf-8-sig')

    # Adjusted joint analysis. Explicit reference = candidate 6-8 h + lowest ARV quartile.
    ref = f'{config.SHORT_SLEEP_H:g}-{config.LONG_SLEEP_H:g} h | Q1 lowest variability'
    formula = (
        f'event ~ C(interval) + C(joint_mean_ARV, Treatment(reference="{ref}")) + '
        + ' + '.join(COVARIATES)
    )
    try:
        res = fit_cloglog(formula, pp, robust=True)
        out = exponentiated_table(res, 'joint_mean_sleep_ARV', 'cvd')
        out.insert(2, 'formula', formula)
        out.to_csv(config.OUT_MODELS / 'joint_mean_sleep_ARV_model.csv', index=False, encoding='utf-8-sig')
    except Exception as e:
        pd.DataFrame([{'error': repr(e), 'formula': formula}]).to_csv(
            config.OUT_MODELS / 'joint_mean_sleep_ARV_model_ERROR.csv', index=False, encoding='utf-8-sig'
        )
        raise

    print('Finished 05_variability_joint_analysis.py')
    print(f'ARV quartile cutpoints: {q1:.3f}, {q2:.3f}, {q3:.3f} h')


if __name__ == '__main__':
    main()
