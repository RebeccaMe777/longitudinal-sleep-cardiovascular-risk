from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import pandas as pd

import config
from analysis_utils import fit_cloglog, exponentiated_table


# Covariates measured at the beginning of the exposure window (2011),
# with age represented at the 2015 landmark for clinical interpretability.
MODEL_TERMS = {
    'M1_demographic': [
        'age_2015',
        'C(b11_gender_harmonized)',
    ],
    'M2_sociobehavioral': [
        'age_2015',
        'C(b11_gender_harmonized)',
        'C(b11_marry_harmonized)',
        'C(b11_rural)',
        'C(b11_edu)',
        'C(b11_smoken)',
        'C(b11_drinkl)',
        'b11_srh',
        'b11_adlab_c',
        'b11_iadl',
        'b11_cesd9_derived',
    ],
    'M3_cardiometabolic': [
        'age_2015',
        'C(b11_gender_harmonized)',
        'C(b11_marry_harmonized)',
        'C(b11_rural)',
        'C(b11_edu)',
        'C(b11_smoken)',
        'C(b11_drinkl)',
        'b11_srh',
        'b11_adlab_c',
        'b11_iadl',
        'b11_cesd9_derived',
        'b11_bmi_harmonized',
        'C(b11_hibpe_1)',
        'C(b11_diabe_1)',
        'C(b11_dyslipe)',
    ],
}

# Each variable is analyzed separately first; a combined sleep-dimension model follows.
EXPOSURES = {
    'mean_night_sleep_per_1h': 'exp_mean_night_sleep',
    'sleep_ARV_per_1h': 'exp_arv_night_sleep',
    'mean_nap_per_30min': 'mean_nap_30min',
    'mean_restless_sleep_per_1level': 'exp_mean_restless_sleep',
}


def run_one(pp: pd.DataFrame, outcome: str, exposure_label: str, exposure_term: str, model_name: str, covariates):
    formula = 'event ~ C(interval) + ' + exposure_term + ' + ' + ' + '.join(covariates)
    result = fit_cloglog(formula, pp, robust=True)
    tab = exponentiated_table(result, model_name, outcome)
    tab.insert(2, 'exposure_analysis', exposure_label)
    tab.insert(3, 'formula', formula)
    return tab


def main():
    config.ensure_output_dirs()
    all_tabs = []
    summary_rows = []

    for outcome in ['cvd', 'heart', 'stroke']:
        pp_path = config.OUT_COHORT / f'person_period_{outcome}.csv'
        pp = pd.read_csv(pp_path, low_memory=False)

        for exposure_label, exposure_term in EXPOSURES.items():
            for model_name, covariates in MODEL_TERMS.items():
                try:
                    tab = run_one(pp, outcome, exposure_label, exposure_term, model_name, covariates)
                    all_tabs.append(tab)
                    hit = tab[tab['term'] == exposure_term]
                    if not hit.empty:
                        r = hit.iloc[0]
                        summary_rows.append({
                            'outcome': outcome,
                            'exposure': exposure_label,
                            'model': model_name,
                            'HR': r['HR'],
                            'CI_low': r['CI_low'],
                            'CI_high': r['CI_high'],
                            'p_value': r['p_value'],
                            'n_people': r['n_people'],
                            'n_events': r['n_events'],
                            'n_interval_rows': r['n_interval_rows'],
                        })
                except Exception as e:
                    summary_rows.append({
                        'outcome': outcome,
                        'exposure': exposure_label,
                        'model': model_name,
                        'error': repr(e),
                    })

        # Combined model: estimates mutually adjusted associations of the measured dimensions.
        combined_terms = list(EXPOSURES.values())
        covariates = MODEL_TERMS['M3_cardiometabolic']
        formula = 'event ~ C(interval) + ' + ' + '.join(combined_terms + covariates)
        try:
            result = fit_cloglog(formula, pp, robust=True)
            tab = exponentiated_table(result, 'M4_combined_sleep_dimensions', outcome)
            tab.insert(2, 'exposure_analysis', 'combined_sleep_dimensions')
            tab.insert(3, 'formula', formula)
            all_tabs.append(tab)
            for exposure_label, exposure_term in EXPOSURES.items():
                hit = tab[tab['term'] == exposure_term]
                if not hit.empty:
                    r = hit.iloc[0]
                    summary_rows.append({
                        'outcome': outcome,
                        'exposure': exposure_label,
                        'model': 'M4_combined_sleep_dimensions',
                        'HR': r['HR'],
                        'CI_low': r['CI_low'],
                        'CI_high': r['CI_high'],
                        'p_value': r['p_value'],
                        'n_people': r['n_people'],
                        'n_events': r['n_events'],
                        'n_interval_rows': r['n_interval_rows'],
                    })
        except Exception as e:
            summary_rows.append({
                'outcome': outcome,
                'exposure': 'combined_sleep_dimensions',
                'model': 'M4_combined_sleep_dimensions',
                'error': repr(e),
            })

    if all_tabs:
        pd.concat(all_tabs, ignore_index=True).to_csv(
            config.OUT_MODELS / 'primary_cloglog_all_coefficients.csv',
            index=False,
            encoding='utf-8-sig',
        )
    pd.DataFrame(summary_rows).to_csv(
        config.OUT_MODELS / 'primary_cloglog_exposure_summary.csv',
        index=False,
        encoding='utf-8-sig',
    )

    print('Finished 03_primary_models.py')
    print(pd.DataFrame(summary_rows).head(20).to_string(index=False))


if __name__ == '__main__':
    main()
