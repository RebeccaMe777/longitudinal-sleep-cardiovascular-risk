from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd

import config


def fmt_mean_sd(s):
    x = pd.to_numeric(s, errors='coerce').dropna()
    if len(x) == 0:
        return 'NA'
    return f'{x.mean():.2f} ({x.std(ddof=1):.2f})'


def fmt_median_iqr(s):
    x = pd.to_numeric(s, errors='coerce').dropna()
    if len(x) == 0:
        return 'NA'
    q1, med, q3 = x.quantile([0.25, 0.50, 0.75])
    return f'{med:.2f} [{q1:.2f}, {q3:.2f}]'


def smd_cont(a, b):
    a = pd.to_numeric(a, errors='coerce').dropna()
    b = pd.to_numeric(b, errors='coerce').dropna()
    if len(a) < 2 or len(b) < 2:
        return np.nan
    pooled = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2)
    if pooled == 0:
        return 0.0
    return (a.mean() - b.mean()) / pooled


def smd_binary(a, b):
    a = pd.to_numeric(a, errors='coerce').dropna()
    b = pd.to_numeric(b, errors='coerce').dropna()
    if len(a) == 0 or len(b) == 0:
        return np.nan
    p1, p0 = a.mean(), b.mean()
    denom = np.sqrt((p1 * (1 - p1) + p0 * (1 - p0)) / 2)
    if denom == 0:
        return 0.0
    return (p1 - p0) / denom


def n_pct(s, value=1):
    x = s.dropna()
    if len(x) == 0:
        return 'NA'
    n = int((x == value).sum())
    return f'{n} ({100*n/len(x):.1f}%)'


def main():
    config.ensure_output_dirs()
    path = config.OUT_COHORT / 'analysis_cohort_personlevel.csv'
    d = pd.read_csv(path, low_memory=False)
    d = d[d['incident_cvd'].notna()].copy()
    no = d[d['incident_cvd'] == 0]
    yes = d[d['incident_cvd'] == 1]

    continuous_mean = {
        'Age at 2015 landmark, y': 'age_2015',
        'Mean nighttime sleep 2011-2015, h': 'exp_mean_night_sleep',
        'Long-term sleep ARV, h': 'exp_arv_night_sleep',
        'Mean nap duration, min': 'exp_mean_nap_minutes',
        'Mean restless-sleep frequency': 'exp_mean_restless_sleep',
        'BMI at 2011, kg/m2': 'b11_bmi_harmonized',
        'CESD-9 without sleep item at 2011': 'b11_cesd9_derived',
        'ADL limitations at 2011': 'b11_adlab_c',
        'IADL limitations at 2011': 'b11_iadl',
    }
    continuous_median = {
        'Household per-capita consumption at 2011': 'b11_hhcperc',
    }
    binary = {
        'Male': 'b11_gender_harmonized',
        'Married': 'b11_marry_harmonized',
        'Rural residence': 'b11_rural',
        'Current smoking': 'b11_smoken',
        'Current drinking': 'b11_drinkl',
        'Hypertension at 2011': 'b11_hibpe_1',
        'Diabetes at 2011': 'b11_diabe_1',
        'Dyslipidemia at 2011': 'b11_dyslipe',
    }

    rows = []
    for label, var in continuous_mean.items():
        if var not in d.columns:
            continue
        rows.append({
            'variable': label,
            'level': '',
            'overall': fmt_mean_sd(d[var]),
            'no_incident_cvd': fmt_mean_sd(no[var]),
            'incident_cvd': fmt_mean_sd(yes[var]),
            'SMD': smd_cont(yes[var], no[var]),
            'missing_n': int(d[var].isna().sum()),
        })
    for label, var in continuous_median.items():
        if var not in d.columns:
            continue
        rows.append({
            'variable': label,
            'level': '',
            'overall': fmt_median_iqr(d[var]),
            'no_incident_cvd': fmt_median_iqr(no[var]),
            'incident_cvd': fmt_median_iqr(yes[var]),
            'SMD': smd_cont(yes[var], no[var]),
            'missing_n': int(d[var].isna().sum()),
        })
    for label, var in binary.items():
        if var not in d.columns:
            continue
        rows.append({
            'variable': label,
            'level': 'Yes',
            'overall': n_pct(d[var], 1),
            'no_incident_cvd': n_pct(no[var], 1),
            'incident_cvd': n_pct(yes[var], 1),
            'SMD': smd_binary(yes[var], no[var]),
            'missing_n': int(d[var].isna().sum()),
        })

    # Education: show each category as a binary indicator for transparent SMDs.
    edu_labels = {1: 'Below primary', 2: 'Primary', 3: 'Middle school', 4: 'High school+'}
    if 'b11_edu' in d.columns:
        for value, lev in edu_labels.items():
            a = (yes['b11_edu'] == value).astype(float)
            b = (no['b11_edu'] == value).astype(float)
            rows.append({
                'variable': 'Education at 2011',
                'level': lev,
                'overall': n_pct(d['b11_edu'], value),
                'no_incident_cvd': n_pct(no['b11_edu'], value),
                'incident_cvd': n_pct(yes['b11_edu'], value),
                'SMD': smd_binary(a, b),
                'missing_n': int(d['b11_edu'].isna().sum()),
            })

    out = pd.DataFrame(rows)
    out.to_csv(config.OUT_DESC / 'Table1_by_incident_CVD.csv', index=False, encoding='utf-8-sig')

    # Candidate category event rates: exploratory only, not a frozen definition.
    if 'candidate_mean_night_sleep_cat' in d.columns:
        tab = (
            d.groupby('candidate_mean_night_sleep_cat', observed=False)['incident_cvd']
            .agg(['count', 'sum', 'mean'])
            .reset_index()
            .rename(columns={'sum': 'events', 'mean': 'event_fraction'})
        )
        tab['event_percent'] = tab['event_fraction'] * 100
        tab.to_csv(config.OUT_DESC / 'candidate_sleep_category_event_rates.csv', index=False, encoding='utf-8-sig')

    print('Finished 02_descriptive_table1.py')
    print(f'Table 1 rows: {len(out)}')


if __name__ == '__main__':
    main()
