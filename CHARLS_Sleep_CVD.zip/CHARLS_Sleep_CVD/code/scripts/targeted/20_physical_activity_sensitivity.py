from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd

import config
from analysis_utils import read_harmonized
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    fit_exposure_model,
    category_formula,
)
from stage3_utils import (
    CORE_CONFOUNDER_COVARIATES,
    EXTENDED_RISK_FACTOR_COVARIATES,
)


# -----------------------------------------------------------------------------
# Targeted sensitivity analysis: add baseline (2011) physical activity.
#
# This script intentionally does NOT modify the frozen primary models.
# It reads the original harmonized longitudinal CSV, extracts 2011 physical
# activity, merges it onto the already-created person-level cohort, and refits
# the key sleep-health models with and without physical-activity adjustment.
# -----------------------------------------------------------------------------

OUT_DIR = config.OUTPUT_DIR / '08_targeted_sensitivity' / '20_physical_activity'
OUT_DIR.mkdir(parents=True, exist_ok=True)

# If you know the exact harmonized variable name, set it here, e.g. 'totmet'.
# Leave as None to auto-detect from the priority list below.
PREFERRED_PA_VAR: str | None = None

# Exact-name priority only. We deliberately do NOT guess from arbitrary columns.
PA_PRIORITY = [
    'totmet',
    'total_met',
    'total_met_min_week',
    'total_met_minutes',
    'met_total',
    'pa_met',
    'physical_activity_met',
    'exercise',
]


OUTCOME_LABELS = {
    'cvd': 'Overall CVD',
    'heart': 'Heart disease',
    'stroke': 'Stroke',
}


def detect_pa_variable(df: pd.DataFrame) -> tuple[str, list[str]]:
    """Choose a baseline physical-activity variable and return diagnostic candidates."""
    cols = list(df.columns)
    lower_map = {c.lower(): c for c in cols}

    # Diagnostic list only: useful if the exact variable was not detected.
    diagnostic = [
        c for c in cols
        if any(k in c.lower() for k in ['totmet', 'exercise', 'physical', 'activity', 'met_'])
    ]

    if PREFERRED_PA_VAR is not None:
        if PREFERRED_PA_VAR in df.columns:
            return PREFERRED_PA_VAR, diagnostic
        if PREFERRED_PA_VAR.lower() in lower_map:
            return lower_map[PREFERRED_PA_VAR.lower()], diagnostic
        raise KeyError(
            f'PREFERRED_PA_VAR={PREFERRED_PA_VAR!r} not found. '
            f'Possible physical-activity columns: {diagnostic}'
        )

    for candidate in PA_PRIORITY:
        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()], diagnostic

    raise KeyError(
        'No exact physical-activity variable was detected. '
        'Set PREFERRED_PA_VAR at the top of this script. '
        f'Possible related columns: {diagnostic}'
    )


def prepare_baseline_pa(raw: pd.DataFrame, pa_var: str) -> tuple[pd.DataFrame, str, str]:
    """Extract and transform 2011 physical activity for model adjustment.

    For MET-like variables, use log(1 + MET) in models because total MET volume
    is usually strongly right-skewed. Raw MET remains in the diagnostic output.

    If only an exercise indicator/category is available, treat it as categorical.
    """
    b = raw.loc[raw['wave'] == 1, ['ID', pa_var]].copy()
    b = b.sort_values('ID').drop_duplicates('ID')

    x = pd.to_numeric(b[pa_var], errors='coerce')
    # Negative values are treated as non-substantive survey codes / invalid values.
    x = x.where(x >= 0)

    is_met = 'met' in pa_var.lower()
    if is_met:
        b['b11_physical_activity_raw'] = x
        b['b11_log_physical_activity'] = np.log1p(x)
        model_term = 'b11_log_physical_activity'
        transform_label = f'log1p({pa_var})'
    else:
        # Keep observed nonnegative codes as categories rather than assuming 0/1 coding.
        b['b11_physical_activity'] = x.astype(object)
        model_term = 'C(b11_physical_activity)'
        transform_label = f'categorical({pa_var})'

    return b.drop(columns=[pa_var]), model_term, transform_label


def pa_diagnostics(raw: pd.DataFrame, cohort: pd.DataFrame, pa_var: str, transform_label: str) -> None:
    """Save source coding/distribution/missingness before fitting models."""
    w1 = raw.loc[raw['wave'] == 1, ['ID', pa_var]].copy()
    x = pd.to_numeric(w1[pa_var], errors='coerce')
    valid = x.where(x >= 0)

    q = valid.quantile([0, .01, .05, .25, .50, .75, .95, .99, 1]).rename('value')
    q.index = [str(v) for v in q.index]
    q.to_csv(OUT_DIR / 'physical_activity_quantiles_2011.csv', encoding='utf-8-sig')

    vc = w1[pa_var].value_counts(dropna=False).head(50).rename_axis('raw_value').reset_index(name='n')
    vc.to_csv(OUT_DIR / 'physical_activity_top_raw_values_2011.csv', index=False, encoding='utf-8-sig')

    diag = pd.DataFrame([
        {'metric': 'selected_source_variable', 'value': pa_var},
        {'metric': 'model_transform', 'value': transform_label},
        {'metric': 'wave1_n', 'value': int(len(w1))},
        {'metric': 'wave1_nonmissing_nonnegative_n', 'value': int(valid.notna().sum())},
        {'metric': 'wave1_missing_or_negative_n', 'value': int(valid.isna().sum())},
        {'metric': 'wave1_missing_or_negative_pct', 'value': float(valid.isna().mean() * 100)},
        {'metric': 'primary_landmark_cohort_n', 'value': int(len(cohort))},
    ])
    diag.to_csv(OUT_DIR / 'physical_activity_diagnostics.csv', index=False, encoding='utf-8-sig')


def select_key_terms(tab: pd.DataFrame, analysis: str, model_label: str) -> pd.DataFrame:
    """Retain manuscript-relevant coefficients from each fitted model."""
    z = tab.copy()
    term = z['term'].astype(str)

    if analysis == 'cumulative_score':
        keep = term.eq('mdsh_cumulative_total')
        effect = 'Cumulative MDSH, per +1 point'

    elif analysis == 'favorable_waves':
        # Retain both the 3-vs-0 contrast and the full category terms in the full file;
        # the compact file focuses on 3 vs 0.
        keep = term.str.contains('mdsh_n_favorable_strict_waves', regex=False)
        effect = 'Fully favorable waves (categorical; ref=0)'

    elif analysis == 'favorable_wave_trend':
        keep = term.eq('mdsh_n_favorable_strict_waves')
        effect = 'Per additional fully favorable wave'

    elif analysis == 'transition':
        keep = term.str.contains('mdsh_transition_strict', regex=False)
        effect = '2011-2015 endpoint transition'

    elif analysis == 'continuous_change':
        keep = term.eq('mdsh_delta_2015_2011')
        effect = 'MDSH change, per +1 point; adjusted for 2011 MDSH'

    else:
        raise ValueError(analysis)

    out = z.loc[keep].copy()
    out.insert(0, 'analysis', analysis)
    out.insert(1, 'effect', effect)
    out.insert(2, 'adjustment_model', model_label)
    return out


def fit_all(d: pd.DataFrame, pa_term: str) -> pd.DataFrame:
    rows = []

    model_sets = {
        'Model 2: core confounder': list(CORE_CONFOUNDER_COVARIATES),
        'Model 2 + physical activity': list(CORE_CONFOUNDER_COVARIATES) + [pa_term],
        'Model 3: extended risk factor': list(EXTENDED_RISK_FACTOR_COVARIATES),
        'Model 3 + physical activity': list(EXTENDED_RISK_FACTOR_COVARIATES) + [pa_term],
    }

    exposure_specs = [
        ('cumulative_score', 'mdsh_cumulative_total'),
        ('favorable_waves', category_formula('mdsh_n_favorable_strict_waves', 0)),
        ('favorable_wave_trend', 'mdsh_n_favorable_strict_waves'),
        ('transition', category_formula('mdsh_transition_strict', 'persistent unfavorable')),
        # As in Stage 4, continuous change additionally adjusts for baseline MDSH.
        ('continuous_change', 'mdsh_delta_2015_2011 + mdsh_score_2011'),
    ]

    for outcome in ['cvd', 'heart', 'stroke']:
        for model_label, covariates in model_sets.items():
            for analysis, exposure_term in exposure_specs:
                _, tab = fit_exposure_model(
                    d,
                    outcome,
                    exposure_term,
                    model_name='physical_activity_sensitivity',
                    covariates=covariates,
                )
                rows.append(select_key_terms(tab, analysis, model_label))

    return pd.concat(rows, ignore_index=True)


def make_compact(full: pd.DataFrame) -> pd.DataFrame:
    """Compact comparison of the effects most likely to be cited in the manuscript."""
    t = full['term'].astype(str)
    keep = (
        (full['analysis'] == 'cumulative_score')
        | (full['analysis'] == 'favorable_wave_trend')
        | ((full['analysis'] == 'favorable_waves') & t.str.contains(r'\[T\.3(?:\.0)?\]', regex=True))
        | ((full['analysis'] == 'transition') & t.str.contains('persistent favorable', regex=False))
        | (full['analysis'] == 'continuous_change')
    )
    z = full.loc[keep].copy()
    z['Outcome'] = z['outcome'].map(OUTCOME_LABELS)
    z['HR (95% CI)'] = z.apply(
        lambda r: f"{r['HR']:.3f} ({r['CI_low']:.3f}-{r['CI_high']:.3f})", axis=1
    )
    z['P'] = z['p_value'].apply(lambda p: '<0.001' if p < .001 else f'{p:.3f}')
    return z


def compare_attenuation(compact: pd.DataFrame) -> pd.DataFrame:
    """Quantify how much adding PA changes the sleep-health log-HR."""
    z = compact.copy()
    z['beta_sleep'] = np.log(z['HR'])

    pairs = [
        ('Model 2: core confounder', 'Model 2 + physical activity'),
        ('Model 3: extended risk factor', 'Model 3 + physical activity'),
    ]
    rows = []

    # term is needed to distinguish specific categorical contrasts.
    key_cols = ['outcome', 'analysis', 'term']
    for base_label, pa_label in pairs:
        base = z[z['adjustment_model'] == base_label][key_cols + ['HR', 'CI_low', 'CI_high', 'beta_sleep', 'n_people', 'n_events']].copy()
        pa = z[z['adjustment_model'] == pa_label][key_cols + ['HR', 'CI_low', 'CI_high', 'beta_sleep', 'n_people', 'n_events']].copy()
        m = base.merge(pa, on=key_cols, suffixes=('_base', '_pa'))
        for _, r in m.iterrows():
            beta0 = float(r['beta_sleep_base'])
            beta1 = float(r['beta_sleep_pa'])
            pct = np.nan if abs(beta0) < 1e-12 else (beta1 - beta0) / abs(beta0) * 100.0
            rows.append({
                'outcome': r['outcome'],
                'analysis': r['analysis'],
                'term': r['term'],
                'base_model': base_label,
                'pa_model': pa_label,
                'HR_base': r['HR_base'],
                'CI_low_base': r['CI_low_base'],
                'CI_high_base': r['CI_high_base'],
                'HR_plus_PA': r['HR_pa'],
                'CI_low_plus_PA': r['CI_low_pa'],
                'CI_high_plus_PA': r['CI_high_pa'],
                'percent_change_log_HR': pct,
                'n_people_base': r['n_people_base'],
                'n_people_plus_PA': r['n_people_pa'],
                'n_events_base': r['n_events_base'],
                'n_events_plus_PA': r['n_events_pa'],
            })

    return pd.DataFrame(rows)


def main():
    raw, source_path = read_harmonized()
    pa_var, diagnostic_candidates = detect_pa_variable(raw)

    cohort = read_person_cohort()
    d = derive_dynamic_sleep_features(cohort)

    pa, pa_term, transform_label = prepare_baseline_pa(raw, pa_var)
    d = d.merge(pa, on='ID', how='left', validate='one_to_one')

    pa_diagnostics(raw, d, pa_var, transform_label)

    pd.DataFrame({'candidate_column': diagnostic_candidates}).to_csv(
        OUT_DIR / 'physical_activity_related_columns.csv', index=False, encoding='utf-8-sig'
    )

    full = fit_all(d, pa_term)
    full.insert(0, 'source_file', str(source_path))
    full.insert(1, 'physical_activity_source_var', pa_var)
    full.insert(2, 'physical_activity_model_term', pa_term)
    full.to_csv(
        OUT_DIR / 'physical_activity_sensitivity_full_results.csv',
        index=False,
        encoding='utf-8-sig',
    )

    compact = make_compact(full)
    compact.to_csv(
        OUT_DIR / 'physical_activity_sensitivity_compact.csv',
        index=False,
        encoding='utf-8-sig',
    )

    attenuation = compare_attenuation(compact)
    attenuation.to_csv(
        OUT_DIR / 'physical_activity_attenuation_comparison.csv',
        index=False,
        encoding='utf-8-sig',
    )

    print('Finished 20_physical_activity_sensitivity.py')
    print(f'Source: {source_path}')
    print(f'Physical activity variable selected: {pa_var}')
    print(f'Model term: {pa_term} ({transform_label})')

    if 'b11_physical_activity_raw' in d.columns:
        x = d['b11_physical_activity_raw']
        print(
            'PA in landmark cohort: '
            f'nonmissing={x.notna().sum():,}/{len(d):,} '
            f'({x.notna().mean()*100:.1f}%), '
            f'median={x.median():.1f}, '
            f'IQR={x.quantile(.25):.1f}-{x.quantile(.75):.1f}'
        )
    elif 'b11_physical_activity' in d.columns:
        print('PA category counts in landmark cohort:')
        print(d['b11_physical_activity'].value_counts(dropna=False).to_string())

    print('\nKey physical-activity sensitivity results:')
    show = compact[[
        'Outcome', 'analysis', 'adjustment_model', 'HR (95% CI)', 'P', 'n_people', 'n_events'
    ]].copy()
    print(show.to_string(index=False))

    print('\nChange after adding physical activity (log-HR scale):')
    show2 = attenuation[[
        'outcome', 'analysis', 'base_model', 'HR_base', 'HR_plus_PA',
        'percent_change_log_HR', 'n_people_base', 'n_people_plus_PA'
    ]].copy()
    print(show2.to_string(index=False))


if __name__ == '__main__':
    main()
