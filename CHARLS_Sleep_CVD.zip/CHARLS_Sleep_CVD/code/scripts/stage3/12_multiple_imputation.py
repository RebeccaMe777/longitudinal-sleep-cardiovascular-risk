from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import os
import numpy as np
import pandas as pd
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge

import config
from analysis_utils import make_person_period, fit_cloglog
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features, category_formula, FULL_COVARIATES
from stage3_utils import ensure_stage3_dirs, rubin_pool

OUT = config.OUTPUT_DIR / '06_stage3' / '12_multiple_imputation'
M = int(os.environ.get('SLEEP_CVD_MI_M', '20'))
MAX_ITER = int(os.environ.get('SLEEP_CVD_MI_MAX_ITER', '10'))
SEED = config.RANDOM_SEED

IMPUTE_COVARS = [
    'age_2015', 'b11_gender_harmonized', 'b11_marry_harmonized', 'b11_rural',
    'b11_edu', 'b11_smoken', 'b11_drinkl', 'b11_srh', 'b11_adlab_c', 'b11_iadl',
    'b11_cesd9_derived', 'b11_bmi_harmonized', 'b11_hibpe_1', 'b11_diabe_1', 'b11_dyslipe',
]

# Auxiliary predictors improve imputation but are not automatically added to outcome models.
AUXILIARY = [
    'b11_waist_harmonized_cm', 'b11_systo', 'b11_diasto',
    'b11_social_activity_count', 'b11_log_hhcperc', 'b11_retire', 'b11_ins',
    'mdsh_cumulative_total', 'incident_cvd', 'incident_heart', 'incident_stroke',
]

FIXED = [
    'ID', 'observed_wave4', 'observed_wave5',
    'incident_cvd', 'incident_heart', 'incident_stroke',
    'first_cvd_event_wave', 'first_heart_event_wave', 'first_stroke_event_wave',
    'mdsh_cumulative_total', 'mdsh_transition_strict',
]

DISCRETE_ALLOWED = {
    'b11_gender_harmonized': [0, 1],
    'b11_marry_harmonized': [0, 1],
    'b11_rural': [0, 1],
    'b11_edu': [1, 2, 3, 4],
    'b11_smoken': [0, 1],
    'b11_drinkl': [0, 1],
    'b11_srh': [1, 2, 3, 4, 5],
    'b11_adlab_c': [0, 1, 2, 3, 4, 5, 6],
    'b11_iadl': [0, 1, 2, 3, 4, 5],
    'b11_cesd9_derived': list(range(0, 28)),
    'b11_hibpe_1': [0, 1],
    'b11_diabe_1': [0, 1],
    'b11_dyslipe': [0, 1],
}


def snap_to_allowed(x: pd.Series, allowed):
    a = np.asarray(allowed, dtype=float)
    vals = pd.to_numeric(x, errors='coerce').to_numpy(dtype=float)
    idx = np.abs(vals[:, None] - a[None, :]).argmin(axis=1)
    return pd.Series(a[idx], index=x.index)


def pool_target(fits, term, outcome, analysis):
    estimates, variances, n_people, n_events = [], [], [], []
    for res in fits:
        if term not in res.params.index:
            continue
        estimates.append(float(res.params[term]))
        variances.append(float(res.cov_params().loc[term, term]))
        try:
            used = res.model.data.frame.loc[res.model.data.row_labels]
            n_people.append(int(used.ID.nunique()))
            n_events.append(int(used.event.sum()))
        except Exception:
            pass
    pooled = rubin_pool(estimates, variances)
    pooled.update({
        'analysis': analysis, 'outcome': outcome, 'term': term,
        'n_people_median': float(np.median(n_people)) if n_people else np.nan,
        'n_events_median': float(np.median(n_events)) if n_events else np.nan,
    })
    return pooled


def main():
    ensure_stage3_dirs()
    d = derive_dynamic_sleep_features(read_person_cohort())
    d = d[d['mdsh_complete_all3'] == 1].copy()

    impute_features = []
    for c in IMPUTE_COVARS + AUXILIARY:
        if c in d.columns and c not in impute_features:
            impute_features.append(c)

    X = d[impute_features].apply(pd.to_numeric, errors='coerce')
    missing_before = pd.DataFrame({
        'variable': IMPUTE_COVARS,
        'n_missing': [int(X[c].isna().sum()) for c in IMPUTE_COVARS],
        'pct_missing': [float(X[c].isna().mean() * 100) for c in IMPUTE_COVARS],
    })
    missing_before.to_csv(OUT / 'mi_missingness_before.csv', index=False, encoding='utf-8-sig')

    fixed_cols = [c for c in FIXED if c in d.columns]
    fixed = d[fixed_cols].copy().reset_index(drop=True)
    X = X.reset_index(drop=True)

    completed = []
    diag_rows = []
    for m in range(1, M + 1):
        imp = IterativeImputer(
            estimator=BayesianRidge(),
            max_iter=MAX_ITER,
            sample_posterior=True,
            random_state=SEED + m,
            initial_strategy='median',
            skip_complete=True,
            min_value=-1e6,
            max_value=1e6,
        )
        arr = imp.fit_transform(X)
        xi = pd.DataFrame(arr, columns=X.columns)

        # Constrain imputed discrete variables to their observed/codebook support.
        for c, allowed in DISCRETE_ALLOWED.items():
            if c in xi.columns:
                xi[c] = snap_to_allowed(xi[c], allowed)
        # Plausible BMI guardrail; observed values remain unchanged by IterativeImputer.
        if 'b11_bmi_harmonized' in xi.columns:
            xi['b11_bmi_harmonized'] = xi['b11_bmi_harmonized'].clip(10, 60)

        person = fixed.copy()
        for c in IMPUTE_COVARS:
            person[c] = xi[c].values
        person['imputation'] = m
        completed.append(person)

        for c in IMPUTE_COVARS:
            diag_rows.append({
                'variable': c, 'imputation': m,
                'mean': float(person[c].mean()), 'sd': float(person[c].std(ddof=1)),
                'min': float(person[c].min()), 'max': float(person[c].max()),
            })

    pd.DataFrame(diag_rows).to_csv(OUT / 'mi_completed_diagnostics.csv', index=False, encoding='utf-8-sig')

    formulas = {
        'cumulative_score': 'event ~ C(interval) + mdsh_cumulative_total + ' + ' + '.join(FULL_COVARIATES),
        'transition': 'event ~ C(interval) + ' + category_formula('mdsh_transition_strict', 'persistent unfavorable') + ' + ' + ' + '.join(FULL_COVARIATES),
    }

    summary = []
    for outcome in ['cvd', 'heart', 'stroke']:
        fits = {k: [] for k in formulas}
        for x in completed:
            x = x[x[f'incident_{outcome}'].notna()].copy()
            pp = make_person_period(x, outcome)
            for key, formula in formulas.items():
                fits[key].append(fit_cloglog(formula, pp, robust=True))

        summary.append(pool_target(fits['cumulative_score'], 'mdsh_cumulative_total', outcome, 'MI_cumulative_score_per_1point'))
        for level in ['deteriorated', 'improved', 'persistent favorable']:
            term = f'C(mdsh_transition_strict, Treatment(reference="persistent unfavorable"))[T.{level}]'
            summary.append(pool_target(fits['transition'], term, outcome, 'MI_transition_vs_persistent_unfavorable'))

    out = pd.DataFrame(summary)
    out.to_csv(OUT / 'stage3_multiple_imputation_pooled_summary.csv', index=False, encoding='utf-8-sig')

    print('Finished 12_multiple_imputation.py')
    print(f'Stochastic chained-equation imputations: M={M}, max_iter={MAX_ITER}')
    print(out.to_string(index=False))


if __name__ == '__main__':
    main()
