from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

import config
from analysis_utils import read_harmonized, derive_cesd9_from_total
from stage2_utils import derive_dynamic_sleep_features, read_person_cohort, FULL_COVARIATES, category_formula
from stage3_utils import ensure_stage3_dirs, normalize_positive_weight, truncate_weight, fit_weighted_exposure_model

OUT = config.OUTPUT_DIR / '06_stage3' / '13_weighting'
YEARS = {1: 2011, 2: 2013, 3: 2015}


def build_prefollowup_eligible():
    df, _ = read_harmonized()
    w1 = df[df.wave == 1].sort_values('ID').drop_duplicates('ID').copy()
    w3 = df[df.wave == 3].sort_values('ID').drop_duplicates('ID').copy()

    bvars = ['ID', 'age', 'gender_harmonized', 'marry_harmonized', 'rural', 'edu', 'smoken', 'drinkl',
             'srh', 'adlab_c', 'iadl', 'cesd10', 'restless_sleep', 'survey_ind_weight', 'survey_psu']
    b = w1[[c for c in bvars if c in w1.columns]].copy()
    b['cesd9_derived'] = derive_cesd9_from_total(b['cesd10'], b['restless_sleep'])

    lm = w3[['ID', 'baseline_cvd_2015', 'observed_wave4', 'observed_wave5']].copy()
    x = lm.merge(b, on='ID', how='left', validate='one_to_one')

    sleep = df[df.wave.isin(YEARS)][['ID', 'wave', 'night_sleep', 'nap', 'restless_sleep']].copy()
    sleep['year'] = sleep.wave.map(YEARS)
    for var in ['night_sleep', 'nap', 'restless_sleep']:
        wide = sleep.pivot(index='ID', columns='year', values=var)
        wide.columns = [f'{var}_{int(y)}' for y in wide.columns]
        x = x.merge(wide.reset_index(), on='ID', how='left', validate='one_to_one')

    all_sleep = [f'{v}_{y}' for v in ['night_sleep', 'nap', 'restless_sleep'] for y in [2011, 2013, 2015]]
    x['mdsh_complete_all3'] = x[all_sleep].notna().all(axis=1).astype(int)
    # Include the exposure in the censoring/attrition model.
    scores = []
    for y in [2011, 2013, 2015]:
        sc = ((x[f'night_sleep_{y}'] >= 6) & (x[f'night_sleep_{y}'] <= 8)).astype(int)
        sc += (x[f'nap_{y}'] <= 60).astype(int)
        sc += (x[f'restless_sleep_{y}'] <= 2).astype(int)
        scores.append(sc)
    x['mdsh_cumulative_total'] = sum(scores)
    x['followed'] = ((x.observed_wave4 == 1) | (x.observed_wave5 == 1)).astype(int)
    x = x[(x.age >= config.AGE_MIN_WAVE1) & (x.baseline_cvd_2015 == 0) & (x.mdsh_complete_all3 == 1)].copy()
    return x


def simple_fill(x, cols):
    d = x.copy()
    discrete = {'gender_harmonized', 'marry_harmonized', 'rural', 'edu', 'smoken', 'drinkl'}
    for c in cols:
        z = pd.to_numeric(d[c], errors='coerce')
        if c in discrete:
            mode = z.dropna().mode(); fill = float(mode.iloc[0]) if not mode.empty else 0.0
        else:
            fill = float(z.median(skipna=True))
        d[c] = z.fillna(fill)
    return d


def main():
    ensure_stage3_dirs()
    source = build_prefollowup_eligible()
    pred = ['age', 'gender_harmonized', 'marry_harmonized', 'rural', 'edu', 'smoken', 'drinkl',
            'srh', 'adlab_c', 'iadl', 'cesd9_derived', 'mdsh_cumulative_total']
    model_df = simple_fill(source[['ID', 'followed'] + pred], pred)
    formula = ('followed ~ age + C(gender_harmonized) + C(marry_harmonized) + C(rural) + C(edu) + '
               'C(smoken) + C(drinkl) + srh + adlab_c + iadl + cesd9_derived + mdsh_cumulative_total')
    mod = smf.glm(formula, data=model_df, family=sm.families.Binomial()).fit()
    source['p_follow'] = mod.predict(model_df)
    p_num = float(model_df.followed.mean())
    source['sw_attrition_raw'] = p_num / source['p_follow']
    source['sw_attrition'], lo, hi = truncate_weight(source['sw_attrition_raw'], 0.01, 0.99)
    source['sw_attrition'] = normalize_positive_weight(source['sw_attrition'])

    weight_diag = pd.DataFrame({
        'metric': ['eligible_prefollowup_mdsh_complete_n', 'followed_n', 'followed_pct', 'numerator_probability',
                   'raw_min', 'raw_median', 'raw_max', 'trunc_p01', 'trunc_p99', 'truncated_mean', 'truncated_sd'],
        'value': [len(source), int(source.followed.sum()), float(source.followed.mean()*100), p_num,
                  float(source.sw_attrition_raw.min()), float(source.sw_attrition_raw.median()), float(source.sw_attrition_raw.max()),
                  lo, hi, float(source.sw_attrition.mean()), float(source.sw_attrition.std(ddof=1))]
    })
    weight_diag.to_csv(OUT / 'attrition_weight_diagnostics.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame({'term': mod.params.index, 'beta': mod.params.values, 'p_value': mod.pvalues.values}).to_csv(
        OUT / 'attrition_model_coefficients.csv', index=False, encoding='utf-8-sig')

    cohort = derive_dynamic_sleep_features(read_person_cohort())
    cohort = cohort.merge(source[['ID', 'sw_attrition']], on='ID', how='left', validate='one_to_one')
    cohort['baseline_survey_weight_norm'] = normalize_positive_weight(cohort['b11_survey_ind_weight'])
    cohort['combined_survey_attrition_weight'] = normalize_positive_weight(cohort['baseline_survey_weight_norm'] * cohort['sw_attrition'])

    rows, tabs = [], []
    analyses = [
        ('attrition_IPW', 'sw_attrition', None),
        ('baseline_survey_weight_PSU_cluster', 'baseline_survey_weight_norm', 'b11_survey_psu'),
        ('combined_survey_x_attrition', 'combined_survey_attrition_weight', 'b11_survey_psu'),
    ]
    for outcome in ['cvd', 'heart', 'stroke']:
        for label, weight, cluster in analyses:
            for exposure_label, exposure_term, target in [
                ('cumulative_score_per_1point', 'mdsh_cumulative_total', 'mdsh_cumulative_total'),
                ('transition', category_formula('mdsh_transition_strict', 'persistent unfavorable'), 'mdsh_transition_strict'),
            ]:
                try:
                    _, tab = fit_weighted_exposure_model(cohort, outcome, exposure_term, FULL_COVARIATES,
                        weight_col=weight, model_name=label + '_' + exposure_label, cluster_override_col=cluster)
                    tabs.append(tab)
                    hit = tab[tab.term.astype(str).str.contains(target, regex=False)]
                    for _, r in hit.iterrows():
                        rows.append({'analysis': label, 'outcome': outcome, 'exposure': exposure_label, 'term': r.term,
                                     'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high, 'p_value': r.p_value,
                                     'n_people': r.n_people, 'n_events': r.n_events})
                except Exception as e:
                    rows.append({'analysis': label, 'outcome': outcome, 'exposure': exposure_label, 'error': repr(e)})

    pd.DataFrame(rows).to_csv(OUT / 'stage3_weighted_sensitivity_summary.csv', index=False, encoding='utf-8-sig')
    if tabs:
        pd.concat(tabs, ignore_index=True).to_csv(OUT / 'stage3_weighted_all_coefficients.csv', index=False, encoding='utf-8-sig')
    print('Finished 13_attrition_and_survey_weighting.py')
    print(weight_diag.to_string(index=False))
    print(pd.DataFrame(rows).head(30).to_string(index=False))


if __name__ == '__main__':
    main()
