from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd

import config
from analysis_utils import make_person_period, fit_cloglog, exponentiated_table
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features, FULL_COVARIATES, category_formula
from stage3_utils import ensure_stage3_dirs

OUT = config.OUTPUT_DIR / '06_stage3' / '14_temporal_death'


def fit_pp(pp, outcome, exposure_term, model_name):
    formula = 'event ~ C(interval) + ' + exposure_term + ' + ' + ' + '.join(FULL_COVARIATES)
    res = fit_cloglog(formula, pp, robust=True)
    tab = exponentiated_table(res, model_name, outcome)
    tab.insert(2, 'formula', formula)
    return tab


def main():
    ensure_stage3_dirs()
    d = derive_dynamic_sleep_features(read_person_cohort())

    death_feasibility = pd.DataFrame([
        {'item': 'primary_cohort_n', 'value': len(d)},
        {'item': 'death_known_flag_n', 'value': int(d.death_known.notna().sum()) if 'death_known' in d else 0},
        {'item': 'death_year_nonmissing_n', 'value': int(d.death_year.notna().sum()) if 'death_year' in d else 0},
        {'item': 'death_month_nonmissing_n', 'value': int(d.death_month.notna().sum()) if 'death_month' in d else 0},
        {'item': 'survey_strata_nonmissing_n', 'value': 0},
    ])
    death_feasibility['interpretation'] = [
        'eligible landmark cohort',
        'known death indicator available for only a subset',
        'exact-enough death timing available for very few participants',
        'exact-enough death timing available for very few participants',
        'no strata available; full complex-survey variance estimation not supported',
    ]
    death_feasibility.to_csv(OUT / 'death_and_survey_feasibility.csv', index=False, encoding='utf-8-sig')

    rows, tabs = [], []
    for outcome in ['cvd', 'heart', 'stroke']:
        pp_all = make_person_period(d, outcome)
        variants = {
            'exclude_skipped_wave4_interval': pp_all[pp_all.interval != '2015-2020'].copy(),
        }
        # Known death dates are too sparse for a defensible Fine-Gray model. As a conservative
        # sensitivity analysis only, exclude participants with known death year <= 2020.
        if 'death_year' in d.columns:
            keep_ids = d.loc[~(pd.to_numeric(d.death_year, errors='coerce') <= 2020), 'ID']
            variants['exclude_known_death_through_2020'] = pp_all[pp_all.ID.isin(set(keep_ids))].copy()

        for variant, pp in variants.items():
            for exposure_label, exposure_term, target in [
                ('cumulative_score', 'mdsh_cumulative_total', 'mdsh_cumulative_total'),
                ('transition', category_formula('mdsh_transition_strict', 'persistent unfavorable'), 'mdsh_transition_strict'),
            ]:
                try:
                    tab = fit_pp(pp, outcome, exposure_term, variant + '_' + exposure_label)
                    tabs.append(tab)
                    hit = tab[tab.term.astype(str).str.contains(target, regex=False)]
                    for _, r in hit.iterrows():
                        rows.append({
                            'analysis': variant, 'outcome': outcome, 'exposure': exposure_label,
                            'term': r.term, 'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high,
                            'p_value': r.p_value, 'n_people': r.n_people, 'n_events': r.n_events,
                        })
                except Exception as e:
                    rows.append({'analysis': variant, 'outcome': outcome, 'exposure': exposure_label, 'error': repr(e)})

    pd.DataFrame(rows).to_csv(OUT / 'stage3_temporal_death_sensitivity_summary.csv', index=False, encoding='utf-8-sig')
    if tabs:
        pd.concat(tabs, ignore_index=True).to_csv(OUT / 'stage3_temporal_death_all_coefficients.csv', index=False, encoding='utf-8-sig')

    print('Finished 14_temporal_and_death_sensitivity.py')
    print(death_feasibility.to_string(index=False))
    print(pd.DataFrame(rows).head(30).to_string(index=False))


if __name__ == '__main__':
    main()
