from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd

import config
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features, fit_exposure_model
from stage3_utils import (
    ensure_stage3_dirs,
    DEMOGRAPHIC_COVARIATES,
    CORE_CONFOUNDER_COVARIATES,
    EXTENDED_RISK_FACTOR_COVARIATES,
)

OUT = config.OUTPUT_DIR / '06_stage3' / '11_model_specification'
YEARS = (2011, 2013, 2015)


def add_leave_one_out_scores(d: pd.DataFrame) -> pd.DataFrame:
    d = d.copy()
    for y in YEARS:
        d[f'score_no_duration_{y}'] = d[[f'healthy_nap_{y}', f'healthy_restless_{y}']].sum(axis=1, min_count=2)
        d[f'score_no_nap_{y}'] = d[[f'healthy_duration_{y}', f'healthy_restless_{y}']].sum(axis=1, min_count=2)
        d[f'score_no_restless_{y}'] = d[[f'healthy_duration_{y}', f'healthy_nap_{y}']].sum(axis=1, min_count=2)

    for name in ['no_duration', 'no_nap', 'no_restless']:
        cols = [f'score_{name}_{y}' for y in YEARS]
        d[f'cum_{name}'] = d[cols].sum(axis=1, min_count=3)
        mean = d[f'cum_{name}'].mean(skipna=True)
        sd = d[f'cum_{name}'].std(skipna=True, ddof=1)
        d[f'z_cum_{name}'] = (d[f'cum_{name}'] - mean) / sd

    mean = d['mdsh_cumulative_total'].mean(skipna=True)
    sd = d['mdsh_cumulative_total'].std(skipna=True, ddof=1)
    d['z_mdsh_cumulative_total'] = (d['mdsh_cumulative_total'] - mean) / sd
    return d


def main():
    ensure_stage3_dirs()
    d = derive_dynamic_sleep_features(read_person_cohort())
    d = add_leave_one_out_scores(d)

    adjustment_sets = {
        'A_demographic': DEMOGRAPHIC_COVARIATES,
        'B_core_confounder': CORE_CONFOUNDER_COVARIATES,
        'C_extended_risk_factor': EXTENDED_RISK_FACTOR_COVARIATES,
    }

    rows, tabs = [], []
    for outcome in ['cvd', 'heart', 'stroke']:
        for model_label, covs in adjustment_sets.items():
            try:
                _, tab = fit_exposure_model(
                    d, outcome, 'mdsh_cumulative_total',
                    f'mdsh_cumulative_{model_label}', covariates=covs,
                )
                tabs.append(tab)
                hit = tab[tab['term'] == 'mdsh_cumulative_total']
                if not hit.empty:
                    r = hit.iloc[0]
                    rows.append({
                        'analysis': 'adjustment_set', 'outcome': outcome,
                        'model': model_label, 'exposure': 'mdsh_cumulative_total_per_1point',
                        'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high,
                        'p_value': r.p_value, 'n_people': r.n_people, 'n_events': r.n_events,
                    })
            except Exception as e:
                rows.append({'analysis': 'adjustment_set', 'outcome': outcome, 'model': model_label, 'error': repr(e)})

        # Leave-one-component-out scores are standardized for scale comparability.
        for label, var in [
            ('full_3component', 'z_mdsh_cumulative_total'),
            ('without_duration', 'z_cum_no_duration'),
            ('without_nap', 'z_cum_no_nap'),
            ('without_restless_sleep', 'z_cum_no_restless'),
        ]:
            try:
                _, tab = fit_exposure_model(
                    d, outcome, var,
                    f'leave_one_out_{label}', covariates=EXTENDED_RISK_FACTOR_COVARIATES,
                )
                tabs.append(tab)
                hit = tab[tab['term'] == var]
                if not hit.empty:
                    r = hit.iloc[0]
                    rows.append({
                        'analysis': 'leave_one_component_out', 'outcome': outcome,
                        'model': 'extended_risk_factor', 'exposure': label + '_per_1SD',
                        'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high,
                        'p_value': r.p_value, 'n_people': r.n_people, 'n_events': r.n_events,
                    })
            except Exception as e:
                rows.append({'analysis': 'leave_one_component_out', 'outcome': outcome, 'exposure': label, 'error': repr(e)})

    pd.DataFrame(rows).to_csv(OUT / 'stage3_model_specification_summary.csv', index=False, encoding='utf-8-sig')
    if tabs:
        pd.concat(tabs, ignore_index=True).to_csv(OUT / 'stage3_model_specification_all_coefficients.csv', index=False, encoding='utf-8-sig')

    # Descriptive correlations among sleep-health components.
    vars_ = ['mdsh_cumulative_total', 'n_short_sleep_waves', 'n_long_nap_waves', 'n_poor_restless_waves', 'exp_arv_night_sleep']
    d[vars_].corr(method='spearman').to_csv(OUT / 'stage3_sleep_component_spearman.csv', encoding='utf-8-sig')

    print('Finished 11_model_specification_leave_one_out.py')
    print(pd.DataFrame(rows).head(40).to_string(index=False))


if __name__ == '__main__':
    main()
