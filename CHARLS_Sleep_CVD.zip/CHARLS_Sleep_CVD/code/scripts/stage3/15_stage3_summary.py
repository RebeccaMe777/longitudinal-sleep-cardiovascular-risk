from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


from pathlib import Path
import pandas as pd

import config
from stage3_utils import ensure_stage3_dirs

OUT = config.OUTPUT_DIR / '06_stage3' / '15_summary'


def read_if(path: Path):
    return pd.read_csv(path, low_memory=False) if path.exists() else None


def main():
    ensure_stage3_dirs()
    root = config.OUTPUT_DIR / '06_stage3'
    sources = {
        'model_specification': root / '11_model_specification' / 'stage3_model_specification_summary.csv',
        'multiple_imputation': root / '12_multiple_imputation' / 'stage3_multiple_imputation_pooled_summary.csv',
        'weighting': root / '13_weighting' / 'stage3_weighted_sensitivity_summary.csv',
        'temporal_death': root / '14_temporal_death' / 'stage3_temporal_death_sensitivity_summary.csv',
    }

    blocks = []
    for label, path in sources.items():
        x = read_if(path)
        if x is None:
            continue
        x.insert(0, 'source_analysis', label)
        blocks.append(x)

    if blocks:
        # Concatenation intentionally preserves heterogeneous columns for a human-readable master file.
        out = pd.concat(blocks, ignore_index=True, sort=False)
        out.to_csv(OUT / 'stage3_master_summary.csv', index=False, encoding='utf-8-sig')
        print(out.head(60).to_string(index=False))
    else:
        print('No stage-3 result files found yet.')

    print('Finished 15_stage3_summary.py')


if __name__ == '__main__':
    main()
