from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import pandas as pd

import config
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    person_event_table,
    fit_exposure_model,
    category_formula,
)


def main():
    config.ensure_output_dirs()
    cohort = derive_dynamic_sleep_features(read_person_cohort())

    # Distribution of score at each wave and cumulative score.
    dist_rows = []
    for var in [
        'mdsh_score_2011', 'mdsh_score_2013', 'mdsh_score_2015',
        'mdsh_cumulative_total', 'mdsh_n_favorable_strict_waves',
    ]:
        vc = cohort[var].value_counts(dropna=False).sort_index()
        for value, n in vc.items():
            dist_rows.append({'variable': var, 'value': value, 'n': int(n)})
    pd.DataFrame(dist_rows).to_csv(
        config.OUT_DESC / 'stage2_mdsh_score_distribution.csv', index=False, encoding='utf-8-sig'
    )

    desc_tabs = []
    model_tabs = []
    summary_rows = []

    for outcome in ['cvd', 'heart', 'stroke']:
        for var in ['mdsh_cumulative_total', 'mdsh_n_favorable_strict_waves']:
            desc = person_event_table(cohort, var, outcome)
            desc.insert(1, 'exposure_analysis', var)
            desc_tabs.append(desc)

        # Primary cumulative score: 0-9, HR per 1-point healthier score.
        try:
            _, tab = fit_exposure_model(
                cohort, outcome, 'mdsh_cumulative_total',
                'mdsh_cumulative_total_per_1point_full_adjustment',
            )
            tab.insert(2, 'exposure_analysis', 'mdsh_cumulative_total')
            tab.insert(3, 'parameterization', '0-9; HR per +1 healthier point')
            model_tabs.append(tab)
            hit = tab[tab['term'] == 'mdsh_cumulative_total']
            if not hit.empty:
                r = hit.iloc[0]
                summary_rows.append({
                    'outcome': outcome,
                    'exposure': 'mdsh_cumulative_total',
                    'parameterization': 'per_1point',
                    'HR': r['HR'], 'CI_low': r['CI_low'], 'CI_high': r['CI_high'],
                    'p_value': r['p_value'], 'n_people': r['n_people'], 'n_events': r['n_events'],
                })
        except Exception as e:
            summary_rows.append({'outcome': outcome, 'exposure': 'mdsh_cumulative_total', 'error': repr(e)})

        # Number of waves with all 3 favorable domains, 0-3; primary persistence of full sleep health.
        try:
            term = category_formula('mdsh_n_favorable_strict_waves', 0)
            _, tab = fit_exposure_model(
                cohort, outcome, term,
                'mdsh_n_favorable_waves_categorical_full_adjustment',
            )
            tab.insert(2, 'exposure_analysis', 'mdsh_n_favorable_strict_waves')
            tab.insert(3, 'parameterization', '0/1/2/3 waves; reference=0')
            model_tabs.append(tab)
            hit = tab[tab['term'].astype(str).str.contains('mdsh_n_favorable_strict_waves', regex=False)]
            for _, r in hit.iterrows():
                summary_rows.append({
                    'outcome': outcome,
                    'exposure': 'mdsh_n_favorable_strict_waves',
                    'parameterization': 'categorical',
                    'term': r['term'],
                    'HR': r['HR'], 'CI_low': r['CI_low'], 'CI_high': r['CI_high'],
                    'p_value': r['p_value'], 'n_people': r['n_people'], 'n_events': r['n_events'],
                })
        except Exception as e:
            summary_rows.append({'outcome': outcome, 'exposure': 'mdsh_n_favorable_strict_waves', 'error': repr(e)})

        # Trend per additional fully favorable wave.
        try:
            _, tab = fit_exposure_model(
                cohort, outcome, 'mdsh_n_favorable_strict_waves',
                'mdsh_n_favorable_waves_per_wave_full_adjustment',
            )
            tab.insert(2, 'exposure_analysis', 'mdsh_n_favorable_strict_waves')
            tab.insert(3, 'parameterization', 'per additional fully favorable wave')
            model_tabs.append(tab)
            hit = tab[tab['term'] == 'mdsh_n_favorable_strict_waves']
            if not hit.empty:
                r = hit.iloc[0]
                summary_rows.append({
                    'outcome': outcome,
                    'exposure': 'mdsh_n_favorable_strict_waves',
                    'parameterization': 'per_wave',
                    'HR': r['HR'], 'CI_low': r['CI_low'], 'CI_high': r['CI_high'],
                    'p_value': r['p_value'], 'n_people': r['n_people'], 'n_events': r['n_events'],
                })
        except Exception as e:
            summary_rows.append({'outcome': outcome, 'exposure': 'mdsh_n_favorable_strict_waves', 'parameterization': 'per_wave', 'error': repr(e)})

    pd.concat(desc_tabs, ignore_index=True).to_csv(
        config.OUT_DESC / 'stage2_mdsh_event_rates.csv', index=False, encoding='utf-8-sig'
    )
    if model_tabs:
        pd.concat(model_tabs, ignore_index=True).to_csv(
            config.OUT_MODELS / 'stage2_mdsh_all_coefficients.csv', index=False, encoding='utf-8-sig'
        )
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(
        config.OUT_MODELS / 'stage2_mdsh_summary.csv', index=False, encoding='utf-8-sig'
    )

    print('Finished 08_multidimensional_sleep_score.py')
    print(summary.head(30).to_string(index=False))


if __name__ == '__main__':
    main()
