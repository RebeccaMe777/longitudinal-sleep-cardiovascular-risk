from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

import config
from analysis_utils import make_person_period, fit_cloglog, exponentiated_table
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    FULL_COVARIATES,
    category_formula,
    fit_lr_interaction,
)


def main():
    config.ensure_output_dirs()
    cohort = derive_dynamic_sleep_features(read_person_cohort())

    # ------------------------------------------------------------------
    # A. Correlation and VIF among the four stage-1 sleep dimensions.
    # ------------------------------------------------------------------
    sleep_vars = [
        'exp_mean_night_sleep',
        'exp_arv_night_sleep',
        'mean_nap_30min',
        'exp_mean_restless_sleep',
    ]
    corr = cohort[sleep_vars].corr(method='spearman')
    corr.to_csv(config.OUT_DESC / 'stage2_sleep_dimension_spearman_correlation.csv', encoding='utf-8-sig')

    vif_data = cohort[sleep_vars].dropna().copy()
    X = sm.add_constant(vif_data.astype(float), has_constant='add')
    vif_rows = []
    for i, c in enumerate(X.columns):
        if c == 'const':
            continue
        vif_rows.append({'variable': c, 'VIF': float(variance_inflation_factor(X.values, i)), 'n': len(X)})
    pd.DataFrame(vif_rows).to_csv(
        config.OUT_DESC / 'stage2_sleep_dimension_vif.csv', index=False, encoding='utf-8-sig'
    )

    # ------------------------------------------------------------------
    # B. Continuous mean-sleep x ARV interaction.
    # ------------------------------------------------------------------
    cohort['mean_sleep_centered_7h'] = cohort['exp_mean_night_sleep'] - 7.0
    arv_median = float(cohort['exp_arv_night_sleep'].median())
    cohort['arv_centered_median'] = cohort['exp_arv_night_sleep'] - arv_median

    interaction_rows = []
    coefficient_tabs = []

    for outcome in ['cvd', 'heart', 'stroke']:
        pp = make_person_period(cohort, outcome)
        base_terms = ['mean_sleep_centered_7h', 'arv_centered_median'] + FULL_COVARIATES
        reduced_formula = 'event ~ C(interval) + ' + ' + '.join(base_terms)
        full_formula = reduced_formula + ' + mean_sleep_centered_7h:arv_centered_median'

        try:
            test = fit_lr_interaction(pp, reduced_formula, full_formula)
            robust_full = fit_cloglog(full_formula, pp, robust=True)
            tab = exponentiated_table(robust_full, 'continuous_mean_sleep_x_ARV', outcome)
            tab.insert(2, 'formula', full_formula)
            coefficient_tabs.append(tab)
            hit = tab[tab['term'] == 'mean_sleep_centered_7h:arv_centered_median']
            interaction_rows.append({
                'outcome': outcome,
                'interaction': 'continuous mean nighttime sleep x ARV',
                'ARV_center_hours': arv_median,
                'LR': test['LR'], 'df': test['df'], 'p_interaction': test['p_value'],
                'interaction_HR': hit.iloc[0]['HR'] if not hit.empty else np.nan,
                'CI_low': hit.iloc[0]['CI_low'] if not hit.empty else np.nan,
                'CI_high': hit.iloc[0]['CI_high'] if not hit.empty else np.nan,
            })
        except Exception as e:
            interaction_rows.append({'outcome': outcome, 'interaction': 'continuous mean nighttime sleep x ARV', 'error': repr(e)})

    # ------------------------------------------------------------------
    # C. Categorical global interaction: mean sleep category x ARV quartile.
    # ------------------------------------------------------------------
    q = cohort['exp_arv_night_sleep'].quantile([0.25, 0.50, 0.75]).tolist()
    q1, q2, q3 = q
    cohort['arv_quartile'] = pd.cut(
        cohort['exp_arv_night_sleep'],
        bins=[-np.inf, q1, q2, q3, np.inf],
        labels=['Q1 lowest variability', 'Q2', 'Q3', 'Q4 highest variability'],
        include_lowest=True,
    ).astype(object)
    x = cohort['exp_mean_night_sleep']
    cohort['mean_sleep_cat'] = pd.Series(np.nan, index=cohort.index, dtype=object)
    cohort.loc[x < config.SHORT_SLEEP_H, 'mean_sleep_cat'] = f'<{config.SHORT_SLEEP_H:g} h'
    cohort.loc[x.between(config.SHORT_SLEEP_H, config.LONG_SLEEP_H, inclusive='both'), 'mean_sleep_cat'] = f'{config.SHORT_SLEEP_H:g}-{config.LONG_SLEEP_H:g} h'
    cohort.loc[x > config.LONG_SLEEP_H, 'mean_sleep_cat'] = f'>{config.LONG_SLEEP_H:g} h'

    mean_ref = f'{config.SHORT_SLEEP_H:g}-{config.LONG_SLEEP_H:g} h'
    arv_ref = 'Q1 lowest variability'
    mean_term = category_formula('mean_sleep_cat', mean_ref)
    arv_term = category_formula('arv_quartile', arv_ref)

    for outcome in ['cvd', 'heart', 'stroke']:
        pp = make_person_period(cohort, outcome)
        reduced_formula = 'event ~ C(interval) + ' + mean_term + ' + ' + arv_term + ' + ' + ' + '.join(FULL_COVARIATES)
        full_formula = 'event ~ C(interval) + (' + mean_term + ')*(' + arv_term + ') + ' + ' + '.join(FULL_COVARIATES)
        try:
            test = fit_lr_interaction(pp, reduced_formula, full_formula)
            robust_full = fit_cloglog(full_formula, pp, robust=True)
            tab = exponentiated_table(robust_full, 'categorical_mean_sleep_x_ARV', outcome)
            tab.insert(2, 'formula', full_formula)
            coefficient_tabs.append(tab)
            interaction_rows.append({
                'outcome': outcome,
                'interaction': 'categorical mean sleep x ARV quartile',
                'ARV_quartile_cutpoints_hours': f'{q1:.3f}, {q2:.3f}, {q3:.3f}',
                'LR': test['LR'], 'df': test['df'], 'p_interaction': test['p_value'],
            })
        except Exception as e:
            interaction_rows.append({'outcome': outcome, 'interaction': 'categorical mean sleep x ARV quartile', 'error': repr(e)})

    pd.DataFrame(interaction_rows).to_csv(
        config.OUT_MODELS / 'stage2_mean_sleep_ARV_interaction_tests.csv', index=False, encoding='utf-8-sig'
    )
    if coefficient_tabs:
        pd.concat(coefficient_tabs, ignore_index=True).to_csv(
            config.OUT_MODELS / 'stage2_mean_sleep_ARV_interaction_coefficients.csv', index=False, encoding='utf-8-sig'
        )

    print('Finished 09_interaction_and_subtype_analysis.py')
    print(pd.DataFrame(interaction_rows).to_string(index=False))
    print('\nVIF:')
    print(pd.DataFrame(vif_rows).to_string(index=False))


if __name__ == '__main__':
    main()
