from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import pandas as pd

import config
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    person_event_table,
    fit_exposure_model,
    category_formula,
)

PERSISTENCE_EXPOSURES = {
    'short_sleep': 'n_short_sleep_waves',
    'long_sleep': 'n_long_sleep_waves',
    'poor_restless_sleep': 'n_poor_restless_waves',
    'long_nap': 'n_long_nap_waves',
}


def main():
    config.ensure_output_dirs()
    cohort = derive_dynamic_sleep_features(read_person_cohort())

    # Save a stage-2 enriched cohort without overwriting stage-1 files.
    cohort.to_csv(
        config.OUT_COHORT / 'analysis_cohort_stage2_dynamic_sleep.csv',
        index=False,
        encoding='utf-8-sig',
    )

    desc_tabs = []
    model_tabs = []
    summaries = []

    for outcome in ['cvd', 'heart', 'stroke']:
        for label, var in PERSISTENCE_EXPOSURES.items():
            desc = person_event_table(cohort, var, outcome)
            desc.insert(1, 'exposure_analysis', label)
            desc_tabs.append(desc)

            # Categorical count 0/1/2/3 waves, reference = 0.
            term = category_formula(var, 0)
            try:
                _, tab = fit_exposure_model(
                    cohort, outcome, term,
                    f'{label}_categorical_full_adjustment',
                )
                tab.insert(2, 'exposure_analysis', label)
                tab.insert(3, 'parameterization', '0/1/2/3 waves; reference=0')
                model_tabs.append(tab)
                for _, r in tab[tab['term'].astype(str).str.contains(var, regex=False)].iterrows():
                    summaries.append({
                        'outcome': outcome,
                        'exposure': label,
                        'parameterization': 'categorical',
                        'term': r['term'],
                        'HR': r['HR'],
                        'CI_low': r['CI_low'],
                        'CI_high': r['CI_high'],
                        'p_value': r['p_value'],
                        'n_people': r['n_people'],
                        'n_events': r['n_events'],
                    })
            except Exception as e:
                summaries.append({'outcome': outcome, 'exposure': label, 'parameterization': 'categorical', 'error': repr(e)})

            # Linear trend: HR per one additional affected wave.
            try:
                _, tab = fit_exposure_model(
                    cohort, outcome, var,
                    f'{label}_per_additional_wave_full_adjustment',
                )
                tab.insert(2, 'exposure_analysis', label)
                tab.insert(3, 'parameterization', 'per additional affected wave')
                model_tabs.append(tab)
                hit = tab[tab['term'] == var]
                if not hit.empty:
                    r = hit.iloc[0]
                    summaries.append({
                        'outcome': outcome,
                        'exposure': label,
                        'parameterization': 'per_additional_wave',
                        'term': var,
                        'HR': r['HR'],
                        'CI_low': r['CI_low'],
                        'CI_high': r['CI_high'],
                        'p_value': r['p_value'],
                        'n_people': r['n_people'],
                        'n_events': r['n_events'],
                    })
            except Exception as e:
                summaries.append({'outcome': outcome, 'exposure': label, 'parameterization': 'per_additional_wave', 'error': repr(e)})

    pd.concat(desc_tabs, ignore_index=True).to_csv(
        config.OUT_DESC / 'stage2_persistence_event_rates.csv', index=False, encoding='utf-8-sig'
    )
    if model_tabs:
        pd.concat(model_tabs, ignore_index=True).to_csv(
            config.OUT_MODELS / 'stage2_persistence_all_coefficients.csv', index=False, encoding='utf-8-sig'
        )
    summary = pd.DataFrame(summaries)
    summary.to_csv(
        config.OUT_MODELS / 'stage2_persistence_summary.csv', index=False, encoding='utf-8-sig'
    )

    print('Finished 06_persistence_analysis.py')
    print('Stage-2 enriched cohort N = {:,}'.format(len(cohort)))
    print('Complete 3-wave multidimensional sleep N = {:,}'.format(int((cohort['mdsh_complete_all3'] == 1).sum())))
    print(summary.head(30).to_string(index=False))


if __name__ == '__main__':
    main()
