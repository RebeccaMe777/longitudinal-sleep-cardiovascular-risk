from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import pandas as pd

import config
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    person_event_table,
    fit_exposure_model,
    category_formula,
)


def run_transition(cohort, outcome, var, definition_label):
    ref = 'persistent unfavorable'
    term = category_formula(var, ref)
    _, tab = fit_exposure_model(
        cohort, outcome, term,
        f'mdsh_transition_{definition_label}_full_adjustment',
    )
    tab.insert(2, 'exposure_analysis', f'mdsh_transition_{definition_label}')
    tab.insert(3, 'parameterization', f'reference={ref}')
    return tab


def main():
    config.ensure_output_dirs()
    cohort = derive_dynamic_sleep_features(read_person_cohort())

    desc_tabs = []
    tabs = []
    summary_rows = []

    for outcome in ['cvd', 'heart', 'stroke']:
        for var, label in [
            ('mdsh_transition_strict', 'strict_all_3_low_risk'),
            ('mdsh_transition_lenient', 'sensitivity_at_least_2_of_3'),
        ]:
            desc = person_event_table(cohort, var, outcome)
            desc.insert(1, 'definition', label)
            desc_tabs.append(desc)
            try:
                tab = run_transition(cohort, outcome, var, label)
                tabs.append(tab)
                hit = tab[tab['term'].astype(str).str.contains(var, regex=False)]
                for _, r in hit.iterrows():
                    summary_rows.append({
                        'outcome': outcome,
                        'definition': label,
                        'term': r['term'],
                        'HR': r['HR'],
                        'CI_low': r['CI_low'],
                        'CI_high': r['CI_high'],
                        'p_value': r['p_value'],
                        'n_people': r['n_people'],
                        'n_events': r['n_events'],
                    })
            except Exception as e:
                summary_rows.append({'outcome': outcome, 'definition': label, 'error': repr(e)})

        # Continuous improvement analysis: change in 0-3 score, adjusted for 2011 score.
        try:
            term = 'mdsh_delta_2015_2011 + mdsh_score_2011'
            _, tab = fit_exposure_model(
                cohort, outcome, term,
                'mdsh_score_change_adjusted_for_2011_score',
            )
            tab.insert(2, 'exposure_analysis', 'mdsh_delta_2015_2011')
            tab.insert(3, 'parameterization', 'per +1 score improvement; adjusted for 2011 score')
            tabs.append(tab)
            hit = tab[tab['term'] == 'mdsh_delta_2015_2011']
            if not hit.empty:
                r = hit.iloc[0]
                summary_rows.append({
                    'outcome': outcome,
                    'definition': 'continuous_score_change',
                    'term': r['term'],
                    'HR': r['HR'],
                    'CI_low': r['CI_low'],
                    'CI_high': r['CI_high'],
                    'p_value': r['p_value'],
                    'n_people': r['n_people'],
                    'n_events': r['n_events'],
                })
        except Exception as e:
            summary_rows.append({'outcome': outcome, 'definition': 'continuous_score_change', 'error': repr(e)})

    pd.concat(desc_tabs, ignore_index=True).to_csv(
        config.OUT_DESC / 'stage2_sleep_change_event_rates.csv', index=False, encoding='utf-8-sig'
    )
    if tabs:
        pd.concat(tabs, ignore_index=True).to_csv(
            config.OUT_MODELS / 'stage2_sleep_change_all_coefficients.csv', index=False, encoding='utf-8-sig'
        )
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(
        config.OUT_MODELS / 'stage2_sleep_change_summary.csv', index=False, encoding='utf-8-sig'
    )

    print('Finished 07_sleep_change_analysis.py')
    print(summary.head(30).to_string(index=False))


if __name__ == '__main__':
    main()
