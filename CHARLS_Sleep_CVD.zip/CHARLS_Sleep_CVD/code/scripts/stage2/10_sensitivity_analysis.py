from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import numpy as np
import pandas as pd

import config
from analysis_utils import fit_cloglog, exponentiated_table
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    FULL_COVARIATES,
    category_formula,
)

DEFINITIONS = {
    # Primary study-specific definition.
    'primary_6to8_nap60_restless_le2': dict(duration_low=6.0, duration_high=8.0, nap_max=60.0, restless_max=2.0),
    # Published Chinese cohort used <=60 min midday napping; a stricter nap cutoff tests robustness.
    'sensitivity_nap30': dict(duration_low=6.0, duration_high=8.0, nap_max=30.0, restless_max=2.0),
    # Stricter subjective sleep criterion: restless <1 day/week only.
    'sensitivity_restless_le1': dict(duration_low=6.0, duration_high=8.0, nap_max=60.0, restless_max=1.0),
    # Dongfeng-Tongji low-risk duration definition: 7 to <8 h, approximated here as [7, 8).
    # Implemented below with a tiny epsilon for the upper bound because the common helper is inclusive.
    'sensitivity_duration_7to_lt8': dict(duration_low=7.0, duration_high=7.999999, nap_max=60.0, restless_max=2.0),
}


def fit_one_interval_lag(cohort, outcome, exposure_term, model_name):
    evwave = f'first_{outcome}_event_wave'
    outcol = f'incident_{outcome}'
    d = cohort[
        (cohort['observed_wave4'] == 1)
        & (cohort['observed_wave5'] == 1)
        & (cohort[evwave] != 4)
        & cohort[outcol].notna()
    ].copy()
    if d.empty:
        raise ValueError('No participants available for lag analysis')
    d['event'] = (d[evwave] == 5).astype(int)
    d['interval'] = '2018-2020'
    d['interval_years'] = 2.0
    d['log_interval_years'] = np.log(2.0)
    formula = 'event ~ ' + exposure_term + ' + ' + ' + '.join(FULL_COVARIATES)
    res = fit_cloglog(formula, d, robust=True)
    tab = exponentiated_table(res, model_name, outcome)
    tab.insert(2, 'formula', formula)
    return tab


def main():
    config.ensure_output_dirs()
    base = read_person_cohort()
    rows = []
    tabs = []

    # ------------------------------------------------------------------
    # A. Alternative multidimensional sleep-health definitions.
    # ------------------------------------------------------------------
    for name, kwargs in DEFINITIONS.items():
        d = derive_dynamic_sleep_features(base, suffix=name, **kwargs)
        total = f'mdsh_cumulative_total_{name}'
        trans = f'mdsh_transition_strict_{name}'
        complete = f'mdsh_complete_all3_{name}'

        for outcome in ['cvd', 'heart', 'stroke']:
            # Cumulative score association.
            from stage2_utils import fit_exposure_model
            try:
                _, tab = fit_exposure_model(d, outcome, total, f'{name}_cumulative_score')
                tab.insert(2, 'sensitivity_definition', name)
                tabs.append(tab)
                hit = tab[tab['term'] == total]
                if not hit.empty:
                    r = hit.iloc[0]
                    rows.append({
                        'analysis': 'alternative_score_definition', 'definition': name,
                        'outcome': outcome, 'exposure': 'cumulative_score_per_1point',
                        'HR': r['HR'], 'CI_low': r['CI_low'], 'CI_high': r['CI_high'],
                        'p_value': r['p_value'], 'n_people': r['n_people'], 'n_events': r['n_events'],
                        'n_sleep_complete': int((d[complete] == 1).sum()),
                    })
            except Exception as e:
                rows.append({'analysis': 'alternative_score_definition', 'definition': name, 'outcome': outcome, 'error': repr(e)})

            # Strict transition association.
            try:
                term = category_formula(trans, 'persistent unfavorable')
                _, tab = fit_exposure_model(d, outcome, term, f'{name}_transition')
                tab.insert(2, 'sensitivity_definition', name)
                tabs.append(tab)
                hit = tab[tab['term'].astype(str).str.contains(trans, regex=False)]
                for _, r in hit.iterrows():
                    rows.append({
                        'analysis': 'alternative_transition_definition', 'definition': name,
                        'outcome': outcome, 'exposure': r['term'],
                        'HR': r['HR'], 'CI_low': r['CI_low'], 'CI_high': r['CI_high'],
                        'p_value': r['p_value'], 'n_people': r['n_people'], 'n_events': r['n_events'],
                        'n_sleep_complete': int((d[complete] == 1).sum()),
                    })
            except Exception as e:
                rows.append({'analysis': 'alternative_transition_definition', 'definition': name, 'outcome': outcome, 'error': repr(e)})

    # ------------------------------------------------------------------
    # B. Three-year lag: exclude events first observed in 2018 and analyze
    #    only 2018-2020 among participants observed at both waves.
    # ------------------------------------------------------------------
    d = derive_dynamic_sleep_features(base)
    for outcome in ['cvd', 'heart', 'stroke']:
        for exposure, term_contains in [
            ('mdsh_cumulative_total', 'mdsh_cumulative_total'),
            ('mdsh_transition_strict', 'mdsh_transition_strict'),
        ]:
            try:
                if exposure == 'mdsh_transition_strict':
                    term = category_formula(exposure, 'persistent unfavorable')
                else:
                    term = exposure
                tab = fit_one_interval_lag(d, outcome, term, f'lag_2018_2020_{exposure}')
                tab.insert(2, 'sensitivity_definition', '3-year lag; observed 2018 and 2020; no wave-4 event')
                tabs.append(tab)
                hit = tab[tab['term'].astype(str).str.contains(term_contains, regex=False)]
                for _, r in hit.iterrows():
                    rows.append({
                        'analysis': 'three_year_lag', 'definition': '2018-2020 outcome only',
                        'outcome': outcome, 'exposure': r['term'],
                        'HR': r['HR'], 'CI_low': r['CI_low'], 'CI_high': r['CI_high'],
                        'p_value': r['p_value'], 'n_people': r['n_people'], 'n_events': r['n_events'],
                    })
            except Exception as e:
                rows.append({'analysis': 'three_year_lag', 'outcome': outcome, 'exposure': exposure, 'error': repr(e)})

    if tabs:
        pd.concat(tabs, ignore_index=True).to_csv(
            config.OUT_SENS / 'stage2_sensitivity_all_coefficients.csv', index=False, encoding='utf-8-sig'
        )
    summary = pd.DataFrame(rows)
    summary.to_csv(
        config.OUT_SENS / 'stage2_sensitivity_summary.csv', index=False, encoding='utf-8-sig'
    )

    print('Finished 10_sensitivity_analysis.py')
    print(summary.head(40).to_string(index=False))


if __name__ == '__main__':
    main()
