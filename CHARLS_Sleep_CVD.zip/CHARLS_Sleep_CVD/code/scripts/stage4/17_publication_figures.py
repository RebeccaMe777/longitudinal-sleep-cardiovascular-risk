from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import config
from stage4_utils import (
    ensure_stage4_dirs,
    STAGE4_TABLES,
    STAGE4_FIGURES,
    PRIMARY_MODEL_LABEL,
    CONSERVATIVE_MODEL_LABEL,
    OUTCOME_LABELS,
    forest_plot,
)


def parse_category(term: str):
    m = re.search(r'\[T\.([^\]]+)\]', str(term))
    return m.group(1) if m else ''


def figure_study_flow():
    path = config.OUT_COHORT / 'refined_sample_flow.csv'
    if not path.exists():
        return
    flow = pd.read_csv(path)
    label_col = flow.columns[0]
    n_col = flow.columns[1]
    fig, ax = plt.subplots(figsize=(9, 7))
    ax.axis('off')
    y_positions = np.linspace(0.90, 0.10, len(flow))
    for i, (_, r) in enumerate(flow.iterrows()):
        txt = f"{r[label_col]}\nN = {int(r[n_col]):,}"
        ax.text(
            0.5, y_positions[i], txt, ha='center', va='center', fontsize=10,
            bbox=dict(boxstyle='round,pad=0.55', fc='white', ec='black', lw=1.0)
        )
        if i < len(flow) - 1:
            ax.annotate('', xy=(0.5, y_positions[i+1] + 0.045),
                        xytext=(0.5, y_positions[i] - 0.045),
                        arrowprops=dict(arrowstyle='->', lw=1.0))
    ax.set_title('Study population flow', fontsize=13)
    fig.tight_layout()
    fig.savefig(STAGE4_FIGURES / 'Figure1_study_flow.png', dpi=300, bbox_inches='tight')
    fig.savefig(STAGE4_FIGURES / 'Figure1_study_flow.pdf', bbox_inches='tight')
    plt.close(fig)


def figure_cumulative_across_models(results):
    d = results[results['analysis'] == 'cumulative_score'].copy()
    d['label'] = d.apply(lambda r: f"{OUTCOME_LABELS.get(r.outcome, r.outcome)} — {r.model}", axis=1)
    forest_plot(
        d, 'label', STAGE4_FIGURES / 'Figure2_cumulative_MDSH_across_models',
        'Cumulative multidimensional sleep health and incident cardiovascular outcomes',
    )


def figure_favorable_waves(results):
    d = results[
        (results['analysis'] == 'favorable_wave_count_categorical') &
        (results['model'] == PRIMARY_MODEL_LABEL)
    ].copy()
    if d.empty:
        return
    d['wave_count'] = d['term'].map(parse_category).astype(float)
    fig, ax = plt.subplots(figsize=(7.4, 5.2))
    for outcome in ['cvd', 'heart', 'stroke']:
        x = d[d['outcome'] == outcome].sort_values('wave_count')
        if x.empty:
            continue
        wave = np.r_[0, x['wave_count'].to_numpy(float)]
        hr = np.r_[1.0, x['HR'].to_numpy(float)]
        lo = np.r_[1.0, x['CI_low'].to_numpy(float)]
        hi = np.r_[1.0, x['CI_high'].to_numpy(float)]
        ax.errorbar(wave, hr, yerr=[hr-lo, hi-hr], marker='o', capsize=3,
                    label=OUTCOME_LABELS[outcome])
    ax.axhline(1.0, linestyle='--', linewidth=1)
    ax.set_xticks([0, 1, 2, 3])
    ax.set_xlabel('Number of waves with fully favorable multidimensional sleep health')
    ax.set_ylabel('Hazard ratio (95% CI)')
    ax.set_title('Persistence of favorable multidimensional sleep health')
    ax.legend(frameon=False)
    ax.grid(axis='y', alpha=0.2)
    fig.tight_layout()
    fig.savefig(STAGE4_FIGURES / 'Figure3_favorable_sleep_persistence.png', dpi=300, bbox_inches='tight')
    fig.savefig(STAGE4_FIGURES / 'Figure3_favorable_sleep_persistence.pdf', bbox_inches='tight')
    plt.close(fig)


def figure_transition(results):
    d = results[
        (results['analysis'] == 'transition') &
        (results['model'] == PRIMARY_MODEL_LABEL)
    ].copy()
    if d.empty:
        return
    d['transition'] = d['term'].map(parse_category)
    order = ['deteriorated', 'improved', 'persistent favorable']
    rows = []
    for outcome in ['cvd', 'heart', 'stroke']:
        for cat in order:
            hit = d[(d.outcome == outcome) & (d.transition == cat)]
            if hit.empty:
                continue
            r = hit.iloc[0].copy()
            r['label'] = f"{OUTCOME_LABELS[outcome]} — {cat}"
            rows.append(r)
    if rows:
        forest_plot(pd.DataFrame(rows), 'label', STAGE4_FIGURES / 'Figure4_sleep_transition',
                    'Change in multidimensional sleep health from 2011 to 2015')


def figure_leave_one_out():
    p = config.OUTPUT_DIR / '06_stage3' / '11_model_specification' / 'stage3_model_specification_summary.csv'
    if not p.exists():
        return
    d = pd.read_csv(p)
    d = d[d['analysis'] == 'leave_one_component_out'].copy()
    if d.empty:
        return
    label_map = {
        'full_3component_per_1SD': 'Full 3-component score',
        'without_duration_per_1SD': 'Without sleep duration',
        'without_nap_per_1SD': 'Without nap',
        'without_restless_sleep_per_1SD': 'Without restless sleep',
    }
    d['label'] = d.apply(
        lambda r: f"{OUTCOME_LABELS.get(r.outcome, r.outcome)} — {label_map.get(r.exposure, r.exposure)}", axis=1
    )
    forest_plot(d, 'label', STAGE4_FIGURES / 'FigureS1_leave_one_component_out',
                'Leave-one-component-out analysis (per 1-SD healthier score)')


def figure_sensitivity_summary():
    paths = {
        'MI': config.OUTPUT_DIR / '06_stage3' / '12_multiple_imputation' / 'stage3_multiple_imputation_pooled_summary.csv',
        'Attrition IPW': config.OUTPUT_DIR / '06_stage3' / '13_weighting' / 'stage3_weighted_sensitivity_summary.csv',
        'Temporal/death': config.OUTPUT_DIR / '06_stage3' / '14_temporal_death' / 'stage3_temporal_death_sensitivity_summary.csv',
    }
    rows = []
    for source, p in paths.items():
        if not p.exists():
            continue
        d = pd.read_csv(p)
        if source == 'MI':
            x = d[(d['analysis'] == 'MI_cumulative_score_per_1point') & (d['outcome'] == 'cvd')]
            for _, r in x.iterrows():
                rows.append({'label': 'Multiple imputation', 'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high})
        elif source == 'Attrition IPW':
            x = d[(d['outcome'] == 'cvd') & (d['exposure'] == 'cumulative_score_per_1point')]
            for _, r in x.iterrows():
                rows.append({'label': str(r['analysis']), 'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high})
        else:
            x = d[(d['outcome'] == 'cvd') & (d['exposure'] == 'cumulative_score')]
            for _, r in x.iterrows():
                rows.append({'label': str(r['analysis']), 'HR': r.HR, 'CI_low': r.CI_low, 'CI_high': r.CI_high})
    if rows:
        forest_plot(pd.DataFrame(rows), 'label', STAGE4_FIGURES / 'FigureS2_sensitivity_summary',
                    'Sensitivity analyses for cumulative MDSH and incident CVD')


def main():
    ensure_stage4_dirs()
    p = STAGE4_TABLES / 'Table2_final_primary_models_long.csv'
    if not p.exists():
        raise FileNotFoundError(f'{p} not found. Run 16_final_primary_tables.py first.')
    results = pd.read_csv(p)
    figure_study_flow()
    figure_cumulative_across_models(results)
    figure_favorable_waves(results)
    figure_transition(results)
    figure_leave_one_out()
    figure_sensitivity_summary()
    print('Finished 17_publication_figures.py')


if __name__ == '__main__':
    main()
