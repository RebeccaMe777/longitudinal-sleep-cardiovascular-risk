"""Reviewer 2: account for intermediate (2013) sleep-health status in endpoint transitions.

Uses three-wave fully observed 2011/2013/2015 MDSH status. U = unfavorable
(not all three criteria met) and F = fully favorable (all three met).
Eight ordered patterns (e.g., FUF) are fitted, without changing the published
four-category 2011->2015 endpoint transition analysis.

On the IDENTICAL Model-2 complete-case person-period sample, compare:
  reduced: 2011/2015 endpoints (4 categories) + interval + core covariates
  full:    2011/2013/2015 pattern (8 categories) + interval + core covariates

Nested likelihood-ratio test evaluates whether 2013 status contributes additional
model fit conditional on both endpoints. Participant-clustered robust SEs are
used for trajectory HRs and pairwise 2013 F vs U contrasts within endpoint
categories. The interval-length log offset is handled by fit_cloglog.

Example from project root:
  python code/scripts/stage4/25_three_wave_transition_sensitivity.py \\
    --input output/01_cohort/analysis_cohort_personlevel.csv
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from patsy import dmatrices

SCRIPT = Path(__file__).resolve()
for parent in (SCRIPT.parent, *SCRIPT.parents):
    if (parent / 'analysis_utils.py').is_file() and (parent / 'stage2_utils.py').is_file():
        sys.path.insert(0, str(parent))
        break
else:
    raise FileNotFoundError('Expected analysis_utils.py and stage2_utils.py in project code folder')

import config
from analysis_utils import (make_person_period, fit_cloglog, lr_test,
                            _patsy_compatible_copy)
from stage2_utils import derive_dynamic_sleep_features
from stage3_utils import CORE_CONFOUNDER_COVARIATES

YEARS = (2011, 2013, 2015)
PATTERNS = ('UUU','UUF','UFU','UFF','FUU','FUF','FFU','FFF')
ENDPOINTS = ('UU','UF','FU','FF')
OUTCOMES = ('cvd','heart','stroke')
PREFIX = 'C(trajectory_3wave, Treatment(reference="UUU"))'
CORE = ' + '.join(CORE_CONFOUNDER_COVARIATES)


def make_statuses(d):
    d = derive_dynamic_sleep_features(d)
    d = d.loc[d['mdsh_complete_all3'].eq(1)].copy()
    codes = []
    for year in YEARS:
        v = d[f'mdsh_favorable_strict_{year}']
        if not v.notna().all():
            raise AssertionError('3-wave complete sample contains unknown favorable status')
        codes.append(v.astype(int).map({0:'U',1:'F'}))
    d['trajectory_3wave'] = codes[0] + codes[1] + codes[2]
    d['transition_2endpoints'] = codes[0] + codes[2]
    if not set(d['trajectory_3wave'].unique()).issubset(PATTERNS):
        raise AssertionError('Unrecognized 3-wave trajectory codes')
    d['trajectory_3wave'] = pd.Categorical(d['trajectory_3wave'], categories=PATTERNS)
    d['transition_2endpoints'] = pd.Categorical(d['transition_2endpoints'], categories=ENDPOINTS)
    return d


def _term(pattern):
    return f'{PREFIX}[T.{pattern}]'


def _pair_contrast(res, pattern_f, pattern_u):
    # log(HR) for 2013 F relative to 2013 U, within fixed 2011/2015 endpoints.
    contrast = np.zeros(len(res.params), dtype=float)
    names = list(res.params.index)
    for code, sign in ((pattern_f, +1.0),(pattern_u, -1.0)):
        if code != 'UUU':
            contrast[names.index(_term(code))] += sign
    beta = float(contrast @ res.params.to_numpy())
    cov = np.asarray(res.cov_params())
    se = float(np.sqrt(contrast @ cov @ contrast))
    from scipy import stats
    p = float(2.0*stats.norm.sf(abs(beta/se))) if se > 0 else np.nan
    return float(np.exp(beta)), float(np.exp(beta - 1.95996398454*se)), float(np.exp(beta + 1.95996398454*se)), p


def run_one(d, outcome):
    pp = make_person_period(d, outcome)
    form_full = f'event ~ C(interval) + {PREFIX} + {CORE}'
    form_reduced = f'event ~ C(interval) + C(transition_2endpoints, Treatment(reference="UU")) + {CORE}'
    # A single complete-case sample is determined before fitting both models.
    model_pp = _patsy_compatible_copy(pp)
    _, X = dmatrices(form_full, model_pp, return_type='dataframe', NA_action='drop')
    used = model_pp.loc[X.index].copy()
    if used['ID'].isna().any() or used['log_interval_years'].isna().any():
        raise AssertionError('Missing ID or interval offset in model sample')
    if used['ID'].nunique() != len(used.drop_duplicates('ID')):
        raise AssertionError('Unexpected duplicate IDs')
    fit_f = fit_cloglog(form_full, used, robust=True)
    fit_f_ml = fit_cloglog(form_full, used, robust=False)
    fit_r_ml = fit_cloglog(form_reduced, used, robust=False)
    fit_r = fit_cloglog(form_reduced, used, robust=True)
    if fit_f.nobs != fit_f_ml.nobs or fit_f.nobs != fit_r_ml.nobs or fit_f.nobs != len(used):
        raise AssertionError('Full and endpoint-only models did not use identical rows')
    test = lr_test(fit_r_ml, fit_f_ml)
    if test['df'] != 4:
        raise AssertionError('Expected 4 additional parameters (8 vs 4 categories)')

    people = used.drop_duplicates('ID')
    counts = (people.groupby('trajectory_3wave', observed=False)
              .agg(n_people=('ID','size'), n_events=(f'incident_{outcome}','sum'))
              .reindex(PATTERNS))
    if (counts['n_people'] < 20).any():
        raise RuntimeError(f'Small trajectory group for {outcome}: {counts.to_dict()}')
    est = []
    for pat in PATTERNS:
        rec = counts.loc[pat]
        if pat == 'UUU':
            hr,lo,hi,p = 1.0, 1.0, 1.0, np.nan
        else:
            term = _term(pat)
            ci = fit_f.conf_int().loc[term]
            hr,lo,hi,p = (float(np.exp(fit_f.params[term])),float(np.exp(ci.iloc[0])),
                          float(np.exp(ci.iloc[1])),float(fit_f.pvalues[term]))
        est.append({
            'outcome':outcome,'three_wave_pattern':pat,
            'pattern_expansion': ' -> '.join(('fully favorable' if c=='F' else 'not fully favorable') for c in pat),
            'endpoint_transition':pat[0]+pat[2],
            'n_people':int(rec.n_people),'n_events':int(rec.n_events),
            'observed_event_percent':100.0*float(rec.n_events)/int(rec.n_people),
            'HR_vs_UUU':hr,'CI_low':lo,'CI_high':hi,'p_value':p,
            'adjustment':'Model 2: core confounders',
        })
    pair_records=[]
    for s in ('U','F'):
        for e in ('U','F'):
            pu=s+'U'+e
            pf=s+'F'+e
            hr,lo,hi,p = _pair_contrast(fit_f, pf, pu)
            pair_records.append({
                'outcome':outcome,'endpoint_transition':s+e,
                'comparison':pf+' vs '+pu+' (2013 F vs U)',
                '2013_favorable_pattern':pf,'2013_unfavorable_pattern':pu,
                'HR':hr,'CI_low':lo,'CI_high':hi,'p_value':p,
                'n_people_favorable_2013':int(counts.loc[pf,'n_people']),
                'n_people_unfavorable_2013':int(counts.loc[pu,'n_people']),
            })
    # Endpoint-only estimates, refitted on the exact same three-wave sample.
    endpoint_counts = (people.groupby('transition_2endpoints', observed=False)
                       .agg(n_people=('ID','size'), n_events=(f'incident_{outcome}','sum'))
                       .reindex(ENDPOINTS))
    endpoint_rows=[]
    for ep in ENDPOINTS:
        if ep=='UU':
            hr,lo,hi,p=1.0,1.0,1.0,np.nan
        else:
            name=f'C(transition_2endpoints, Treatment(reference="UU"))[T.{ep}]'
            ci=fit_r.conf_int().loc[name]
            hr,lo,hi,p=(float(np.exp(fit_r.params[name])),float(np.exp(ci.iloc[0])),
                        float(np.exp(ci.iloc[1])),float(fit_r.pvalues[name]))
        endpoint_rows.append({'outcome':outcome,'endpoint_transition':ep,
            'n_people':int(endpoint_counts.loc[ep,'n_people']),
            'n_events':int(endpoint_counts.loc[ep,'n_events']),
            'HR_vs_UU':hr,'CI_low':lo,'CI_high':hi,'p_value':p})
    summary = {
        'outcome':outcome,'n_people':int(people['ID'].nunique()),
        'n_events':int(used['event'].sum()),'n_person_period_rows':int(len(used)),
        'endpoint_only_4_categories_logLik':float(fit_r_ml.llf),
        'full_3wave_8_categories_logLik':float(fit_f_ml.llf),
        '3wave_vs_endpoints_LR_statistic':test['LR'],'LR_df':test['df'],
        'LR_p_value':test['p_value'],
        'interpretation':'Additional fit of 2013 fully favorable status conditional on 2011/2015 endpoints',
    }
    return summary, est, pair_records, endpoint_rows


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',type=Path,default=config.OUT_COHORT/'analysis_cohort_personlevel.csv')
    parser.add_argument('--output-dir',type=Path,default=config.OUTPUT_DIR/'08_targeted_sensitivity'/'three_wave_trajectory')
    args=parser.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True)
    person = pd.read_csv(args.input,low_memory=False)
    if person['ID'].duplicated().any():
        raise AssertionError('Input is not person-level: IDs are duplicated')
    d=make_statuses(person)
    records=[]; rows=[]; pairrows=[]; endpoint_rows=[]
    for outcome in OUTCOMES:
        s,r,p,e=run_one(d,outcome)
        records.append(s); rows.extend(r); pairrows.extend(p); endpoint_rows.extend(e)
    pd.DataFrame(records).to_csv(args.output_dir/'three_wave_vs_endpoint_model2_LR.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(rows).to_csv(args.output_dir/'eight_trajectories_model2.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(pairrows).to_csv(args.output_dir/'intermediate_2013_within_endpoints_model2.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(endpoint_rows).to_csv(args.output_dir/'endpoint_transitions_same_sample_model2.csv',index=False,encoding='utf-8-sig')
    print('Three-wave complete people:',len(d))
    print(pd.DataFrame(records)[['outcome','n_people','n_events','3wave_vs_endpoints_LR_statistic','LR_df','LR_p_value']].to_string(index=False))
    print('CVD 8 trajectory categories:')
    print(pd.DataFrame(rows).query('outcome=="cvd"')[['three_wave_pattern','n_people','n_events','HR_vs_UUU','CI_low','CI_high']].to_string(index=False))
    print('CVD within-endpoints 2013 contrasts:')
    print(pd.DataFrame(pairrows).query('outcome=="cvd"')[['comparison','HR','CI_low','CI_high','p_value']].to_string(index=False))
    print('Saved results to:',args.output_dir)

if __name__=='__main__':
    main()
