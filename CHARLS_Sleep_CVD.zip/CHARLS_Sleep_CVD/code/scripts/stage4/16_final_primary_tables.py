from __future__ import annotations

import pandas as pd

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))

import config
from stage2_utils import (
    read_person_cohort,
    derive_dynamic_sleep_features,
    fit_exposure_model,
    category_formula,
)
from stage4_utils import (
    ensure_stage4_dirs,
    STAGE4_TABLES,
    PRIMARY_MODEL_LABEL,
    CONSERVATIVE_MODEL_LABEL,
    OUTCOME_LABELS,
    ADJUSTMENT_SETS,
    event_rate_table,
    format_hr_ci,
    format_p,
)


MODEL_SETS = {
    PRIMARY_MODEL_LABEL: ADJUSTMENT_SETS[PRIMARY_MODEL_LABEL],
    CONSERVATIVE_MODEL_LABEL: ADJUSTMENT_SETS[CONSERVATIVE_MODEL_LABEL],
}


def selected_rows(
    tab: pd.DataFrame,
    term_contains: str,
    analysis: str,
    exposure: str,
    model_label: str,
):
    hit = tab[tab["term"].astype(str).str.contains(term_contains, regex=False)].copy()
    rows = []
    for _, r in hit.iterrows():
        rows.append({
            "analysis": analysis,
            "outcome": r["outcome"],
            "model": model_label,
            "exposure": exposure,
            "term": r["term"],
            "HR": r["HR"],
            "CI_low": r["CI_low"],
            "CI_high": r["CI_high"],
            "p_value": r["p_value"],
            "n_people": r["n_people"],
            "n_events": r["n_events"],
            "n_interval_rows": r.get("n_interval_rows", pd.NA),
        })
    return rows


def fit_publication_models(d: pd.DataFrame):
    rows = []
    all_tabs = []

    exposure_specs = [
        (
            "cumulative_score",
            "mdsh_cumulative_total",
            "mdsh_cumulative_total",
            "MDSH cumulative score, per +1 point",
        ),
        (
            "favorable_wave_count_categorical",
            category_formula("mdsh_n_favorable_strict_waves", 0),
            "mdsh_n_favorable_strict_waves",
            "Number of fully favorable waves (ref=0)",
        ),
        (
            "favorable_wave_count_trend",
            "mdsh_n_favorable_strict_waves",
            "mdsh_n_favorable_strict_waves",
            "Per additional fully favorable wave",
        ),
        (
            "transition",
            category_formula("mdsh_transition_strict", "persistent unfavorable"),
            "mdsh_transition_strict",
            "2011-2015 multidimensional sleep transition",
        ),
        (
            "continuous_change",
            "mdsh_delta_2015_2011 + mdsh_score_2011",
            "mdsh_delta_2015_2011",
            "MDSH score change, per +1 point; adjusted for 2011 score",
        ),
    ]

    for outcome in ["cvd", "heart", "stroke"]:
        for model_label, covariates in MODEL_SETS.items():
            for analysis, exposure_term, term_filter, exposure_label in exposure_specs:
                _, tab = fit_exposure_model(
                    d,
                    outcome,
                    exposure_term,
                    model_name=f"final_{model_label}",
                    covariates=list(covariates),
                )
                tab = tab.copy()
                tab.insert(2, "analysis", analysis)
                tab.insert(3, "adjustment_model", model_label)
                all_tabs.append(tab)
                rows.extend(
                    selected_rows(
                        tab,
                        term_filter,
                        analysis,
                        exposure_label,
                        model_label,
                    )
                )
    return pd.DataFrame(rows), pd.concat(all_tabs, ignore_index=True)


def main():
    ensure_stage4_dirs()
    cohort = read_person_cohort()
    d = derive_dynamic_sleep_features(cohort)

    results, all_coefficients = fit_publication_models(d)

    if results.empty:
        raise RuntimeError("No publication model results were generated.")

    results.to_csv(
        STAGE4_TABLES / "Table2_final_primary_models_long.csv",
        index=False,
        encoding="utf-8-sig",
    )
    all_coefficients.to_csv(
        STAGE4_TABLES / "Table2_all_models_all_coefficients.csv",
        index=False,
        encoding="utf-8-sig",
    )

    compact = results[
        (results["analysis"] == "cumulative_score")
        | (
            (results["analysis"] == "transition")
            & results["term"].astype(str).str.contains("persistent favorable", regex=False)
        )
    ].copy()
    compact["Outcome"] = compact["outcome"].map(OUTCOME_LABELS)
    compact["Effect"] = compact["analysis"].map({
        "cumulative_score": "Cumulative MDSH, per +1 point",
        "transition": "Persistent favorable vs persistent unfavorable",
    })
    compact["HR (95% CI)"] = [
        format_hr_ci(a, b, c)
        for a, b, c in zip(compact.HR, compact.CI_low, compact.CI_high)
    ]
    compact["P"] = compact["p_value"].map(format_p)
    compact[
        ["Outcome", "Effect", "model", "HR (95% CI)", "P", "n_people", "n_events"]
    ].to_csv(
        STAGE4_TABLES / "Table2_manuscript_compact.csv",
        index=False,
        encoding="utf-8-sig",
    )

    event_tabs = []
    for outcome in ["cvd", "heart", "stroke"]:
        for exposure in ["mdsh_n_favorable_strict_waves", "mdsh_transition_strict"]:
            event_tabs.append(event_rate_table(d, exposure, outcome))
    pd.concat(event_tabs, ignore_index=True).to_csv(
        STAGE4_TABLES / "key_dynamic_sleep_observed_event_rates.csv",
        index=False,
        encoding="utf-8-sig",
    )

    results[results["model"] == PRIMARY_MODEL_LABEL].to_csv(
        STAGE4_TABLES / "primary_core_confounder_results.csv",
        index=False,
        encoding="utf-8-sig",
    )
    results[results["model"] == CONSERVATIVE_MODEL_LABEL].to_csv(
        STAGE4_TABLES / "conservative_extended_results.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("Finished 16_final_primary_tables.py")
    print("Both publication adjustment sets were refitted from the same cohort.")
    print("Primary inferential model:", PRIMARY_MODEL_LABEL)
    print("Conservative extended model:", CONSERVATIVE_MODEL_LABEL)
    print(
        compact[["Outcome", "Effect", "model", "HR (95% CI)", "P"]]
        .to_string(index=False)
    )


if __name__ == "__main__":
    main()
