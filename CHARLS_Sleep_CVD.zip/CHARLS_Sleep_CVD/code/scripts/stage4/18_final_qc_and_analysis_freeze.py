from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import json
import pandas as pd

import config
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features
from stage4_utils import (
    ensure_stage4_dirs,
    STAGE4_QC,
    PRIMARY_MODEL_LABEL,
    CONSERVATIVE_MODEL_LABEL,
)


def main():
    ensure_stage4_dirs()
    d = derive_dynamic_sleep_features(read_person_cohort())

    metrics = {
        'primary_landmark_cohort_n': int(len(d)),
        'three_wave_MDSH_complete_n': int((d['mdsh_complete_all3'] == 1).sum()),
        'incident_cvd_n': int(d['incident_cvd'].fillna(0).sum()),
        'incident_heart_n': int(d['incident_heart'].fillna(0).sum()),
        'incident_stroke_n': int(d['incident_stroke'].fillna(0).sum()),
        'death_known_flag_n': int(pd.to_numeric(d.get('death_known', pd.Series(index=d.index, dtype=float)), errors='coerce').notna().sum()) if 'death_known' in d else 0,
        'death_year_nonmissing_n': int(pd.to_numeric(d.get('death_year', pd.Series(index=d.index, dtype=float)), errors='coerce').notna().sum()) if 'death_year' in d else 0,
        'survey_strata_nonmissing_n': int(pd.to_numeric(d.get('survey_strata', pd.Series(index=d.index, dtype=float)), errors='coerce').notna().sum()) if 'survey_strata' in d else 0,
    }
    pd.DataFrame([{'metric': k, 'value': v} for k, v in metrics.items()]).to_csv(
        STAGE4_QC / 'final_analysis_counts.csv', index=False, encoding='utf-8-sig'
    )

    decisions = [
        ('study_population', 'CHARLS participants aged >=45 years at 2011 with 2011/2013/2015 nighttime sleep data, CVD-free at 2015 landmark, and 2018 or 2020 follow-up'),
        ('exposure_window', '2011, 2013, 2015'),
        ('landmark', '2015'),
        ('follow_up', '2015 to 2018/2020'),
        ('primary_outcome', 'incident self-reported physician-diagnosed CVD = heart disease OR stroke'),
        ('secondary_outcomes', 'incident heart disease; incident stroke'),
        ('MDSH_duration_component', 'healthy if nighttime sleep 6-8 h/night, inclusive'),
        ('MDSH_nap_component', 'healthy if midday nap <=60 min/day'),
        ('MDSH_restless_component', 'healthy if restless-sleep frequency <=2 on harmonized 1-4 scale'),
        ('MDSH_wave_score', '0-3 low-risk components per wave'),
        ('MDSH_cumulative_score', 'sum of 2011+2013+2015 wave scores; range 0-9; complete all three waves required'),
        ('fully_favorable_wave', 'all 3 MDSH components low risk in that wave'),
        ('strict_transition', 'persistent unfavorable / improved / deteriorated / persistent favorable based on 2011 and 2015 fully-favorable status'),
        ('primary_model', 'grouped-time complementary log-log model with interval-length offset and participant-clustered robust SE'),
        ('primary_adjustment', PRIMARY_MODEL_LABEL),
        ('conservative_extended_adjustment', CONSERVATIVE_MODEL_LABEL),
        ('reason_for_adjustment_hierarchy', 'BMI, hypertension, diabetes and dyslipidemia may partly lie on the sleep-to-CVD pathway; extended model is therefore retained as conservative attenuation/sensitivity analysis rather than the sole etiologic model'),
        ('missing_covariates', '20 stochastic chained-equation multiple imputations with Rubin pooling as sensitivity analysis'),
        ('attrition', 'stabilized inverse-probability-of-follow-up weighting with 1st/99th percentile truncation'),
        ('survey_weighting', 'baseline survey-weight sensitivity clustered by PSU; no full strata-based complex-survey variance because survey_strata unavailable'),
        ('death_competing_risk', 'Fine-Gray not used because usable death timing is too sparse; known-death exclusion reported as sensitivity analysis'),
        ('RCS_role', 'supplementary; no evidence of nonlinearity in mean nighttime sleep-CVD association'),
        ('age_interaction_role', 'supplementary; no strong evidence of continuous age interaction'),
        ('ARV_role', 'secondary/supplementary long-term sleep instability analysis; no formal interaction evidence with mean sleep'),
        ('multiple_testing', 'primary hypotheses limited to cumulative MDSH and persistence/change; secondary component/outcome analyses interpreted with emphasis on effect sizes and consistency rather than isolated P values'),
    ]
    pd.DataFrame(decisions, columns=['item', 'frozen_specification']).to_csv(
        STAGE4_QC / 'final_analysis_specification.csv', index=False, encoding='utf-8-sig'
    )

    md = ['# Frozen statistical analysis specification', '']
    for item, text in decisions:
        md += [f'## {item}', text, '']
    md += ['## Analysis counts', '']
    for k, v in metrics.items():
        md.append(f'- {k}: {v:,}')
    (STAGE4_QC / 'final_analysis_specification.md').write_text('\n'.join(md), encoding='utf-8')

    # A small machine-readable status file makes reruns auditable.
    status = {
        'analysis_freeze_version': 'v0.5-stage4',
        'primary_model': PRIMARY_MODEL_LABEL,
        'conservative_model': CONSERVATIVE_MODEL_LABEL,
        'counts': metrics,
    }
    (STAGE4_QC / 'analysis_freeze_status.json').write_text(
        json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8'
    )

    print('Finished 18_final_qc_and_analysis_freeze.py')
    print(pd.DataFrame([{'metric': k, 'value': v} for k, v in metrics.items()]).to_string(index=False))


if __name__ == '__main__':
    main()
