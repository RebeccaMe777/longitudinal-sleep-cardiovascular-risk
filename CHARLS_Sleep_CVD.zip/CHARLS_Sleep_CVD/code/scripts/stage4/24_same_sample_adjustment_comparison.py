"""Reviewer 2 Major 4: distinguish covariate-adjustment and complete-case sample changes.

Run from any directory:
  python 24_same_sample_adjustment_comparison.py --input path/to/analysis_cohort_personlevel.csv

Implements the existing 2015 landmark grouped-time cloglog estimator with the same
person-period construction, interval-length offset, and participant-clustered SEs
as the publication scripts. The same-sample comparison fits Model 2 and Model 3
to precisely the Model-3 complete-case participant set for each outcome.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
import pandas as pd

CODE_ROOT = Path(__file__).resolve().parent
# When placed in code/scripts/stage4, find the code root; also support standalone
# use beside an extracted CHARLS project.
for candidate in (CODE_ROOT, CODE_ROOT.parent, CODE_ROOT.parent.parent):
    if (candidate / 'stage2_utils.py').exists() and (candidate / 'stage3_utils.py').exists():
        sys.path.insert(0, str(candidate))
        CODE_ROOT = candidate
        break
else:
    raise ImportError('Cannot locate stage2_utils.py and stage3_utils.py; place this script in code/scripts/stage4/.')

from stage2_utils import derive_dynamic_sleep_features, fit_exposure_model
from stage3_utils import CORE_CONFOUNDER_COVARIATES, EXTENDED_RISK_FACTOR_COVARIATES
import config


def extract(res, tab, name):
    v = tab.loc[tab.term == 'mdsh_cumulative_total']
    if len(v) != 1:
        raise ValueError('Missing MDSH cumulative coefficient')
    r = v.iloc[0]
    return dict(compare=name, HR=float(r.HR), CI_low=float(r.CI_low),
                CI_high=float(r.CI_high), p_value=float(r.p_value),
                n_people=int(r.n_people), n_events=int(r.n_events),
                n_person_period_rows=int(r.n_interval_rows))


def analyze(cohort):
    d = derive_dynamic_sleep_features(cohort)
    all_rows = []
    for outcome in ('cvd', 'heart', 'stroke'):
        res2_full, tab2_full = fit_exposure_model(
            d, outcome, 'mdsh_cumulative_total', 'Model2_original_full',
            covariates=CORE_CONFOUNDER_COVARIATES)
        res3_full, tab3_full = fit_exposure_model(
            d, outcome, 'mdsh_cumulative_total', 'Model3_original',
            covariates=EXTENDED_RISK_FACTOR_COVARIATES)
        used_rows = res3_full.model.data.row_labels
        model3_ids = set(res3_full.model.data.frame.loc[used_rows, 'ID'].tolist())
        matched = d.loc[d['ID'].isin(model3_ids)].copy()
        res2_matched, tab2_matched = fit_exposure_model(
            matched, outcome, 'mdsh_cumulative_total', 'Model2_matched_to_Model3',
            covariates=CORE_CONFOUNDER_COVARIATES)
        x = [extract(res2_full,tab2_full,'Model 2: original complete cases'),
             extract(res2_matched,tab2_matched,'Model 2: Model-3 same-sample'),
             extract(res3_full,tab3_full,'Model 3: Model-3 complete cases')]
        for r in x: r['outcome']=outcome
        assert x[1]['n_people']==x[2]['n_people'], (outcome,x)
        assert x[1]['n_events']==x[2]['n_events'], (outcome,x)
        all_rows.extend(x)
    return pd.DataFrame(all_rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input',type=Path, default=config.OUT_COHORT/'analysis_cohort_personlevel.csv')
    ap.add_argument('--output',type=Path, default=config.OUTPUT_DIR/'08_targeted_sensitivity'/'same_sample_model2_model3.csv')
    args=ap.parse_args()
    d=pd.read_csv(args.input,low_memory=False)
    result=analyze(d)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output,index=False,encoding='utf-8-sig')
    print(result[['outcome','compare','HR','CI_low','CI_high','n_people','n_events']].to_string(index=False))
    print(f'Output: {args.output}')
if __name__=='__main__':main()
