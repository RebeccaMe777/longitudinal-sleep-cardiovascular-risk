"""Reviewer 2 Major 3: shape check of cumulative multidimensional sleep health.

Uses the same 2015-landmark cohort and Model 2 core adjustments as the primary
analysis. Tests a quadratic departure from a per-point linear term, on the
SAME complete-case person-period rows. As a descriptive robustness display,
reports grouped cumulative-score associations (0–3, 4–5, 6–7, 8–9).

The grouped categorical and linear score models are *not* nested; no LR test
between those models is valid. Nonlinearity is tested using the nested
linear vs linear+quadratic models. Four score categories are supplementary.
"""
from __future__ import annotations
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from patsy import dmatrices

SCRIPT_FILE = Path(__file__).resolve()
for candidate in (SCRIPT_FILE.parent, *SCRIPT_FILE.parents):
    if (candidate/'analysis_utils.py').is_file() and (candidate/'stage2_utils.py').is_file():
        if str(candidate) not in sys.path:
            sys.path.insert(0, str(candidate))
        break
else:
    raise FileNotFoundError('Place script inside a project containing analysis_utils.py/stage2_utils.py')

import config
from analysis_utils import make_person_period, fit_cloglog, lr_test, _patsy_compatible_copy
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features
from stage3_utils import CORE_CONFOUNDER_COVARIATES

OUT_DIR = config.OUTPUT_DIR/'08_targeted_sensitivity'/'mdsh_score_shape'
OUTCOMES = ('cvd', 'heart', 'stroke')
SCORE = 'mdsh_cumulative_total'
SCORE_CAT = 'mdsh_cumulative_group'
GROUPS = ['0-3', '4-5', '6-7', '8-9']
CORE = ' + '.join(CORE_CONFOUNDER_COVARIATES)


def _analyze(cohort, outcome):
    pp = make_person_period(cohort, outcome)
    pp['mdsh_centered'] = pp[SCORE] - 6
    pp['mdsh_centered_sq'] = pp['mdsh_centered'] ** 2
    pp[SCORE_CAT] = pd.cut(pp[SCORE], bins=[-0.5, 3.5, 5.5, 7.5, 9.5],
                           labels=GROUPS, ordered=True)
    lin = f'event ~ C(interval) + mdsh_centered + {CORE}'
    quad = f'event ~ C(interval) + mdsh_centered + mdsh_centered_sq + {CORE}'
    cat = f'event ~ C(interval) + C({SCORE_CAT}, Treatment(reference="0-3")) + {CORE}'

    # Build the most restrictive design to ensure all fits use identical rows.
    cleaned = _patsy_compatible_copy(pp)
    _, X = dmatrices(quad, cleaned, return_type='dataframe', NA_action='drop')
    used = cleaned.loc[X.index].copy()
    assert used[SCORE].notna().all()
    assert used[SCORE_CAT].notna().all()
    assert used['log_interval_years'].notna().all()

    linear_robust = fit_cloglog(lin, used, robust=True)
    linear_ml = fit_cloglog(lin, used, robust=False)
    quadratic_robust = fit_cloglog(quad, used, robust=True)
    quadratic_ml = fit_cloglog(quad, used, robust=False)
    grouped_robust = fit_cloglog(cat, used, robust=True)
    nested = lr_test(linear_ml, quadratic_ml)
    if linear_ml.nobs != quadratic_ml.nobs or linear_ml.nobs != grouped_robust.nobs:
        raise AssertionError('Models did not use the same person-period rows')
    if int(nested['df']) != 1:
        raise AssertionError('Quadratic vs linear should have one extra parameter')

    sample = used.drop_duplicates('ID')
    counts = (sample.groupby(SCORE_CAT, observed=True)
              .agg(n_people=('ID', 'size'), n_events=(f'incident_{outcome}', 'sum'))
              .reindex(GROUPS).reset_index())
    if counts['n_people'].isna().any() or (counts['n_people'] < 10).any():
        raise RuntimeError('Empty or too-small score group; reassess category edges')
    n_people = used['ID'].nunique()
    n_events = int(used['event'].sum())
    score_results = {
        'outcome': outcome,
        'n_people': int(n_people), 'n_events': n_events,
        'n_person_period_rows': int(len(used)),
        'linear_per_point_HR': float(np.exp(linear_robust.params['mdsh_centered'])),
        'linear_CI_low': float(np.exp(linear_robust.conf_int().loc['mdsh_centered',0])),
        'linear_CI_high': float(np.exp(linear_robust.conf_int().loc['mdsh_centered',1])),
        'linear_p': float(linear_robust.pvalues['mdsh_centered']),
        'quadratic_beta': float(quadratic_robust.params['mdsh_centered_sq']),
        'quadratic_robust_wald_p': float(quadratic_robust.pvalues['mdsh_centered_sq']),
        'quadratic_vs_linear_LR': nested['LR'],
        'quadratic_vs_linear_LR_df': nested['df'],
        'quadratic_vs_linear_LR_p': nested['p_value'],
        'score_min': int(sample[SCORE].min()),
        'score_max': int(sample[SCORE].max()),
    }

    group_data = []
    for _, row in counts.iterrows():
        group = str(row[SCORE_CAT])
        term = f'C({SCORE_CAT}, Treatment(reference="0-3"))[T.{group}]'
        if group == '0-3':
            hr, lower, upper, pval = (1., 1., 1., np.nan)
        else:
            if term not in grouped_robust.params.index:
                raise KeyError(term)
            ci = grouped_robust.conf_int().loc[term]
            hr,lower,upper,pval = (
                float(np.exp(grouped_robust.params[term])),
                float(np.exp(ci.iloc[0])),float(np.exp(ci.iloc[1])),
                float(grouped_robust.pvalues[term]),
            )
        group_data.append({
            'outcome': outcome, 'mdsh_score_group': group,
            'n_people': int(row.n_people), 'n_events': int(row.n_events),
            'observed_event_pct': round(100*row.n_events/row.n_people, 4),
            'adjusted_HR_vs_0_3': hr, 'CI_low': lower, 'CI_high': upper,
            'p_value': pval,
            'adjustment': 'Model 2 (core confounders)',
        })
    return score_results, group_data


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    d = derive_dynamic_sleep_features(read_person_cohort())
    d = d.loc[d['mdsh_complete_all3'].eq(1)].copy()
    summary, categorical = [], []
    for outcome in OUTCOMES:
        res, cat = _analyze(d, outcome)
        summary.append(res)
        categorical.extend(cat)
    pd.DataFrame(summary).to_csv(OUT_DIR/'score_shape_model2_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(categorical).to_csv(OUT_DIR/'score_group_model2_estimates.csv', index=False, encoding='utf-8-sig')
    print('Completed linear-vs-quadratic MDSH score test')
    print(pd.DataFrame(summary)[['outcome','n_people','n_events','linear_per_point_HR','quadratic_robust_wald_p','quadratic_vs_linear_LR_p']].to_string(index=False))
    print(pd.DataFrame(categorical).to_string(index=False))
    print('Output:', OUT_DIR)

if __name__ == '__main__':
    main()
