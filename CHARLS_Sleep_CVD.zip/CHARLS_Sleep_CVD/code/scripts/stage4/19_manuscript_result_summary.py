from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))


import pandas as pd

from stage4_utils import (
    ensure_stage4_dirs,
    STAGE4_TABLES,
    STAGE4_QC,
    PRIMARY_MODEL_LABEL,
    CONSERVATIVE_MODEL_LABEL,
    OUTCOME_LABELS,
    format_hr_ci,
    format_p,
)


def pick(df, analysis, outcome, model, term_contains=None):
    x = df[(df.analysis == analysis) & (df.outcome == outcome) & (df.model == model)].copy()
    if term_contains is not None:
        x = x[x.term.astype(str).str.contains(term_contains, regex=False)]
    return x.iloc[0] if not x.empty else None


def line(label, r):
    if r is None:
        return f'- {label}: unavailable'
    return f"- {label}: HR {r.HR:.3f} (95% CI {r.CI_low:.3f}-{r.CI_high:.3f}), P {format_p(r.p_value)}, N={int(r.n_people):,}, events={int(r.n_events):,}."


def main():
    ensure_stage4_dirs()
    p = STAGE4_TABLES / 'Table2_final_primary_models_long.csv'
    if not p.exists():
        raise FileNotFoundError(f'{p} not found. Run 16_final_primary_tables.py first.')
    d = pd.read_csv(p)

    out = ['# Manuscript-facing result summary', '',
           'This file is generated directly from the frozen Stage-4 models and is intended as a numerical drafting aid.', '',
           f'Primary inferential model: **{PRIMARY_MODEL_LABEL}**.',
           f'Conservative extended adjustment: **{CONSERVATIVE_MODEL_LABEL}**.', '']

    for model in [PRIMARY_MODEL_LABEL, CONSERVATIVE_MODEL_LABEL]:
        out += [f'## {model}', '']
        for outcome in ['cvd', 'heart', 'stroke']:
            out += [f'### {OUTCOME_LABELS[outcome]}']
            out.append(line('Cumulative MDSH per +1 point', pick(d, 'cumulative_score', outcome, model, 'mdsh_cumulative_total')))
            out.append(line('Per additional fully favorable wave', pick(d, 'favorable_wave_count_trend', outcome, model, 'mdsh_n_favorable_strict_waves')))
            out.append(line('Persistent favorable vs persistent unfavorable', pick(d, 'transition', outcome, model, 'persistent favorable')))
            out.append(line('Improved vs persistent unfavorable', pick(d, 'transition', outcome, model, '[T.improved]')))
            out.append(line('Deteriorated vs persistent unfavorable', pick(d, 'transition', outcome, model, '[T.deteriorated]')))
            out.append(line('MDSH change per +1 point (2015-2011)', pick(d, 'continuous_change', outcome, model, 'mdsh_delta_2015_2011')))
            out.append('')

    (STAGE4_QC / 'manuscript_result_summary.md').write_text('\n'.join(out), encoding='utf-8')
    print('Finished 19_manuscript_result_summary.py')


if __name__ == '__main__':
    main()
