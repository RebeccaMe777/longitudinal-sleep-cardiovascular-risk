"""Reviewer 2 Major Comment 2: pre-2015 sleep-exposure sensitivity.

Sensitivity exposure = mdsh_score_2011 + mdsh_score_2013 (0–6). The 2015
wave is used ONLY to establish the CVD-free landmark, not as a sleep exposure.
Outcomes are first reported in 2018/2020. Uses the published core-confounder
(Model 2) covariates and the existing grouped-time cloglog model implementation.

Run from code/scripts/stage4, or place with core utility modules and run it.
"""
from __future__ import annotations

from pathlib import Path
import sys
import numpy as np
import pandas as pd

# Compatible with both `code/scripts/stage4/` and a flat `code/` layout.
SCRIPT_FILE = Path(__file__).resolve()
for candidate in (SCRIPT_FILE.parent, *SCRIPT_FILE.parents):
    if (candidate / 'stage2_utils.py').is_file() and (candidate / 'analysis_utils.py').is_file():
        if str(candidate) not in sys.path:
            sys.path.insert(0, str(candidate))
        break
else:
    raise FileNotFoundError('Cannot locate stage2_utils.py and analysis_utils.py; place this script inside the existing code project.')

import config
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features, fit_exposure_model
from stage3_utils import CORE_CONFOUNDER_COVARIATES

OUT = config.OUTPUT_DIR / '08_targeted_sensitivity' / 'pre2015_sleep_exposure'
OUTCOMES = ('cvd', 'heart', 'stroke')
EXPOSURE = 'mdsh_cumulative_2011_2013'


def _prepare(cohort: pd.DataFrame) -> pd.DataFrame:
    d = derive_dynamic_sleep_features(cohort)
    # Require both wave scores fully observed; never treat missing as 0.
    d[EXPOSURE] = d[['mdsh_score_2011', 'mdsh_score_2013']].sum(axis=1, min_count=2)
    assert d[EXPOSURE].dropna().between(0, 6).all()
    # The 2015 sleep score must NOT be present in the model formula below.
    return d


def _run_one(d: pd.DataFrame, outcome: str, sample: str):
    result, tab = fit_exposure_model(
        cohort=d,
        outcome=outcome,
        exposure_term=EXPOSURE,
        model_name=f'pre2015_two_wave_{sample}_core_model2',
        covariates=CORE_CONFOUNDER_COVARIATES,
        robust=True,
    )
    row = tab.loc[tab['term'].eq(EXPOSURE)]
    if len(row) != 1:
        raise RuntimeError(f'Expected exactly one exposure coefficient for {outcome}, {sample}; got {len(row)}')
    r = row.iloc[0]
    if 'mdsh_score_2015' in str(tab['formula'].iloc[0]):
        raise RuntimeError('2015 sleep exposure was inadvertently included in this sensitivity model.')
    output = {
        'outcome': outcome,
        'sample': sample,
        'exposure': '2011+2013 cumulative MDSH, per 1-point increase (range 0–6)',
        'adjustment': 'Model 2: core confounders',
        'landmark': 'CVD-free at 2015',
        'followup': '2018 and/or 2020',
        'HR': float(r.HR),
        'CI_low': float(r.CI_low),
        'CI_high': float(r.CI_high),
        'p_value': float(r.p_value),
        'n_people': int(r.n_people),
        'n_events': int(r.n_events),
        'n_interval_rows': int(r.n_interval_rows),
        'sample_n_before_covariate_and_outcome_exclusion': int(len(d)),
        'formula': str(r['formula']),
    }
    return output, tab


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    d = _prepare(read_person_cohort())
    # Group A: all who have 2011 and 2013 fully observed, independent of 2015 sleep availability.
    two_wave = d[d[EXPOSURE].notna()].copy()
    # Group B: fixed three-wave-complete sleep sample for direct comparability to main analysis.
    same_sample = d[d['mdsh_complete_all3'].eq(1) & d[EXPOSURE].notna()].copy()
    if two_wave.empty or same_sample.empty:
        raise RuntimeError('No eligible participants: inspect 2011/2013 sleep variable coding.')

    records, coefficients = [], []
    for outcome in OUTCOMES:
        for name, subset in [('two_wave_available', two_wave), ('three_wave_complete', same_sample)]:
            rec, table = _run_one(subset, outcome, name)
            records.append(rec)
            coefficients.append(table)

    pd.DataFrame(records).to_csv(OUT / 'pre2015_two_wave_model2_results.csv', index=False, encoding='utf-8-sig')
    pd.concat(coefficients, ignore_index=True).to_csv(OUT / 'pre2015_two_wave_model2_all_coefficients.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame([
        {'group': '2015 disease-free eligible cohort', 'N': len(d)},
        {'group': '2011 and 2013 MDSH complete', 'N': len(two_wave)},
        {'group': '2011, 2013 and 2015 MDSH complete (comparability subset)', 'N': len(same_sample)},
    ]).to_csv(OUT / 'pre2015_two_wave_sample_flow.csv', index=False, encoding='utf-8-sig')
    (OUT / 'README.md').write_text('''# Pre-2015 two-wave sleep sensitivity\n\nExposure is the sum of wave-specific 2011 and 2013 MDSH (0–6).\n2015 sleep data are excluded from this exposure. The 2015 CVD-free landmark and\n2018/2020 incident outcomes are unchanged.\n\n`two_wave_available` uses all participants with observed 2011 and 2013 MDSH;\n`three_wave_complete` restricts to the original three-wave-complete sleep group\nfor comparison with the primary three-wave analysis. Each model uses complete\nModel 2 covariates and an observed outcome. Sample sizes may therefore differ\nslightly between the analytic groups and across outcomes.\n\nReported effects are HRs per 1 point of a 0–6 two-wave score; these estimates\nshould not be compared numerically as if their scale and exposure window were\nidentical to the primary 0–9 three-wave score.\n\nThis analysis checks the association using older sleep assessments and does\nnot eliminate subclinical-disease confounding or prove causation.\n''', encoding='utf-8')
    print('Finished pre-2015 sleep-exposure sensitivity')
    print(pd.DataFrame(records)[['outcome','sample','n_people','n_events','HR','CI_low','CI_high','p_value']].to_string(index=False))
    print('Output:', OUT)


if __name__ == '__main__':
    main()
