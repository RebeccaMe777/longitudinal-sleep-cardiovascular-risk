from __future__ import annotations

from pathlib import Path
import sys
CODE_ROOT = Path(__file__).resolve().parents[2]
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))

import numpy as np
import pandas as pd
from patsy import dmatrices

import config
from analysis_utils import make_person_period, fit_cloglog, exponentiated_table, lr_test
from stage2_utils import read_person_cohort, derive_dynamic_sleep_features
from stage3_utils import CORE_CONFOUNDER_COVARIATES


OUT_DIR = config.OUTPUT_DIR / "09_incremental_value"
OUTCOMES = ("cvd", "heart", "stroke")


def _fit_exposure_rows(result, model_name: str, outcome: str, terms: list[str]) -> pd.DataFrame:
    table = exponentiated_table(result, model_name, outcome)
    table = table[table["term"].isin(terms)].copy()
    return table


def _wald_joint_early_waves(result) -> dict:
    """Robust joint Wald test for the 2011 and 2013 coefficients."""
    constraint = "mdsh_score_2011 = 0, mdsh_score_2013 = 0"
    test = result.wald_test(constraint, scalar=True)
    statistic = float(np.asarray(test.statistic).squeeze())
    p_value = float(np.asarray(test.pvalue).squeeze())
    df_num = getattr(test, "df_num", 2)
    try:
        df_num = float(np.asarray(df_num).squeeze())
    except Exception:
        df_num = 2.0
    return {
        "joint_test": "2011 and 2013 MDSH coefficients jointly equal zero",
        "wald_chi2": statistic,
        "df": df_num,
        "p_value": p_value,
    }


def _common_person_period(cohort: pd.DataFrame, outcome: str) -> pd.DataFrame:
    """Create identical complete-case rows for the nested single- vs three-wave models."""
    pp = make_person_period(cohort, outcome)
    if pp.empty:
        return pp

    full_formula = (
        "event ~ C(interval) + mdsh_score_2011 + mdsh_score_2013 + mdsh_score_2015"
        + " + " + " + ".join(CORE_CONFOUNDER_COVARIATES)
    )
    _, design = dmatrices(full_formula, pp, return_type="dataframe", NA_action="drop")
    if design.empty:
        return pp.iloc[0:0].copy()
    common = pp.loc[design.index].copy()
    common = common.sort_index()
    return common


def _fit_one_outcome(d: pd.DataFrame, outcome: str):
    pp = _common_person_period(d, outcome)
    if pp.empty:
        raise RuntimeError(f"No complete person-period records for outcome={outcome}.")

    covariates = " + ".join(CORE_CONFOUNDER_COVARIATES)
    single_formula = (
        "event ~ C(interval) + mdsh_score_2015 + " + covariates
    )
    repeated_formula = (
        "event ~ C(interval) + mdsh_score_2011 + mdsh_score_2013"
        " + mdsh_score_2015 + " + covariates
    )
    cumulative_formula = (
        "event ~ C(interval) + mdsh_cumulative_total + " + covariates
    )

    # Robust fits provide the reported HRs and confidence intervals.
    single_robust = fit_cloglog(single_formula, pp, robust=True)
    repeated_robust = fit_cloglog(repeated_formula, pp, robust=True)
    cumulative_robust = fit_cloglog(cumulative_formula, pp, robust=True)

    # Non-robust likelihood fits are used for the nested likelihood-ratio test.
    # All fits use the exact same person-period records.
    single_ml = fit_cloglog(single_formula, pp, robust=False)
    repeated_ml = fit_cloglog(repeated_formula, pp, robust=False)
    if int(single_ml.nobs) != int(repeated_ml.nobs):
        raise RuntimeError(
            f"Nested models used different numbers of interval records for {outcome}: "
            f"{single_ml.nobs} vs {repeated_ml.nobs}"
        )
    lrt = lr_test(single_ml, repeated_ml)

    single_rows = _fit_exposure_rows(
        single_robust, "2015 single-wave MDSH", outcome, ["mdsh_score_2015"]
    )
    repeated_rows = _fit_exposure_rows(
        repeated_robust,
        "Three-wave MDSH entered separately",
        outcome,
        ["mdsh_score_2011", "mdsh_score_2013", "mdsh_score_2015"],
    )
    cumulative_rows = _fit_exposure_rows(
        cumulative_robust,
        "Three-wave cumulative MDSH",
        outcome,
        ["mdsh_cumulative_total"],
    )
    coefficients = pd.concat(
        [single_rows, repeated_rows, cumulative_rows], ignore_index=True
    )
    # exponentiated_table already supplies the outcome column.
    coefficients["n_people"] = int(pp["ID"].nunique())
    coefficients["n_events"] = int(pp["event"].sum())
    coefficients["n_interval_rows"] = int(len(pp))

    k_single = len(single_ml.params)
    k_repeated = len(repeated_ml.params)
    comparison = {
        "outcome": outcome,
        "comparison": "2015 single-wave vs 2011+2013+2015 entered separately",
        "n_people": int(pp["ID"].nunique()),
        "n_events": int(pp["event"].sum()),
        "n_interval_rows": int(len(pp)),
        "single_log_likelihood": float(single_ml.llf),
        "repeated_log_likelihood": float(repeated_ml.llf),
        "single_AIC": float(-2 * single_ml.llf + 2 * k_single),
        "repeated_AIC": float(-2 * repeated_ml.llf + 2 * k_repeated),
        "single_BIC": float(-2 * single_ml.llf + np.log(single_ml.nobs) * k_single),
        "repeated_BIC": float(-2 * repeated_ml.llf + np.log(repeated_ml.nobs) * k_repeated),
        "delta_AIC_repeated_minus_single": float(
            (-2 * repeated_ml.llf + 2 * k_repeated) - (-2 * single_ml.llf + 2 * k_single)
        ),
        "delta_BIC_repeated_minus_single": float(
            (-2 * repeated_ml.llf + np.log(repeated_ml.nobs) * k_repeated)
            - (-2 * single_ml.llf + np.log(single_ml.nobs) * k_single)
        ),
        "same_analytic_sample": True,
        "LR_chi2": lrt["LR"],
        "LR_df": lrt["df"],
        "LR_p_value": lrt["p_value"],
        "interpretation": (
            "Nested likelihood-ratio test of whether adding 2011 and 2013 MDSH "
            "scores improves fit beyond the 2015 score, on the same complete-case sample."
        ),
    }

    joint = _wald_joint_early_waves(repeated_robust)
    joint.update({
        "outcome": outcome,
        "n_people": int(pp["ID"].nunique()),
        "n_events": int(pp["event"].sum()),
        "n_interval_rows": int(len(pp)),
        "interpretation": (
            "Cluster-robust joint Wald test of the 2011 and 2013 MDSH coefficients "
            "conditional on the 2015 MDSH score and core covariates."
        ),
    })
    return coefficients, comparison, joint


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    cohort = derive_dynamic_sleep_features(read_person_cohort())

    # Restrict all comparisons to participants with complete MDSH scores at all 3 waves.
    complete = cohort.loc[cohort["mdsh_complete_all3"].eq(1)].copy()
    if complete.empty:
        raise RuntimeError(
            "No participants have complete MDSH scores at all 3 waves. "
            "Check the harmonized sleep variables and MDSH derivation."
        )

    coefficient_tables = []
    comparison_rows = []
    joint_rows = []
    flow_rows = [{
        "step": "2015 landmark cohort",
        "n_people": int(len(cohort)),
    }, {
        "step": "Complete MDSH scores at 2011, 2013, and 2015",
        "n_people": int(len(complete)),
    }]

    for outcome in OUTCOMES:
        coef, comparison, joint = _fit_one_outcome(complete, outcome)
        coefficient_tables.append(coef)
        comparison_rows.append(comparison)
        joint_rows.append(joint)

    pd.concat(coefficient_tables, ignore_index=True).to_csv(
        OUT_DIR / "incremental_value_coefficients.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(comparison_rows).to_csv(
        OUT_DIR / "incremental_value_model_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(joint_rows).to_csv(
        OUT_DIR / "incremental_value_joint_wald_tests.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(flow_rows).to_csv(
        OUT_DIR / "incremental_value_sample_flow.csv",
        index=False,
        encoding="utf-8-sig",
    )

    note = """# Incremental value analysis

## Purpose
Compare a single 2015 MDSH assessment with repeated 2011, 2013, and 2015 MDSH assessments.

## Models
- Model A: 2015 MDSH score only, plus the prespecified Model 2 core covariates.
- Model B: 2011, 2013, and 2015 MDSH scores entered simultaneously, plus the same covariates.
- Descriptive comparator: cumulative 2011+2013+2015 MDSH score, plus the same covariates.

## Comparability
All models for a given outcome use the same person-period records, restricted to participants with complete MDSH scores at all three exposure waves and complete data for the full Model B formula. This ensures that the nested model comparison is not driven by different analytic samples.

## Primary incremental tests
- Likelihood-ratio test: Model A versus Model B.
- Cluster-robust joint Wald test: coefficients for the 2011 and 2013 MDSH scores jointly equal zero, conditional on the 2015 score.

## Interpretation
These analyses assess incremental association information and model fit. They do not, by themselves, establish improved clinical prediction or causal effects.
"""
    (OUT_DIR / "incremental_value_analysis_notes.md").write_text(note, encoding="utf-8")

    print("Finished incremental value analysis.")
    print(pd.DataFrame(comparison_rows).to_string(index=False))
    print(pd.DataFrame(joint_rows).to_string(index=False))


if __name__ == "__main__":
    main()
