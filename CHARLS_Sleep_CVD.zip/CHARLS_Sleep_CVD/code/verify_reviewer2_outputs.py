"""Sanity-check key counts and reviewer-specific outputs against v0.2 reference.

This is a consistency check, not an independent validation of CHARLS harmonization,
individual event adjudication or causal identification.
"""
from __future__ import annotations

from pathlib import Path
import sys
import pandas as pd

CODE_ROOT = Path(__file__).resolve().parent
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))
import config


def read_csv(relative: str) -> pd.DataFrame:
    p = config.OUTPUT_DIR / relative
    if not p.is_file():
        raise FileNotFoundError(f"Missing {p}. Run: python code/run_pipeline.py --stage reviewer2")
    return pd.read_csv(p)


def require(expr: bool, msg: str) -> None:
    if not expr:
        raise AssertionError(msg)
    print(f"PASS: {msg}")


def check_outcome_sample(df: pd.DataFrame, outcome: str, n: int, events: int, name: str) -> pd.Series:
    rows = df.loc[df['outcome'].eq(outcome)]
    require(len(rows) == 1, f"{name}: exactly one {outcome} row")
    r = rows.iloc[0]
    require(int(r['n_people']) == n and int(r['n_events']) == events,
            f"{name}: {outcome} N={n}, events={events}")
    return r


def main():
    print('Checking outputs in:', config.OUTPUT_DIR)
    flow = read_csv('01_cohort/refined_sample_flow.csv')
    expected = [17708, 17060, 10868, 8784, 8277, 7991]
    require(flow['n'].astype(int).tolist() == expected,
            'Sequential cohort counts: ' + ' → '.join(map(str, expected)))
    require(flow['excluded_since_previous_step'].astype(int).tolist() == [0, 648, 6192, 2084, 507, 286],
            'Sequential exclusions match Figure 1')

    inc = read_csv('09_incremental_value/incremental_value_model_comparison.csv')
    check_outcome_sample(inc, 'cvd', 7973, 1464, 'Incremental comparison')
    require(float(inc.loc[inc.outcome.eq('cvd'), 'LR_p_value'].iloc[0]) < 0.01,
            'Incremental comparison: CVD LR p<0.01')

    two = read_csv('08_targeted_sensitivity/pre2015_sleep_exposure/pre2015_two_wave_model2_results.csv')
    main_two = two.loc[two['sample'].eq('three_wave_complete')].copy()
    r = check_outcome_sample(main_two, 'cvd', 7973, 1464, 'Pre-2015 two-wave')
    require(0.85 < float(r['HR']) < 0.98, 'Pre-2015 CVD HR within expected reference range')

    shape = read_csv('08_targeted_sensitivity/mdsh_score_shape/score_shape_model2_summary.csv')
    check_outcome_sample(shape, 'cvd', 7973, 1464, 'Cumulative-score shape')
    require(float(shape.loc[shape.outcome.eq('cvd'), 'quadratic_vs_linear_LR_p'].iloc[0]) > 0.05,
            'Cumulative score CVD quadratic LR test reported')

    same = read_csv('08_targeted_sensitivity/same_sample_model2_model3.csv')
    match = same.loc[same['compare'].eq('Model 3: Model-3 complete cases')]
    check_outcome_sample(match, 'cvd', 6838, 1259, 'Model 3 matched-sample')

    trajectories = read_csv('08_targeted_sensitivity/three_wave_trajectory/three_wave_vs_endpoint_model2_LR.csv')
    check_outcome_sample(trajectories, 'cvd', 7973, 1464, 'Three-wave trajectories')
    require(int(trajectories.loc[trajectories.outcome.eq('cvd'), 'LR_df'].iloc[0]) == 4,
            'Eight-pattern vs four-endpoint comparison has 4 extra parameters')

    print('\nALL CHECKS PASSED — reviewer-specific output sanity checks only.')
    print('Full pipeline, input harmonization and manuscript table/figure audit still require separate review.')


if __name__ == '__main__':
    main()
