from __future__ import annotations
import subprocess
import sys
from pathlib import Path
CODE_ROOT = Path(__file__).resolve().parent
SCRIPT = CODE_ROOT / "scripts" / "stage4" / "21_incremental_value_analysis.py"
subprocess.run([sys.executable, str(SCRIPT)], cwd=CODE_ROOT, check=True)
