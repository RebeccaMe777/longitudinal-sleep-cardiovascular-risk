from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

CODE_ROOT = Path(__file__).resolve().parent
SCRIPTS = CODE_ROOT / "scripts"


def run_group(group: str, names: list[str]) -> None:
    for name in names:
        script = SCRIPTS / group / name
        if not script.is_file():
            raise FileNotFoundError(script)
        print("\n" + "=" * 88, flush=True)
        print(f"RUNNING: {group}/{name}", flush=True)
        print("=" * 88, flush=True)
        subprocess.run([sys.executable, str(script)], cwd=CODE_ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description="Run the CHARLS sleep-CVD analysis pipeline.")
    parser.add_argument(
        "--stage",
        choices=["stage1", "stage2", "stage3", "stage4", "reviewer2", "all"],
        default="all",
        help="Analysis stage to run (default: all).",
    )
    parser.add_argument(
        "--include-physical-activity",
        action="store_true",
        help="Also run the optional physical-activity sensitivity analysis.",
    )
    args = parser.parse_args()

    stages = {
        "stage1": [
            "01_prepare_analysis_cohort.py",
            "02_descriptive_table1.py",
            "03_primary_models.py",
            "04_rcs_age_effect.py",
            "05_variability_joint_analysis.py",
        ],
        "stage2": [
            "06_persistence_analysis.py",
            "07_sleep_change_analysis.py",
            "08_multidimensional_sleep_score.py",
            "09_interaction_and_subtype_analysis.py",
            "10_sensitivity_analysis.py",
        ],
        "stage3": [
            "11_model_specification_leave_one_out.py",
            "12_multiple_imputation.py",
            "13_attrition_and_survey_weighting.py",
            "14_temporal_and_death_sensitivity.py",
            "15_stage3_summary.py",
        ],
        "stage4": [
            "21_incremental_value_analysis.py",
            "22_pre2015_exposure_sensitivity.py",
            "23_score_form_sensitivity.py",
            "24_same_sample_adjustment_comparison.py",
            "25_three_wave_transition_sensitivity.py",
            "16_final_primary_tables.py",
            "17_publication_figures.py",
            "18_final_qc_and_analysis_freeze.py",
            "19_manuscript_result_summary.py",
        ],
    }

    if args.stage == "reviewer2":
        # Rebuild the authoritative 2015-landmark cohort, then check the five
        # analyses added specifically in response to Reviewer 2.
        run_group("stage1", ["01_prepare_analysis_cohort.py"])
        run_group("stage4", [
            "21_incremental_value_analysis.py",
            "22_pre2015_exposure_sensitivity.py",
            "23_score_form_sensitivity.py",
            "24_same_sample_adjustment_comparison.py",
            "25_three_wave_transition_sensitivity.py",
        ])
    else:
        selected = list(stages) if args.stage == "all" else [args.stage]
        for stage in selected:
            run_group(stage, stages[stage])

    if args.include_physical_activity:
        script = SCRIPTS / "targeted" / "20_physical_activity_sensitivity.py"
        print("\n" + "=" * 88, flush=True)
        print(f"RUNNING: targeted/{script.name}", flush=True)
        print("=" * 88, flush=True)
        subprocess.run([sys.executable, str(script)], cwd=CODE_ROOT, check=True)

    print("\nRequested analysis stages completed.", flush=True)


if __name__ == "__main__":
    main()
