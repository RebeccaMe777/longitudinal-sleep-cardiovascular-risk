from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats

import config


def find_harmonized_file() -> Path:
    """Resolve the intended harmonized dataset without silently selecting an old version.

    Priority:
      1) SLEEP_CVD_DATA_FILE (explicit full path);
      2) exact SLEEP_CVD_DATA_FILENAME in DATA_DIR;
      3) a unique v0.2 file matching DATA_GLOB.

    If multiple v0.2 files exist, the user must select one explicitly.
    No automatic fallback to v0.1 is permitted.
    """
    explicit = str(getattr(config, "DATA_FILE", "") or "").strip()
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"SLEEP_CVD_DATA_FILE does not exist: {path}")
        return path

    exact = config.DATA_DIR / config.DATA_FILENAME
    if exact.is_file():
        return exact
    if getattr(config, "DATA_FILENAME_EXPLICIT", False):
        raise FileNotFoundError(
            "The explicitly configured SLEEP_CVD_DATA_FILENAME was not found: "
            f"{exact}"
        )

    files = sorted(config.DATA_DIR.glob(config.DATA_GLOB))
    if len(files) == 1:
        return files[0]
    if len(files) > 1:
        names = "\n".join(f"  - {p.name}" for p in files)
        raise RuntimeError(
            "Multiple harmonized v0.2 files were found. Set "
            "SLEEP_CVD_DATA_FILENAME or SLEEP_CVD_DATA_FILE to select the intended file:\n"
            f"{names}"
        )

    legacy = sorted(config.DATA_DIR.glob("charls_sleep_cvd_harmonized*.csv"))
    legacy_note = ""
    if legacy:
        legacy_note = (
            "\nOther harmonized CSV files were found, but none matched the configured "
            "v0.2 pattern:\n" + "\n".join(f"  - {p.name}" for p in legacy)
        )
    raise FileNotFoundError(
        f"No harmonized v0.2 CSV found in {config.DATA_DIR}. "
        f"Expected {config.DATA_GLOB!r}. "
        "Place the v0.2 file in the data folder or set SLEEP_CVD_DATA_FILE."
        + legacy_note
    )


def read_harmonized() -> tuple[pd.DataFrame, Path]:
    path = find_harmonized_file()
    df = pd.read_csv(path, low_memory=False)
    return df, path


def require_columns(df: pd.DataFrame, cols: Iterable[str], where: str = '') -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        loc = f' in {where}' if where else ''
        raise KeyError(f'Missing required columns{loc}: {missing}')


def mode_or_nan(s: pd.Series):
    x = s.dropna()
    if x.empty:
        return np.nan
    return x.mode().iloc[0]


def derive_cesd9_from_total(cesd10: pd.Series, restless_sleep: pd.Series) -> pd.Series:
    """
    CHARLS restless_sleep is harmonized to 1..4 corresponding to CES-D item score 0..3.
    Therefore CESD9_without_sleep = CESD10 - (restless_sleep - 1).
    Invalid values are set to missing.
    """
    out = pd.to_numeric(cesd10, errors='coerce') - (
        pd.to_numeric(restless_sleep, errors='coerce') - 1.0
    )
    out = out.where(out.between(0, 27))
    return out


def validate_cesd9_reconstruction(df: pd.DataFrame) -> dict:
    need = {'wave', 'cesd10', 'restless_sleep', 'CESD9_without_sleep'}
    if not need.issubset(df.columns):
        return {'available': False, 'reason': 'required columns missing'}
    check = df[df['wave'] == 5].copy()
    calc = derive_cesd9_from_total(check['cesd10'], check['restless_sleep'])
    mask = calc.notna() & check['CESD9_without_sleep'].notna()
    if mask.sum() == 0:
        return {'available': False, 'reason': 'no overlapping non-missing wave-5 values'}
    diff = calc.loc[mask] - check.loc[mask, 'CESD9_without_sleep']
    return {
        'available': True,
        'n_compared': int(mask.sum()),
        'n_exact': int((diff.abs() < 1e-12).sum()),
        'pct_exact': float((diff.abs() < 1e-12).mean() * 100),
        'max_abs_difference': float(diff.abs().max()),
    }


def build_person_level_cohort(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build the prespecified 2011-2015 exposure / 2015 landmark cohort."""
    required = [
        'ID', 'wave', 'iwy', 'age', 'gender_harmonized', 'marry_harmonized',
        'rural', 'edu', 'smoken', 'drinkl', 'bmi_harmonized', 'hibpe_1',
        'diabe_1', 'dyslipe', 'srh', 'adlab_c', 'iadl', 'cesd10',
        'restless_sleep', 'nap', 'night_sleep', 'landmark_sleep3_complete',
        'baseline_cvd_2015', 'observed_wave4', 'observed_wave5',
        'incident_cvd', 'incident_heart', 'incident_stroke',
        'first_cvd_event_wave', 'first_heart_event_wave', 'first_stroke_event_wave',
        'exp_mean_night_sleep', 'exp_sd_night_sleep', 'exp_cv_night_sleep',
        'exp_arv_night_sleep', 'exp_mean_nap_minutes', 'exp_mean_restless_sleep',
    ]
    require_columns(df, required, 'harmonized data')

    # One row per participant per wave has already been QC'd, but we defensively enforce it.
    wave1 = df[df['wave'] == 1].sort_values('ID').drop_duplicates('ID').copy()
    wave3 = df[df['wave'] == 3].sort_values('ID').drop_duplicates('ID').copy()

    baseline_vars = [
        'ID', 'age', 'gender_harmonized', 'marry_harmonized', 'rural', 'edu',
        'smoken', 'drinkl', 'bmi_harmonized', 'waist_harmonized_cm',
        'systo', 'diasto', 'hibpe_1', 'diabe_1', 'dyslipe', 'srh',
        'adlab_c', 'iadl', 'cesd10', 'restless_sleep', 'hhcperc',
        'retire', 'ins', 'survey_psu', 'survey_ind_weight',
    ]
    baseline_vars += [f'act_{i}' for i in range(1, 9)]
    baseline_vars = [c for c in baseline_vars if c in wave1.columns]
    b11 = wave1[baseline_vars].copy()
    b11 = b11.rename(columns={c: f'b11_{c}' for c in b11.columns if c != 'ID'})

    landmark_vars = [
        'ID', 'age', 'landmark_sleep3_complete', 'baseline_cvd_2015',
        'landmark_basic_eligible', 'observed_wave4', 'observed_wave5',
        'incident_cvd', 'incident_heart', 'incident_stroke',
        'first_cvd_event_wave', 'first_heart_event_wave', 'first_stroke_event_wave',
        'last_observed_wave', 'death_known', 'death_year', 'death_month',
        'survey_ind_weight', 'survey_psu',
        'exp_mean_night_sleep', 'exp_sd_night_sleep', 'exp_cv_night_sleep',
        'exp_arv_night_sleep', 'exp_mean_nap_minutes', 'exp_mean_restless_sleep',
    ]
    landmark_vars = [c for c in landmark_vars if c in wave3.columns]
    lm = wave3[landmark_vars].copy().rename(columns={'age': 'age_2015'})

    cohort = lm.merge(b11, on='ID', how='left', validate='one_to_one')

    # Add raw 2011/2013/2015 sleep dimensions in wide form.
    sleep_long = df[df['wave'].isin(config.EXPOSURE_WAVES)][
        ['ID', 'wave', 'night_sleep', 'nap', 'restless_sleep']
    ].copy()
    year_map = {1: 2011, 2: 2013, 3: 2015}
    sleep_long['year'] = sleep_long['wave'].map(year_map)
    for var in ['night_sleep', 'nap', 'restless_sleep']:
        wide = sleep_long.pivot(index='ID', columns='year', values=var)
        wide.columns = [f'{var}_{int(y)}' for y in wide.columns]
        cohort = cohort.merge(wide.reset_index(), on='ID', how='left', validate='one_to_one')

    # Refined inclusion criteria.
    cohort['has_followup_2018_or_2020'] = (
        (cohort['observed_wave4'] == 1) | (cohort['observed_wave5'] == 1)
    ).astype(int)

    # Sequential counts used in Figure 1. Apply the age restriction FIRST,
    # consistently with the final cohort filter. The original implementation
    # counted 3-wave sleep/CVD/follow-up before age restriction, yielding the
    # misleading 11,203 -> 9,069 -> 8,553 sequence.
    age_ok = cohort['b11_age'].ge(config.AGE_MIN_WAVE1)
    night_ok = cohort['landmark_sleep3_complete'].eq(1)
    cvd_free = cohort['baseline_cvd_2015'].eq(0)
    followup_ok = cohort['has_followup_2018_or_2020'].eq(1)

    n_start = int(len(wave1))
    n_age = int((wave1['age'] >= config.AGE_MIN_WAVE1).sum())
    n_night = int((age_ok & night_ok).sum())
    n_cvd_free = int((age_ok & night_ok & cvd_free).sum())
    n_followup = int((age_ok & night_ok & cvd_free & followup_ok).sum())
    cvd_prevalent = int((age_ok & night_ok & cohort['baseline_cvd_2015'].eq(1)).sum())
    cvd_missing = int((age_ok & night_ok & cohort['baseline_cvd_2015'].isna()).sum())
    if n_night - n_cvd_free != cvd_prevalent + cvd_missing:
        raise AssertionError('Unexpected CVD-status values in landmark exclusions')

    cohort = cohort[age_ok & night_ok & cvd_free & followup_ok].copy()
    if len(cohort) != n_followup:
        raise AssertionError('Sequential flow and final cohort counts disagree')

    # All night-duration values are complete here. The remaining domains
    # (daytime naps and restless sleep) determine the final 3-wave MDSH sample.
    mdsh_extra_cols = [
        f'{v}_{year}'
        for year in (2011, 2013, 2015)
        for v in ('nap', 'restless_sleep')
    ]
    mdsh_complete = cohort[mdsh_extra_cols].notna().all(axis=1)
    n_mdsh = int(mdsh_complete.sum())
    flow_rows = [
        ('2011 initial CHARLS participants', n_start, 0, ''),
        ('2011 age >=45', n_age, n_start - n_age, 'Age <45 years or missing baseline age'),
        ('Three-wave nighttime sleep-duration complete (2011, 2013, 2015)',
         n_night, n_age - n_night, 'Incomplete nighttime sleep-duration assessments'),
        ('CVD-free at the 2015 landmark', n_cvd_free, n_night - n_cvd_free,
         f'Prevalent CVD: {cvd_prevalent}; unknown CVD status: {cvd_missing}'),
        ('Follow-up available in 2018 or 2020', n_followup, n_cvd_free - n_followup,
         'No follow-up in 2018 or 2020'),
        ('Complete multidimensional sleep health in all three waves',
         n_mdsh, n_followup - n_mdsh,
         'Missing nap duration or restless sleep data'),
    ]
    flow = pd.DataFrame(
        flow_rows,
        columns=['sample_flow_step', 'n', 'excluded_since_previous_step', 'exclusion_reason'],
    )

    # Reconstruct CESD-9 from total CESD-10 and the harmonized restless-sleep item.
    cohort['b11_cesd9_derived'] = derive_cesd9_from_total(
        cohort['b11_cesd10'], cohort['b11_restless_sleep']
    )
    cohort['b11_cesd9_derivation_flag'] = np.where(
        cohort['b11_cesd9_derived'].notna(),
        'derived_CESD10_minus_restless_item',
        'missing',
    )

    # Baseline social participation count (0-8), used only in extended/sensitivity models.
    act_cols = [f'b11_act_{i}' for i in range(1, 9) if f'b11_act_{i}' in cohort.columns]
    if act_cols:
        cohort['b11_social_activity_count'] = cohort[act_cols].sum(axis=1, min_count=1)

    # Useful transforms.
    if 'b11_hhcperc' in cohort.columns:
        cohort['b11_log_hhcperc'] = np.log1p(cohort['b11_hhcperc'].where(cohort['b11_hhcperc'] >= 0))
    cohort['mean_nap_30min'] = cohort['exp_mean_nap_minutes'] / 30.0

    # Candidate / exploratory sleep categories. These are NOT the primary exposure definition.
    xmean = cohort['exp_mean_night_sleep']
    cohort['candidate_mean_night_sleep_cat'] = np.select(
        [
            xmean < config.SHORT_SLEEP_H,
            (xmean >= config.SHORT_SLEEP_H) & (xmean <= config.LONG_SLEEP_H),
            xmean > config.LONG_SLEEP_H,
        ],
        [
            f'<{config.SHORT_SLEEP_H:g} h',
            f'{config.SHORT_SLEEP_H:g}-{config.LONG_SLEEP_H:g} h',
            f'>{config.LONG_SLEEP_H:g} h',
        ],
        default=None,
    )

    ns_cols = [f'night_sleep_{y}' for y in (2011, 2013, 2015)]
    rs_cols = [f'restless_sleep_{y}' for y in (2011, 2013, 2015)]
    cohort['n_short_sleep_waves_candidate'] = (cohort[ns_cols] < config.SHORT_SLEEP_H).sum(axis=1)
    cohort['n_long_sleep_waves_candidate'] = (cohort[ns_cols] > config.LONG_SLEEP_H).sum(axis=1)
    cohort['n_poor_restless_waves_candidate'] = (
        cohort[rs_cols] >= config.RESTLESS_POOR_THRESHOLD
    ).sum(axis=1)
    cohort['persistent_short_sleep_candidate'] = (cohort['n_short_sleep_waves_candidate'] >= 2).astype(int)
    cohort['persistent_long_sleep_candidate'] = (cohort['n_long_sleep_waves_candidate'] >= 2).astype(int)
    cohort['persistent_restless_sleep_candidate'] = (cohort['n_poor_restless_waves_candidate'] >= 2).astype(int)

    return cohort, flow


def make_person_period(cohort: pd.DataFrame, outcome: str) -> pd.DataFrame:
    """
    Create interval records for grouped-time survival analysis.

    Intervals:
      - 2015->2018: 3 years when wave 4 observed
      - 2018->2020: 2 years when wave 4 event-free and wave 5 observed
      - 2015->2020: 5 years when wave 4 missing but wave 5 observed

    The 5-year skipped-wave interval is retained and explicitly labelled; a later
    sensitivity analysis can exclude these records.
    """
    if outcome not in {'cvd', 'heart', 'stroke'}:
        raise ValueError('outcome must be cvd, heart, or stroke')
    outcome_col = f'incident_{outcome}'
    event_wave_col = f'first_{outcome}_event_wave'
    require_columns(cohort, [outcome_col, event_wave_col, 'observed_wave4', 'observed_wave5'])

    src = cohort[cohort[outcome_col].notna()].copy()
    rows = []
    for d in src.to_dict(orient='records'):
        obs4 = d.get('observed_wave4') == 1
        obs5 = d.get('observed_wave5') == 1
        evwave = d.get(event_wave_col)

        if obs4:
            r = d.copy()
            r.update({
                'outcome_name': outcome,
                'interval': '2015-2018',
                'interval_start_wave': 3,
                'interval_end_wave': 4,
                'interval_years': 3.0,
                'event': int(evwave == 4),
            })
            rows.append(r)
            if evwave == 4:
                continue
            if obs5:
                r = d.copy()
                r.update({
                    'outcome_name': outcome,
                    'interval': '2018-2020',
                    'interval_start_wave': 4,
                    'interval_end_wave': 5,
                    'interval_years': 2.0,
                    'event': int(evwave == 5),
                })
                rows.append(r)
        elif obs5:
            r = d.copy()
            r.update({
                'outcome_name': outcome,
                'interval': '2015-2020',
                'interval_start_wave': 3,
                'interval_end_wave': 5,
                'interval_years': 5.0,
                'event': int(evwave == 5),
            })
            rows.append(r)

    pp = pd.DataFrame(rows)
    if pp.empty:
        return pp
    pp['log_interval_years'] = np.log(pp['interval_years'])
    return pp


def _patsy_compatible_copy(data: pd.DataFrame) -> pd.DataFrame:
    """Return a copy with pandas extension dtypes converted for patsy/statsmodels.

    Patsy (used by statsmodels formula API) does not reliably accept pandas
    extension dtypes such as ``string[python]`` and nullable ``boolean``/``Int64``.
    Converting these here keeps all formula-based models stable while preserving
    ordinary numeric, object, categorical, and datetime columns.
    """
    out = data.copy()
    for col in out.columns:
        dtype = out[col].dtype

        # pandas StringDtype, e.g. string[python] or string[pyarrow]
        if isinstance(dtype, pd.StringDtype):
            x = out[col].astype(object)
            out[col] = x.where(pd.notna(x), np.nan)
            continue

        # Nullable BooleanDtype
        if str(dtype) == 'boolean':
            out[col] = out[col].astype('Float64').astype(float)
            continue

        # Nullable integer/float extension dtypes (Int64, Float64, etc.).
        # Standard numpy int64/float64 are left untouched.
        if pd.api.types.is_extension_array_dtype(dtype) and not isinstance(dtype, pd.CategoricalDtype):
            if pd.api.types.is_numeric_dtype(dtype):
                out[col] = pd.to_numeric(out[col], errors='coerce').astype(float)
            else:
                x = out[col].astype(object)
                out[col] = x.where(pd.notna(x), np.nan)

    return out


def fit_cloglog(formula: str, data: pd.DataFrame, cluster_col: str = 'ID', robust: bool = True):
    """Grouped-time proportional-hazards model via complementary log-log GLM."""
    model_data = _patsy_compatible_copy(data)
    model = smf.glm(
        formula=formula,
        data=model_data,
        family=sm.families.Binomial(link=sm.families.links.CLogLog()),
        offset=model_data['log_interval_years'],
    )
    if robust:
        used_index = model.data.row_labels
        groups = model_data.loc[used_index, cluster_col]
        result = model.fit(cov_type='cluster', cov_kwds={'groups': groups})
    else:
        result = model.fit()
    return result


def exponentiated_table(result, model_name: str, outcome: str) -> pd.DataFrame:
    params = result.params
    ci = result.conf_int()
    p = result.pvalues
    out = pd.DataFrame({
        'term': params.index,
        'beta': params.values,
        'HR': np.exp(params.values),
        'CI_low': np.exp(ci.iloc[:, 0].values),
        'CI_high': np.exp(ci.iloc[:, 1].values),
        'p_value': p.values,
    })
    out.insert(0, 'outcome', outcome)
    out.insert(1, 'model', model_name)
    out['n_interval_rows'] = int(result.nobs)
    try:
        used = result.model.data.frame.loc[result.model.data.row_labels]
        out['n_people'] = int(used['ID'].nunique())
        out['n_events'] = int(used['event'].sum())
    except Exception:
        out['n_people'] = np.nan
        out['n_events'] = np.nan
    return out


def lr_test(reduced_result, full_result) -> dict:
    lr = 2 * (full_result.llf - reduced_result.llf)
    df_diff = int(round(full_result.df_model - reduced_result.df_model))
    p = stats.chi2.sf(lr, df_diff) if df_diff > 0 else np.nan
    return {'LR': float(lr), 'df': df_diff, 'p_value': float(p)}


def save_json(obj: dict, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)
