from __future__ import annotations
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(ROOT / "run_pipeline.py"), "--stage", "stage4"], cwd=ROOT, check=True)
