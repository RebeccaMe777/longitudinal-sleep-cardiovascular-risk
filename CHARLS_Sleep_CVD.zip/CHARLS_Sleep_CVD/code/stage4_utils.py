from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import config
from stage3_utils import (
    DEMOGRAPHIC_COVARIATES,
    CORE_CONFOUNDER_COVARIATES,
    EXTENDED_RISK_FACTOR_COVARIATES,
)


STAGE4_ROOT = config.OUTPUT_DIR / '07_stage4'
STAGE4_TABLES = STAGE4_ROOT / '16_final_tables'
STAGE4_FIGURES = STAGE4_ROOT / '17_publication_figures'
STAGE4_QC = STAGE4_ROOT / '18_final_qc'

ADJUSTMENT_SETS = {
    'Model 1: demographic': DEMOGRAPHIC_COVARIATES,
    'Model 2: core confounder': CORE_CONFOUNDER_COVARIATES,
    'Model 3: extended risk factor': EXTENDED_RISK_FACTOR_COVARIATES,
}

# Recommended inferential hierarchy for the manuscript.
# Model 2 is the principal etiologic association model because several Model-3
# cardiometabolic variables may plausibly lie on the sleep -> CVD pathway.
PRIMARY_MODEL_LABEL = 'Model 2: core confounder'
CONSERVATIVE_MODEL_LABEL = 'Model 3: extended risk factor'

OUTCOME_LABELS = {
    'cvd': 'Overall CVD',
    'heart': 'Heart disease',
    'stroke': 'Stroke',
}


def ensure_stage4_dirs():
    for p in [STAGE4_ROOT, STAGE4_TABLES, STAGE4_FIGURES, STAGE4_QC]:
        p.mkdir(parents=True, exist_ok=True)


def format_hr_ci(hr, lo, hi, digits=2):
    if any(pd.isna(x) for x in [hr, lo, hi]):
        return ''
    return f'{hr:.{digits}f} ({lo:.{digits}f}-{hi:.{digits}f})'


def format_p(p):
    if pd.isna(p):
        return ''
    if p < 0.001:
        return '<0.001'
    return f'{p:.3f}'


def event_rate_table(d: pd.DataFrame, exposure: str, outcome: str) -> pd.DataFrame:
    y = f'incident_{outcome}'
    x = d[[exposure, y]].dropna().copy()
    out = (
        x.groupby(exposure, observed=False)[y]
        .agg(n='count', events='sum', event_fraction='mean')
        .reset_index()
    )
    out['event_percent'] = out['event_fraction'] * 100
    out.insert(0, 'outcome', outcome)
    return out


def forest_plot(
    df: pd.DataFrame,
    label_col: str,
    out_path: Path,
    title: str,
    hr_col: str = 'HR',
    lo_col: str = 'CI_low',
    hi_col: str = 'CI_high',
    ref_line: float = 1.0,
    xlabel: str = 'Hazard ratio (95% CI)',
    log_scale: bool = True,
):
    plot_df = df.dropna(subset=[hr_col, lo_col, hi_col]).copy().reset_index(drop=True)
    if plot_df.empty:
        return
    y = np.arange(len(plot_df))[::-1]
    fig_h = max(3.6, 0.42 * len(plot_df) + 1.5)
    fig, ax = plt.subplots(figsize=(8.2, fig_h))
    hr = plot_df[hr_col].to_numpy(float)
    lo = plot_df[lo_col].to_numpy(float)
    hi = plot_df[hi_col].to_numpy(float)
    ax.errorbar(hr, y, xerr=[hr - lo, hi - hr], fmt='o', capsize=3)
    ax.axvline(ref_line, linestyle='--', linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels(plot_df[label_col].astype(str).tolist())
    if log_scale:
        ax.set_xscale('log')
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    ax.grid(axis='x', alpha=0.2)
    fig.tight_layout()
    fig.savefig(out_path.with_suffix('.png'), dpi=300, bbox_inches='tight')
    fig.savefig(out_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close(fig)
