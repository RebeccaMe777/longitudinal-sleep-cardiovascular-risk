"""Render the single-panel, six-step conceptual DAG used in the manuscript.

Outputs a publication-ready SVG, PDF, PNG, and an auditable CSV edge list in
this script's folder. The figure deliberately omits a title and caption, so
author can add both separately in Word. No participant data are used.
"""
from pathlib import Path
import svgwrite, cairosvg, networkx as nx, csv
from matplotlib import font_manager
OUT = Path(__file__).resolve().parent; BASE='CHARLS_DAG_SixStep_PreviousStyle_NoTitleCaption'
W,H=2100,1060
S=svgwrite.Drawing(str(OUT/(BASE+'.svg')),profile='full',size=('21in','10.6in'),viewBox=f'0 0 {W} {H}')
S.add(S.rect(insert=(0,0),size=(W,H),fill='#ffffff'))
for name, color in [('causal','#208875'),('common','#687989'),('observe','#7B8B9C'),('select','#C5776D')]:
 m=S.marker(id='arr_'+name,insert=(11,5),size=(12,10),orient='auto',markerUnits='userSpaceOnUse')
 m.add(S.path(d='M0 0 L11 5 L0 10 Z',fill=color));S.defs.add(m)
P={'core':('#EDF4FD','#4376B7'),'ext':('#F3EEFA','#8B67B4'),'sleep':('#EAF8F3','#23836A'),'out':('#EAF3F8','#3687A6'),'measure':('#F0F3F7','#6E7F91'),'selection':('#FFF0EE','#CA756B')}
N={
'C':(60,120,363,122,'core','Demographic and social factors',['Age (2015 landmark); sex; education,','marital status; rural/urban residence','[Model 2]']),
'B':(60,290,363,110,'core','Behaviors and depressive symptoms',['2011 smoking, alcohol, CESD-9','[Model 2]']),
'H':(60,449,363,145,'ext','Baseline health / cardiometabolic',['2011 BMI, hypertension, diabetes,','dyslipidemia, self-rated health,','ADL / IADL limitations  [Model 3]']),
'X11':(535,276,210,103,'sleep','Sleep health 2011',['Exposure wave 1']),
'X13':(815,276,210,103,'sleep','Sleep health 2013',['Exposure wave 2']),
'X15':(1095,276,210,103,'sleep','Sleep health 2015',['Exposure wave 3']),
'Y':(1740,276,306,103,'out','Incident CVD',['Heart disease or stroke','reported in 2018 or 2020']),
'O11':(535,575,210,86,'measure','Sleep measure 2011',['3 components; 0–3 score']),
'O13':(815,575,210,86,'measure','Sleep measure 2013',['3 components; 0–3 score']),
'O15':(1095,575,210,86,'measure','Sleep measure 2015',['3 components; 0–3 score']),
'SCORE':(1400,575,232,100,'measure','Cumulative MDSH',['2011 + 2013 + 2015','Observed total: 0–9 points']),
'D':(635,804,275,90,'selection','2015 disease-free landmark',['No reported prior heart disease','or stroke by 2015']),
'K':(978,804,265,90,'selection','Complete MDSH data',['All three exposure waves']),
'F':(1320,804,270,90,'selection','Follow-up available',['2018 or 2020']),
'S':(1055,952,300,79,'selection','Analytic cohort (S = 1)',['Conditioned on D, K and F'])}
# DAG edges and their drawing routes
edges=[]
def E(a,b,typ,d,stage):edges.append((a,b,typ,d,stage))
def p(k,side,ratio=.5):
 x,y,w,h=N[k][:4]
 return {'right':(x+w,y+h*ratio),'left':(x,y+h*ratio),'top':(x+w*ratio,y),'bottom':(x+w*ratio,y+h)}[side]
def xy(v):return '%0.1f,%0.1f'%v
def straight(a,b,as_,bs_,ratio1=.5,ratio2=.5):return 'M '+xy(p(a,as_,ratio1))+' L '+xy(p(b,bs_,ratio2))
def cubic(a,b,sa,sb,cp1,cp2,ra=.5,rb=.5):return 'M '+xy(p(a,sa,ra))+' C '+xy(cp1)+' '+xy(cp2)+' '+xy(p(b,sb,rb))
# Step 1 longitudinal sleep and outcome. Multiple exposure waves can affect later CVD, do not assume only last wave matters.
E('X11','X13','causal',straight('X11','X13','right','left'),1)
E('X13','X15','causal',straight('X13','X15','right','left'),1)
E('X15','Y','causal',straight('X15','Y','right','left',.5,.55),1)
E('X11','Y','causal',cubic('X11','Y','top','top',(900,108),(1728,112),.76,.23),1)
E('X13','Y','causal',cubic('X13','Y','top','top',(1150,177),(1830,186),.7,.45),1)
# Step 2 exposure determinants
E('C','X11','common',cubic('C','X11','right','left',(475,165),(475,298),.60,.25),2)
E('B','X11','common',straight('B','X11','right','left',.35,.52),2)
E('H','X11','common',cubic('H','X11','right','left',(470,465),(510,390),.17,.86),2)
# Step 3 outcome determinants
E('C','Y','common',cubic('C','Y','top','top',(590,42),(1900,47),.90,.78),3)
E('B','Y','common',cubic('B','Y','right','left',(690,450),(1580,430),.81,.79),3)
E('H','Y','common',cubic('H','Y','right','bottom',(850,485),(1800,492),.54,.4),3)
# Step 4 pairwise observed causes
E('C','B','common',straight('C','B','bottom','top',.35,.35),4)
E('C','H','common',cubic('C','H','left','left',(18,228),(17,492),.43,.33),4)
E('B','H','common',straight('B','H','bottom','top',.70,.70),4)
# Step 5 measurement: causal direction of reporting is sleep health -> measured scores
for a,b in [('X11','O11'),('X13','O13'),('X15','O15')]:E(a,b,'observe',straight(a,b,'bottom','top'),5)
E('O11','SCORE','observe',cubic('O11','SCORE','bottom','bottom',(710,733),(1462,729),.65,.2),5)
E('O13','SCORE','observe',cubic('O13','SCORE','bottom','bottom',(970,713),(1460,717),.55,.45),5)
E('O15','SCORE','observe',straight('O15','SCORE','right','left'),5)
# Step 6 selection. Do not draw landmark as cause of 2015 sleep.
E('H','D','select',cubic('H','D','bottom','left',(438,766),(595,812),.82,.42),6)
E('X11','D','select',cubic('X11','D','bottom','top',(612,670),(757,739),.2,.35),6)
E('X13','D','select',cubic('X13','D','bottom','top',(946,684),(830,764),.6,.78),6)
E('H','K','select',cubic('H','K','bottom','left',(530,763),(879,781),.95,.73),6)
E('X15','K','select',cubic('X15','K','bottom','top',(1265,678),(1115,738),.45,.65),6)
E('C','F','select',cubic('C','F','right','top',(497,725),(1390,740),.87,.38),6)
E('Y','F','select',cubic('Y','F','bottom','right',(2110,518),(1745,846),.84,.45),6)
for a,b,r in [('D','S',.11),('K','S',.50),('F','S',.91)]:E(a,b,'select',cubic(a,b,'bottom','top',(p(a,'bottom')[0],930),(p(b,'top',r)[0],930),.5,r),6)
DG=nx.DiGraph();DG.add_nodes_from(N);DG.add_edges_from((a,b) for a,b,*_ in edges)
assert nx.is_directed_acyclic_graph(DG)
# Functional section labels, NOT a figure title or caption
for x,y,s,color in [(62,95,'BASELINE DETERMINANTS','#8291A0'),(535,255,'LONGITUDINAL SLEEP EXPOSURE','#8291A0'),(535,549,'SURVEY-BASED SLEEP MEASURES','#8291A0'),(636,778,'LANDMARK & ANALYTIC SELECTION','#BE8C83'),(1740,255,'CARDIOVASCULAR OUTCOME','#8291A0')]:
 S.add(S.text(s,insert=(x,y),font_family='DejaVu Sans',font_size=16,font_weight=700,fill=color,letter_spacing='1.5'))
style={'causal':('#208875',3.7,None,.89),'common':('#687989',2.3,None,.58),'observe':('#7B8B9C',2.35,'6 7',.80),'select':('#C5776D',2.2,'4 8',.74)}
for a,b,t,d,st in edges:
 c,width,dash,opa=style[t]
 elt=S.path(d=d,fill='none',stroke=c,stroke_width=width,stroke_linecap='round',stroke_linejoin='round',opacity=opa)
 elt['marker-end']='url(#arr_'+t+')'
 if dash:elt['stroke-dasharray']=dash
 S.add(elt)
from PIL import ImageFont
BOLD = font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans', weight='bold'))
REG = font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans'))
def fitted(text, maximum, available, fontpath):
 size=maximum
 while size>12 and ImageFont.truetype(fontpath,int(size)).getlength(text)>available:
  size-=0.4
 return round(size,1)
for key,(x,y,w,h,group,title,subs) in N.items():
 fill,stroke=P[group]
 S.add(S.rect(insert=(x,y),size=(w,h),rx=15,ry=15,fill=fill,stroke=stroke,stroke_width=2.4))
 f=fitted(title,20.7,w-24,BOLD)
 S.add(S.text(title,insert=(x+w/2,y+33),font_family='DejaVu Sans',font_size=f,font_weight=700,text_anchor='middle',fill='#20394A'))
 for i,line in enumerate(subs):
  sf=fitted(line,17.0,w-14,REG)
  S.add(S.text(line,insert=(x+w/2,y+62+i*22),font_family='DejaVu Sans',font_size=sf,text_anchor='middle',fill='#526477'))
S.save()
cairosvg.svg2pdf(url=str(OUT/(BASE+'.svg')),write_to=str(OUT/(BASE+'.pdf')))
cairosvg.svg2png(url=str(OUT/(BASE+'.svg')),write_to=str(OUT/(BASE+'.png')),output_width=2520,output_height=1272)
with (OUT/(BASE+'_edges.csv')).open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['From','To','Six-step stage','Type']);w.writerows((a,b,stage,typ) for a,b,typ,route,stage in edges)
print('Nodes',len(N),'Edges',len(edges),'DAG',nx.is_directed_acyclic_graph(DG))
for suffix in ['.svg','.pdf','.png','_edges.csv']:print(str(OUT/(BASE+suffix)))
