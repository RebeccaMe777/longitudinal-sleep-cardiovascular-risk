# Final conceptual DAG for the CHARLS MDSH–CVD paper

The **approved publication figure** is `CHARLS_DAG_SixStep_PreviousStyle_NoTitleCaption.pdf` (vector), with matching `.svg` (editable vector) and `.png` (preview) files. **No heading or caption is embedded**; insert them in Word separately. The illustration retains the six-step construction layout but excludes unmeasured-variable nodes as requested.

## Rebuild from source

From the project root, after installing the optional plotting dependencies:

```powershell
python -m pip install -r requirements-dag.txt
python .\figures\dag\build_final_publication_dag.py
```

The script writes the PDF, SVG, PNG and `_edges.csv` into this folder. It uses matplotlib's bundled DejaVu Sans fonts, so it is portable to Windows as well as Linux. An operating-system Graphviz installation is **not required** to regenerate this final figure.

The directed edges are hypotheses, not empirical proof of a sufficient adjustment set. Baseline health status variables measured in 2011 may confound the association between repeated sleep health and later CVD, and must not automatically be treated as downstream mediators. Model 2 is the primary *association* model and Model 3 a complementary extended adjustment. Selection and measurement nodes reflect the six-step conceptual process, not fitted regression covariates.

## Figure caption (copy to Word; not included in the artwork)

**Conceptual directed acyclic graph of multidimensional sleep health and subsequent cardiovascular disease among middle-aged and older adults in China, 2011–2020.** Hypothesized pathways link baseline characteristics to three sleep-health assessments, survey-based sleep measurements and the cumulative multidimensional sleep-health score, incident heart disease or stroke reported in 2018 or 2020, and the 2015 disease-free landmark and analytic-selection process. The core covariates used in Model 2 and the additional 2011 health-status and cardiometabolic variables used in Model 3 are shown separately. The diagram represents causal assumptions rather than a validated minimally sufficient adjustment set.

## Six-step construction documents

The `six_step_construction_archive/` subfolder retains the original intermediate source and development notes for transparency. The final PDF above is the only recommended image for manuscript submission.
