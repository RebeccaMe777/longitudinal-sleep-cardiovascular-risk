from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from PIL import Image
p=Path(__file__).resolve().parent
fig,ax=plt.subplots(figsize=(19.2,5.1))
fig.patch.set_facecolor('white');ax.set_xlim(0,19.2);ax.set_ylim(0,5.1);ax.axis('off')
ax.text(.5,4.75,'B  |  Measurement and analytic selection',fontsize=19,weight='bold',color='#1c3144')
ax.text(.52,4.33,'Auxiliary processes considered in iterative steps 5 and 6; S = 1 denotes conditioning on eligibility and observed records',fontsize=11.6,color='#5b6673')
N={
 'X':(2.15,3.13,3.1,.90,'#E9F6F0','#28806C','UNDERLYING SLEEP\n2011 / 2013 / 2015'),
 'XO':(5.85,3.13,3.1,.90,'#F2F4F6','#677587','SELF-REPORTED SLEEP\nthree survey waves'),
 'Score':(9.45,3.13,3.15,.90,'#F2F4F6','#677587','OBSERVED MDSH SCORE\n0–9; derived, not causal'),
 'Y':(2.15,1.35,3.1,.90,'#E9F1FC','#2773AC','TRUE CVD\nafter 2015 landmark'),
 'YO':(5.85,1.35,3.1,.90,'#F2F4F6','#677587','REPORTED CVD\n2018 / 2020'),
 'A':(9.45,1.35,3.15,.90,'#FFF5E9','#BE8743','CARE ACCESS / REPORTING\npropensity (unmeasured)'),
 'D':(13.3,3.5,2.55,.85,'#FFF0EE','#C15E55','CVD-FREE\nreported in 2015'),
 'F':(13.3,2.14,2.55,.85,'#FFF0EE','#C15E55','FOLLOW-UP AVAILABLE\n2018 and / or 2020'),
 'K':(13.3,.78,2.55,.85,'#FFF0EE','#C15E55','COMPLETE SLEEP\nassessment data'),
 'S':(17.0,2.14,2.65,1.2,'#FFF0EE','#C15E55','ANALYTIC SAMPLE\nS = 1 (conditioned)'),
}
for n,(x,y,w,h,fc,ec,txt) in N.items():
 ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=.05,rounding_size=.12',edgecolor=ec,linewidth=1.4,facecolor=fc,zorder=4))
 for i,line in enumerate(txt.split('\n')):
  ax.text(x,y+.13-i*.27,line,ha='center',va='center',fontsize=10 if i==0 else 9.7,fontweight='bold' if i==0 else 'regular',color='#243447',zorder=5)
def point(n,side):
 x,y,w,h,*_=N[n]
 return {'right':(x+w/2,y),'left':(x-w/2,y),'top':(x,y+h/2),'bottom':(x,y-h/2)}[side]
def a(u,v,s1='right',s2='left',rad=0,color='#617080',ls='solid'):
 ax.add_patch(FancyArrowPatch(point(u,s1),point(v,s2),connectionstyle=f'arc3,rad={rad}',arrowstyle='-|>',mutation_scale=12,linewidth=1.55,color=color,linestyle=ls,zorder=2,shrinkA=4,shrinkB=4))
a('X','XO');a('XO','Score');a('Y','YO');a('A','YO','left','right',color='#BB7B37',ls='dashed')
a('D','S','right','top',rad=-.1,color='#C15E55')
a('F','S','right','left',color='#C15E55')
a('K','S','right','bottom',rad=.1,color='#C15E55')
# score and missingness are distinct components; curved arrows encode reporting influence on completeness
a('XO','K','bottom','left',rad=-.36,color='#647588',ls='dotted')
a('A','D','top','left',rad=-.17,color='#BB7B37',ls='dashed')
ax.text(.6,.18,'These are assumed pathways, not directly estimable from the observed CHARLS data. S depends on disease-free eligibility, follow-up and exposure completeness.',fontsize=10.4,color='#5b6673')
fig.savefig(p/'CHARLS_DAG_measurement_selection_panel.png',dpi=190,bbox_inches='tight',facecolor='white')
fig.savefig(p/'CHARLS_DAG_measurement_selection_panel.svg',bbox_inches='tight',facecolor='white')
# combine 2 panels into one print-ready image while retaining both panel svg files separately
f1=Image.open(p/'CHARLS_DAG_primary_causal_panel.png').convert('RGB')
f2=Image.open(p/'CHARLS_DAG_measurement_selection_panel.png').convert('RGB')
W=max(f1.width,f2.width)
from PIL import ImageOps,ImageDraw
canvas=Image.new('RGB',(W,f1.height+f2.height+80),'white')
canvas.paste(f1,((W-f1.width)//2,0))
canvas.paste(f2,((W-f2.width)//2,f1.height+80))
canvas.save(p/'CHARLS_DAG_six_step_two_panel.png',optimize=True)
print('wrote',f1.size,f2.size,canvas.size)
