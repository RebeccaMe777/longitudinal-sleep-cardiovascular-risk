# Six-step iterative DAG construction: CHARLS sleep health and cardiovascular disease

## Target question
Among Chinese adults without reported physician-diagnosed cardiovascular disease by the 2015 landmark, how are repeated sleep-health assessments in 2011, 2013, and 2015 associated with newly reported cardiovascular disease in 2018 or 2020? This is an **observational association question**. The DAG illustrates causal possibilities; it does not by itself identify a causal intervention effect.

## Step 1. Core causal process
- Early underlying sleep health (2011 and 2013) → sleep health in 2015 → post-2015 biological pathways → true cardiovascular events later reported in 2018 or 2020.
- Allow alternative paths that are not mediated through the particular hypothesized biological process. **Do not assume complete mediation.**
- Split sleep into 2011/2013 versus 2015 to preserve the direction of causal time.

## Step 2. Exposure-assignment process
Sleep is not randomized. Plausible determinants of the sleep exposure include:
- Model 2 factors: age calculated at the 2015 landmark, sex, 2011 education, marital status, residence, smoking, alcohol use, and CESD-9.
- Model 3 factors: BMI, hypertension, diabetes, dyslipidemia, self-rated health, and limitations in activities and instrumental activities of daily living, as measured at the 2011 baseline.
- Other unobserved antecedent factors (pre-2011 sleep/health history, predisposition).
In the DAG, 2011 baseline health can cause both later sleep and CVD. That is a plausible **confounding** scenario, not evidence of post-exposure mediation.

## Step 3. Outcome-generating process
Besides sleep, baseline socioeconomic factors, behaviors, depressive symptoms, pre-existing health status, and unmeasured causes may affect CVD risk. Later physiological changes may also form pathways between sleep and CVD.

## Step 4. Pairwise interrelations and shared causes
- Socio-demographic factors can affect behavior, mental health, and baseline health.
- Prior unmeasured causes can contribute both to poor sleep and cardiovascular risk.
- **2015 subclinical health** may be influenced by 2011/2013 sleep and earlier disease burden, while also affecting sleep reported in 2015 and later CVD. The time split prevents a false contemporaneous cycle.
- Plausible uncertain arrows must be examined and documented; do not indiscriminately connect every node. Alternative plausible directions can be sensitivity assumptions.

## Step 5. Distinguish measured from underlying states
- Underlying sleep health → self-reported night sleep, naps and restless sleep → computed cumulative MDSH (0–9); the computed score is a *summary proxy*, not an intervenable cause on its own.
- True cardiovascular disease and diagnostic access/reporting propensity → self-reported physician-diagnosed disease at the follow-up waves.
- Potential reporting and ascertainment errors remain limitations.

## Step 6. Iterate: selection, missingness and additional pathways
- The analytic sample is selected on no **reported** CVD by 2015, adequate exposure data, and at least one 2018/2020 follow-up.
- These selection criteria may depend on underlying health, sleep, demographics, diagnosis access, and events. Conditioning on sample inclusion could introduce selection bias.
- Recheck newly added factors for common causes and valid chronological orientation. The complete extended source includes 18 nodes and 44 directed arrows, and was checked as acyclic computationally.

## Implications for model hierarchy
1. Model 2 is a suitable **primary association model**, as in the current manuscript; this is not equivalent to a demonstrated causal adjustment set, with adjustment for core social, behavioral and depression-related factors. It must **not** be described as causally sufficient merely because a DAG was drawn.
2. When the graph contains baseline health → sleep AND baseline health → CVD, Model 2 leaves some plausible measured backdoor paths open. This is precisely why Model 3 is informative as an extended baseline confounding-adjustment model.
3. Because these additional health measures were taken in 2011, they are not proven downstream mediators of an exposure measured from 2011 to 2015. They may partly reflect consequences of sleep health before 2011, and the interpretation depends on the causal estimand.
4. Neither model formally identifies a total causal effect in the presence of residual unmeasured, selection, time-varying and measurement biases. Avoid mediation claims and causal certainty.

## Draft Supplementary Figure title and legend
**Supplementary Figure Sx. Conceptual directed acyclic graphs for repeated multidimensional sleep health and cardiovascular disease among middle-aged and older adults in China, 2011–2020.** Panel A summarizes hypothesized causal pathways, explicitly distinguishing sleep assessments in 2011/2013 from the 2015 assessment, core Model 2 covariates, additional 2011 baseline health factors in Model 3, and potential unmeasured subclinical disease. Panel B illustrates measurement and analytic selection, including self-reported sleep and physician-diagnosed CVD, the 2015 disease-free landmark, complete sleep assessment and follow-up availability. Directed arrows reflect conceptual assumptions rather than verified causal relations. Baseline 2011 health factors are not automatically mediators of the 2011–2015 exposure; the diagram does not prove that either regression model is a sufficient causal adjustment set.

## Draft Methods insertion
To clarify our covariate adjustment strategy, we developed a conceptual directed acyclic graph using an iterative approach that considered the hypothesized causal pathways, determinants of sleep health, determinants of cardiovascular outcomes, interrelationships among baseline characteristics, and measurement and selection mechanisms (Supplementary Figure Sx). Model 2 was retained as the primary association model adjusted for demographic, socioeconomic, behavioral, and depressive-symptom factors. Model 3 additionally adjusted for baseline health status, functional limitations, and cardiometabolic risk factors. Because the latter were measured in 2011, they cannot be assumed to be established mediators of sleep exposure assessed in 2011–2015; some may also act as baseline confounders. We therefore interpret the two models as complementary adjustment specifications and avoid causal mediation claims.

## Draft Reviewer 2 response
We thank the reviewer for highlighting the need for a more explicit causal rationale for covariate selection. We have constructed a conceptual directed acyclic graph using an iterative approach that considers the exposure-generating process, the cardiovascular outcome-generating process, potential common causes, and the observed measurement and sample selection mechanisms (Supplementary Figure Sx). The graph separates the core demographic, socioeconomic, behavioral, and depressive-symptom factors in Model 2 from the additional 2011 baseline health-status and cardiometabolic factors in Model 3. Importantly, the latter were measured at or before the beginning of the longitudinal exposure window and therefore should not be assumed to be mediators that arose after exposure. Conversely, we recognize that some of these variables could confound the sleep–cardiovascular association, and that the DAG does not establish Model 2 as a minimally sufficient causal adjustment set. We now identify Model 2 as the primary association model and interpret Model 3 as a complementary extended-adjustment analysis. We have revised the Methods and Discussion to clarify this distinction and to avoid causal or mediation interpretations that the observational data cannot support.
