from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import matplotlib as mpl
p=Path(__file__).resolve().parent
mpl.rcParams['font.family']='DejaVu Sans'
fig,ax=plt.subplots(figsize=(19.2,10.1))
fig.patch.set_facecolor('white');ax.set_xlim(0,19.2);ax.set_ylim(0,10.1);ax.axis('off')
ax.text(0.5,9.65,'A  |  Hypothesized causal process',fontsize=19,weight='bold',color='#1c3144')
ax.text(0.52,9.22,'Longitudinal multidimensional sleep health and subsequent cardiovascular disease • China, 2011–2020',fontsize=11.7,color='#5b6673')

N={
'C':(2.45,7.35,3.82,1.25, '#EAF2FC','#3775B5','CORE COVARIATES  •  MODEL 2\nAge, sex, marital status, education,\nresidence, smoking, alcohol, CESD-9'),
'H':(2.45,5.05,3.82,1.25,'#F4EDFA','#8262A7','BASELINE HEALTH  •  MODEL 3\nBMI, hypertension, diabetes, dyslipidemia,\nself-rated health, ADL / IADL'),
'U':(2.45,2.67,3.82,1.25,'#FFF5E9','#BE8743','UNMEASURED PRE-2011 CAUSES\nPredisposition and past sleep/health history'),
'E':(7.35,6.55,2.35,1.12,'#E9F6F0','#28806C','SLEEP HEALTH\n2011 and 2013'),
'Q':(10.7,8.2,2.55,1.12,'#FFF5E9','#BE8743','SUBCLINICAL HEALTH\nby 2015'),
'L':(10.7,5.45,2.55,1.12,'#E9F6F0','#28806C','SLEEP HEALTH\n2015'),
'M':(14.15,6.55,2.6,1.12,'#FFF5E9','#BE8743','POST-2015 PATHWAYS\nhypothesized'),
'Y':(17.35,6.55,2.75,1.25,'#E9F1FC','#2773AC','INCIDENT CVD\n2018 and / or 2020'),
}
# x,y are center; width/height, not left bottom
for n,(x,y,w,h,fill,edge,label) in N.items():
 ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.055,rounding_size=0.13',linewidth=1.55,facecolor=fill,edgecolor=edge,zorder=4))
 part=label.split('\n')
 top=y+(len(part)-1)*0.17
 for i,line in enumerate(part):
  ax.text(x, top-i*0.29,line,ha='center',va='center',fontsize=9.2 if i else 10.8,fontweight='bold' if i==0 else 'regular',color='#223448',zorder=5)

def bd(node,side='right'):
 x,y,w,h,*_=N[node]
 return {'right':(x+w/2,y),'left':(x-w/2,y),'top':(x,y+h/2),'bottom':(x,y-h/2)}[side]
def arrow_pts(u,v,side_u='right',side_v='left',rad=0,color='#4A5B6E',lw=1.65,ls='solid'):
 ax.add_patch(FancyArrowPatch(bd(u,side_u),bd(v,side_v),arrowstyle='-|>',mutation_scale=13,color=color,linewidth=lw,linestyle=ls,connectionstyle=f'arc3,rad={rad}',zorder=2,shrinkA=4,shrinkB=5))
def route(points, color='#4A5B6E',lw=1.55,ls='solid'):
 for a,b in zip(points[:-2],points[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],color=color,linestyle=ls,linewidth=lw,zorder=1)
 a,b=points[-2:]
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,color=color,linewidth=lw,linestyle=ls,zorder=2))

# Long shared causes on outer perimeter, explicitly end at Y
route([bd('C','top'),(2.5,8.85),(16.5,8.85),bd('Y','top')],color='#3A78B2',lw=1.5)
route([bd('H','bottom'),(2.5,4.04),(16.9,4.04),bd('Y','bottom')],color='#8061A5',lw=1.55)
# unmeasured prebaseline path to outcome uses low outer lane, visible uncertainty
route([bd('U','bottom'),(2.4,1.55),(18.55,1.55),(18.55,5.6),bd('Y','right')],color='#BE8743',lw=1.4,ls='dashed')

arrow_pts('C','E','right','top',rad=0.05,color='#3A78B2')
arrow_pts('H','E','right','bottom',rad=-0.14,color='#8061A5')
arrow_pts('U','H','top','bottom',rad=-0.06,color='#BE8743',ls='dashed')
arrow_pts('U','E','right','left',rad=-0.14,color='#BE8743',ls='dashed')
arrow_pts('E','Q','top','left',rad=0.12,color='#BE8743')
arrow_pts('E','L','right','left',rad=0.1,color='#2D806B')
arrow_pts('Q','L','bottom','top',rad=-0.0,color='#BE8743',ls='dashed')
# subclinical health to outcome, high curved arc avoiding M box
arrow_pts('Q','Y','right','top',rad=-0.30,color='#BE8743',ls='dashed')
arrow_pts('L','M','right','bottom',rad=-0.06,color='#2D806B')
arrow_pts('M','Y','right','left',rad=0,color='#2D806B',lw=1.85)
# Alternative paths beyond M
arrow_pts('L','Y','right','bottom',rad=0.28,color='#2D806B',lw=1.4)

# bar at bottom summarizing full six-step audit extensions
ax.plot([.5,18.72],[.5,.5],color='#E4EAF0',lw=1.25)
ax.text(.55,.18,'Conceptual DAG • Arrows denote causal hypotheses  |  Dashed lines indicate unmeasured pathways  |  Post-2015 mechanisms were not observed.',fontsize=10.8,color='#4b5d6e')
fig.savefig(p/'CHARLS_DAG_primary_causal_panel.png',dpi=190,bbox_inches='tight',facecolor='white')
fig.savefig(p/'CHARLS_DAG_primary_causal_panel.svg',bbox_inches='tight',facecolor='white')
print('files',[(f,(p/f).stat().st_size) for f in ['CHARLS_DAG_primary_causal_panel.png','CHARLS_DAG_primary_causal_panel.svg']])
