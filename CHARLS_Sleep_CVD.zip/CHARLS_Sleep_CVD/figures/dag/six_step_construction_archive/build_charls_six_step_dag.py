from graphviz import Digraph
import networkx as nx
from pathlib import Path
import json, zipfile

out=Path(__file__).resolve().parent
colors={
'causal':('#E8F5EE','#237A61'),
'core':('#EAF2FC','#2869A2'),
'extended':('#F7F0FE','#8662A6'),
'latent':('#FFF5E7','#BA7C31'),
'selection':('#FFF0EE','#C15E55'),
'measurement':('#F2F4F6','#677587'),
'outcome':('#E8F4F8','#207C9E'),
}
nodes={
 'Z': ('Baseline social and demographic factors\\nAge, sex, education, marital status, residence\\n(Model 2)', 'core'),
 'B': ('2011 behavior and depressive symptoms\\nSmoking, alcohol, CESD-9 (Model 2)', 'core'),
 'H': ('2011 baseline health and cardiometabolic factors\\nBMI; hypertension; diabetes; dyslipidemia;\\nself-rated health; ADL / IADL (Model 3)', 'extended'),
 'U': ('Prior unmeasured causes\\n(e.g., predisposition, pre-2011 sleep history)', 'latent'),
 'E': ('Underlying sleep health\\n2011 and 2013', 'causal'),
 'Q': ('Subclinical / early health changes\\nby 2015 (unmeasured)', 'latent'),
 'L': ('Underlying sleep health\\n2015', 'causal'),
 'M': ('Biological pathways after 2015\\n(hypothesized; not measured)', 'latent'),
 'Y': ('True incident cardiovascular disease\\n2015-2020', 'outcome'),
 'A': ('Care access / diagnosis propensity\\n(unmeasured)', 'latent'),
 'D': ('Reported CVD by 2015\\nlandmark exclusion', 'selection'),
 'F': ('2018 / 2020 follow-up\\navailability', 'selection'),
 'K': ('Complete repeated sleep\\nassessments', 'selection'),
 'S': ('Analytic inclusion\\nS = 1 (conditioned on)', 'selection'),
 'Eo': ('Reported sleep measures\\n2011 and 2013', 'measurement'),
 'Lo': ('Reported sleep measures\\n2015', 'measurement'),
 'Score': ('Observed cumulative MDSH\\n0-9 points; derived variable', 'measurement'),
 'Yo': ('Reported physician-diagnosed CVD\\n2018 and / or 2020', 'measurement'),
}
# stages 1-6, arrows are hypothesized, not empirical claims
edges=[
 # step1 causal process
 ('E','L',1), ('E','M',1), ('L','M',1),('M','Y',1),('E','Y',1),('L','Y',1),
 # step2 exposure assignment / selection causes
 ('Z','E',2), ('B','E',2), ('H','E',2),('U','E',2),
 # step3 outcome production
 ('Z','Y',3), ('B','Y',3),('H','Y',3),('U','Y',3),
 # step4 pairwise direct and common cause
 ('Z','B',4),('Z','H',4),('B','H',4),('U','H',4),
 ('E','Q',4),('H','Q',4),('U','Q',4),('Q','L',4),('Q','Y',4),
 # step5 measurement: true processes -> observed proxies
 ('E','Eo',5),('L','Lo',5),('Eo','Score',5),('Lo','Score',5),
 ('Y','Yo',5),('A','Yo',5),('Q','D',5),('A','D',5),
 # step6 selection & further interrelations (final iterative scan)
 ('E','D',6),('H','D',6),('Z','A',6),('A','F',6),('Z','F',6),('H','F',6),
 ('Y','F',6),('Z','K',6),('H','K',6),('L','K',6),
 ('D','S',6),('F','S',6),('K','S',6)
]
assert len(edges)==len(set((u,v) for u,v,_ in edges))
g=nx.DiGraph(); g.add_nodes_from(nodes); g.add_edges_from((u,v) for u,v,_ in edges)
assert nx.is_directed_acyclic_graph(g), list(nx.simple_cycles(g))

# schematic stage diagrams: cumulative, meaningful local node context
stage_files=[]
for st in range(1,7):
    dot=Digraph('CHARLS_SixStep_DAG', engine='dot', format='svg')
    dot.attr(rankdir='LR', bgcolor='white', pad='0.28', nodesep='0.35',ranksep='0.75', splines='spline', dpi='150', outputorder='edgesfirst')
    dot.attr('node', shape='box', style='rounded,filled', fontname='DejaVu Sans', fontsize='10.8', margin='0.14,0.10', penwidth='1.3')
    dot.attr('edge', color='#677587', arrowsize='.68', penwidth='1.23')
    present=set()
    for u,v,k in edges:
        if k<=st:present.update([u,v])
    # keep first-stage minimal, later add as edges become available
    for n in nodes:
        if n not in present: continue
        label,t=nodes[n]
        bg,border=colors[t]
        dot.node(n, label=label.replace('\\n','\n'),fillcolor=bg,color=border)
    for u,v,k in edges:
        if k>st:continue
        col= '#D56C45' if k==st and st>1 else '#677587'
        style='dashed' if u in ['U','Q','A'] or v in ['U','Q','A'] else 'solid'
        dot.edge(u,v,color=col, style=style, penwidth='1.8' if k==st else '1.05')
    dot.attr(label=f'Step {st} of 6   |   CHARLS longitudinal sleep and cardiovascular disease',labelloc='t',fontname='DejaVu Sans',fontsize='18', fontcolor='#304055')
    path=out/f'CHARLS_DAG_step{st:02d}'
    dot.save(str(path)+'.dot')
    dot.render(filename=path.name,directory=out,cleanup=True,format='svg')
    stage_files+= [str(path)+'.svg']
    if st==6:
        dot.render(filename=path.name,directory=out,cleanup=True,format='png')

# Reviewer-facing simplified conceptual DAG maintains actual time splitting and confounding
p=Digraph('CHARLS_Reviewer_DAG',engine='dot')
p.attr(rankdir='LR', bgcolor='white',pad='0.30',nodesep='0.52',ranksep='1.08',splines='spline',outputorder='edgesfirst',dpi='200')
p.attr('node',shape='box',style='rounded,filled',fontname='DejaVu Sans',fontsize='13',margin='0.17,0.12',penwidth='1.5')
p.attr('edge',color='#637385',arrowsize='.73',penwidth='1.45')
subset=['U','Z','B','H','E','Q','L','M','Y','D','F','S']
labels={
'Z':'Demographic and social factors (2011)\nModel 2: age, sex, education, marital status, residence',
'B':'Behavior and depressive symptoms (2011)\nModel 2: smoking, alcohol, CESD-9',
'H':'Baseline health / cardiometabolic factors (2011)\nModel 3 additions: BMI, hypertension, diabetes, dyslipidemia,\nself-rated health, ADL / IADL',
'U':'Unmeasured pre-2011 causes',
'E':'Sleep health\n2011 and 2013',
'Q':'Subclinical health changes\nby 2015 (unmeasured)',
'L':'Sleep health\n2015',
'M':'Post-2015 physiological\npathways (hypothesized)',
'Y':'Incident cardiovascular disease\n2018 and / or 2020',
'D':'Reported CVD-free status\nat 2015 landmark',
'F':'Follow-up and sleep-data\navailability',
'S':'Analytic selection\nS = 1',
}
for n in subset:
  bg,border=colors[nodes[n][1]]
  p.node(n,labels[n],fillcolor=bg,color=border)
# distinguish conceptual causal paths and selection arrows, limited to avoid clutter
subset_edges=[
('U','H'),('U','E'),('U','Y'),('Z','B'),('Z','H'),('Z','E'),('Z','Y'),
('B','E'),('B','Y'),('H','E'),('H','Q'),('H','Y'),
('E','Q'),('E','L'),('Q','L'),('Q','Y'),('E','M'),('L','M'),('M','Y'),('E','Y'),('L','Y'),
('E','D'),('H','D'),('Q','D'),('D','S'),('Z','F'),('H','F'),('Y','F'),('F','S')]
for u,v in subset_edges:
    style='dashed' if u in ['U','Q'] or v in ['U','Q'] else 'solid'
    col= '#B17B42' if style=='dashed' else '#637385'
    if v in ('D','F','S') or u in ('D','F'):
        col='#C16E62';style='dotted';
    if (u,v) in [('E','Y'),('L','Y'),('M','Y')]:col='#267C67';
    p.edge(u,v,color=col,style=style, constraint='false' if (v in ('D','F','S') or (u,v) in [('U','Y'),('Z','Y'),('B','Y'),('H','Y'),('Q','Y'),('E','Y')]) else 'true')
p.attr(label='Hypothesized causal structure and adjustment strategy  |  China Health and Retirement Longitudinal Study, 2011-2020',labelloc='t',fontname='DejaVu Sans',fontsize='17',fontcolor='#304055')
p.save(str(out/'CHARLS_DAG_reviewer_simplified.dot'))
p.render(filename='CHARLS_DAG_reviewer_simplified',directory=out,format='svg',cleanup=True)
p.render(filename='CHARLS_DAG_reviewer_simplified',directory=out,format='png',cleanup=True)

# machine-readable edges and detailed methodological note
import csv
with (out/'CHARLS_DAG_six_step_edges.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['cause','effect','stage_introduced','cause_label','effect_label'])
 for u,v,k in edges:w.writerow([u,v,k,nodes[u][0].replace('\\n',' / '),nodes[v][0].replace('\\n',' / ')])

note='''# Six-step iterative DAG construction for the CHARLS longitudinal sleep-CVD study

**Status:** A transparent, proposed causal model; edges are substantive hypotheses, not effects established by CHARLS. The graph was verified computationally to be a directed acyclic graph. Individual variables within grouped boxes may have different causal parents; grouping is for legibility, not evidence they share identical causal structure.

## Step 1 – Core causal process
- True sleep health during 2011/2013 (E), 2015 (L), hypothesized post-2015 biological processes (M), true incident CVD (Y).
- E→L represents longitudinal persistence. E→M→Y and L→M→Y allow mediated pathways; E→Y and L→Y allow other pathways. Importantly, *no assumption of complete mediation*.

## Step 2 – Exposure-assignment process (observational, not randomized)
- Z (2011 sociodemographics), B (2011 smoking/alcohol/CESD-9), H (2011 health and cardiometabolic factors) and U (unmeasured pre-2011 causes) may affect sleep health.
- Both Model 2 (Z+B) and Model 3 (H additionally) variables are assessed before or at the initial exposure wave, so baseline H is not automatically a post-2015 mediator.

## Step 3 – Outcome-generating process
- Z, B, H, U and E/L may each affect incident CVD, independent of hypothesized later biological mechanisms.

## Step 4 – Pairwise interrelations and common causes
- Demographic factors can shape behavioral factors and baseline health; pre-2011 unmeasured causes can influence baseline health, observed sleep trajectories, and cardiovascular risk.
- **Critical timing split:** 2011/2013 sleep (E) may affect subclinical health by 2015 (Q), which may influence both 2015 sleep (L) and future CVD (Y). Drawing one unsplit 2011–2015 sleep node with Q→sleep and sleep→Q would incorrectly create a cycle.

## Step 5 – Observed versus latent measurement
- Latent sleep states E/L generate reported sleep measures Eo/Lo; these yield the observed cumulative MDSH score. The constructed score is a *measurement summary*, and is not represented as an intervention causing Y.
- Actual incident CVD (Y) and healthcare access/diagnosis propensity (A) affect observed diagnosis reports (Yo). This distinction acknowledges self-report and diagnosis-related measurement error.

## Step 6 – Iterate; selection and additional plausible edges
- Reported CVD by the 2015 landmark (D), follow-up availability (F), and complete sleep measurements (K) jointly determine analytic inclusion (S=1). Conditioning on selection can introduce collider-related selection bias.
- 2011/2013 sleep can influence 2015 CVD status; baseline health and subclinical disease also influence that status. Disease onset can affect follow-up. These are plausible, not proved, mechanisms.

## Implications for Reviewer 2
1. **Model 2 is a pragmatic primary *association* model** adjusted for core measured determinants. It should not be described as a demonstrably sufficient causal adjustment set.
2. On this DAG, H→E and H→Y are explicit backdoor paths. **If these arrows are considered plausible, Model 2 alone does not block every backdoor path**, so the DAG cannot be used to *prove* Model 2 is a minimally sufficient set. Model 3 addresses additional measured baseline confounding but can still suffer unmeasured confounding and other biases.
3. It is incorrect to label all 2011 H variables mediators of 2011–2015 exposure. Later biological processes M are possible downstream mediators but not measured here.
4. The graph is a conceptual assessment of assumptions. No causal effect or mediation effect is identified by the graph alone; neither model rules out selection bias, reverse causation, measurement error or residual confounding.
5. To argue Model 2 as a **causal total-effect** estimator, additional defended assumptions, alternative DAG(s), or a different target estimand would be needed. A cautious manuscript describes associations and uses Model 3 as an informative extended-adjustment analysis, without claiming its estimate is necessarily overadjusted or unbiased.

## Abbreviations
- MDSH: multidimensional sleep health; CVD: cardiovascular disease; BMI: body mass index; ADL/IADL: (instrumental) activities of daily living; CESD-9: 9-item depression score excluding restless sleep.

## Suggested journal figure legend
**Supplementary Figure Sx. Conceptual directed acyclic graph of repeated sleep health and subsequent cardiovascular disease among middle-aged and older adults in China, 2011–2020.** The graph distinguishes early (2011/2013) and later (2015) sleep health, core baseline determinants (Model 2), additional baseline health and cardiometabolic characteristics (Model 3), potential unmeasured subclinical health changes, and selection at the 2015 disease-free landmark. Solid arrows indicate hypothesized causal relations; dashed arrows highlight unmeasured sources or subclinical health pathways; dotted arrows represent selection mechanisms. The extended six-step version additionally separates true states from observed reports. The graph illustrates assumptions rather than proving causal identification.
'''
(out/'CHARLS_DAG_6step_methodology_and_caption.md').write_text(note,encoding='utf-8')
with zipfile.ZipFile(out/'CHARLS_DAG_6step_source_and_stages.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in ['CHARLS_DAG_reviewer_simplified.dot','CHARLS_DAG_reviewer_simplified.svg','CHARLS_DAG_reviewer_simplified.png', 'CHARLS_DAG_step06.dot','CHARLS_DAG_step06.svg','CHARLS_DAG_step06.png','CHARLS_DAG_six_step_edges.csv','CHARLS_DAG_6step_methodology_and_caption.md'] + [f'CHARLS_DAG_step{s:02d}.svg' for s in range(1,7)]:
    z.write(out/f,f)

print('Nodes',len(nodes),'Edges',len(edges),'is_dag',nx.is_directed_acyclic_graph(g));print('Topological order:',list(nx.topological_sort(g)))
for f in ['CHARLS_DAG_reviewer_simplified.png','CHARLS_DAG_step06.png','CHARLS_DAG_6step_source_and_stages.zip']:
 print(f,(out/f).stat().st_size)
