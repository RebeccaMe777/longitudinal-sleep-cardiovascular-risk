# Frozen statistical analysis specification

## study_population
CHARLS participants aged >=45 years at 2011 with 2011/2013/2015 nighttime sleep data, CVD-free at 2015 landmark, and 2018 or 2020 follow-up

## exposure_window
2011, 2013, 2015

## landmark
2015

## follow_up
2015 to 2018/2020

## primary_outcome
incident self-reported physician-diagnosed CVD = heart disease OR stroke

## secondary_outcomes
incident heart disease; incident stroke

## MDSH_duration_component
healthy if nighttime sleep 6-8 h/night, inclusive

## MDSH_nap_component
healthy if midday nap <=60 min/day

## MDSH_restless_component
healthy if restless-sleep frequency <=2 on harmonized 1-4 scale

## MDSH_wave_score
0-3 low-risk components per wave

## MDSH_cumulative_score
sum of 2011+2013+2015 wave scores; range 0-9; complete all three waves required

## fully_favorable_wave
all 3 MDSH components low risk in that wave

## strict_transition
persistent unfavorable / improved / deteriorated / persistent favorable based on 2011 and 2015 fully-favorable status

## primary_model
grouped-time complementary log-log model with interval-length offset and participant-clustered robust SE

## primary_adjustment
Model 2: core confounder

## conservative_extended_adjustment
Model 3: extended risk factor

## reason_for_adjustment_hierarchy
BMI, hypertension, diabetes and dyslipidemia may partly lie on the sleep-to-CVD pathway; extended model is therefore retained as conservative attenuation/sensitivity analysis rather than the sole etiologic model

## missing_covariates
20 stochastic chained-equation multiple imputations with Rubin pooling as sensitivity analysis

## attrition
stabilized inverse-probability-of-follow-up weighting with 1st/99th percentile truncation

## survey_weighting
baseline survey-weight sensitivity clustered by PSU; no full strata-based complex-survey variance because survey_strata unavailable

## death_competing_risk
Fine-Gray not used because usable death timing is too sparse; known-death exclusion reported as sensitivity analysis

## RCS_role
supplementary; no evidence of nonlinearity in mean nighttime sleep-CVD association

## age_interaction_role
supplementary; no strong evidence of continuous age interaction

## ARV_role
secondary/supplementary long-term sleep instability analysis; no formal interaction evidence with mean sleep

## multiple_testing
primary hypotheses limited to cumulative MDSH and persistence/change; secondary component/outcome analyses interpreted with emphasis on effect sizes and consistency rather than isolated P values

## Analysis counts

- primary_landmark_cohort_n: 8,277
- three_wave_MDSH_complete_n: 7,991
- incident_cvd_n: 1,509
- incident_heart_n: 1,066
- incident_stroke_n: 584
- death_known_flag_n: 237
- death_year_nonmissing_n: 22
- survey_strata_nonmissing_n: 0