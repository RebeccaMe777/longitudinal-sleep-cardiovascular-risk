# Manuscript-facing result summary

This file is generated directly from the frozen Stage-4 models and is intended as a numerical drafting aid.

Primary inferential model: **Model 2: core confounder**.
Conservative extended adjustment: **Model 3: extended risk factor**.

## Model 2: core confounder

### Overall CVD
- Cumulative MDSH per +1 point: HR 0.921 (95% CI 0.894-0.948), P <0.001, N=7,973, events=1,464.
- Per additional fully favorable wave: HR 0.873 (95% CI 0.826-0.922), P <0.001, N=7,973, events=1,464.
- Persistent favorable vs persistent unfavorable: HR 0.691 (95% CI 0.588-0.811), P <0.001, N=8,086, events=1,483.
- Improved vs persistent unfavorable: HR 0.845 (95% CI 0.725-0.985), P 0.032, N=8,086, events=1,483.
- Deteriorated vs persistent unfavorable: HR 0.977 (95% CI 0.855-1.117), P 0.736, N=8,086, events=1,483.
- MDSH change per +1 point (2015-2011): HR 0.886 (95% CI 0.832-0.943), P <0.001, N=8,086, events=1,483.

### Heart disease
- Cumulative MDSH per +1 point: HR 0.919 (95% CI 0.887-0.952), P <0.001, N=7,973, events=1,035.
- Per additional fully favorable wave: HR 0.884 (95% CI 0.828-0.944), P <0.001, N=7,973, events=1,035.
- Persistent favorable vs persistent unfavorable: HR 0.732 (95% CI 0.606-0.884), P 0.001, N=8,086, events=1,051.
- Improved vs persistent unfavorable: HR 0.840 (95% CI 0.700-1.009), P 0.062, N=8,086, events=1,051.
- Deteriorated vs persistent unfavorable: HR 0.948 (95% CI 0.807-1.113), P 0.512, N=8,086, events=1,051.
- MDSH change per +1 point (2015-2011): HR 0.899 (95% CI 0.834-0.968), P 0.005, N=8,086, events=1,051.

### Stroke
- Cumulative MDSH per +1 point: HR 0.918 (95% CI 0.876-0.961), P <0.001, N=7,973, events=565.
- Per additional fully favorable wave: HR 0.856 (95% CI 0.783-0.935), P <0.001, N=7,973, events=565.
- Persistent favorable vs persistent unfavorable: HR 0.642 (95% CI 0.491-0.839), P 0.001, N=8,086, events=570.
- Improved vs persistent unfavorable: HR 0.860 (95% CI 0.672-1.102), P 0.233, N=8,086, events=570.
- Deteriorated vs persistent unfavorable: HR 1.040 (95% CI 0.840-1.287), P 0.718, N=8,086, events=570.
- MDSH change per +1 point (2015-2011): HR 0.853 (95% CI 0.771-0.943), P 0.002, N=8,086, events=570.

## Model 3: extended risk factor

### Overall CVD
- Cumulative MDSH per +1 point: HR 0.934 (95% CI 0.905-0.964), P <0.001, N=6,838, events=1,259.
- Per additional fully favorable wave: HR 0.889 (95% CI 0.838-0.943), P <0.001, N=6,838, events=1,259.
- Persistent favorable vs persistent unfavorable: HR 0.715 (95% CI 0.599-0.853), P <0.001, N=6,933, events=1,277.
- Improved vs persistent unfavorable: HR 0.854 (95% CI 0.724-1.009), P 0.063, N=6,933, events=1,277.
- Deteriorated vs persistent unfavorable: HR 1.000 (95% CI 0.865-1.156), P 0.998, N=6,933, events=1,277.
- MDSH change per +1 point (2015-2011): HR 0.897 (95% CI 0.838-0.960), P 0.002, N=6,933, events=1,277.

### Heart disease
- Cumulative MDSH per +1 point: HR 0.933 (95% CI 0.898-0.969), P <0.001, N=6,838, events=892.
- Per additional fully favorable wave: HR 0.908 (95% CI 0.846-0.974), P 0.007, N=6,838, events=892.
- Persistent favorable vs persistent unfavorable: HR 0.773 (95% CI 0.629-0.950), P 0.014, N=6,933, events=907.
- Improved vs persistent unfavorable: HR 0.854 (95% CI 0.701-1.041), P 0.118, N=6,933, events=907.
- Deteriorated vs persistent unfavorable: HR 0.964 (95% CI 0.811-1.147), P 0.681, N=6,933, events=907.
- MDSH change per +1 point (2015-2011): HR 0.914 (95% CI 0.844-0.990), P 0.028, N=6,933, events=907.

### Stroke
- Cumulative MDSH per +1 point: HR 0.932 (95% CI 0.887-0.979), P 0.005, N=6,838, events=482.
- Per additional fully favorable wave: HR 0.856 (95% CI 0.778-0.942), P 0.001, N=6,838, events=482.
- Persistent favorable vs persistent unfavorable: HR 0.633 (95% CI 0.470-0.851), P 0.002, N=6,933, events=487.
- Improved vs persistent unfavorable: HR 0.850 (95% CI 0.649-1.113), P 0.237, N=6,933, events=487.
- Deteriorated vs persistent unfavorable: HR 1.056 (95% CI 0.840-1.328), P 0.638, N=6,933, events=487.
- MDSH change per +1 point (2015-2011): HR 0.866 (95% CI 0.776-0.966), P 0.010, N=6,933, events=487.
