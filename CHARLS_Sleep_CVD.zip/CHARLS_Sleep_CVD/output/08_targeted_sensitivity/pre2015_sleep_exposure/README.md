# Pre-2015 two-wave sleep sensitivity

Exposure is the sum of wave-specific 2011 and 2013 MDSH (0–6).
2015 sleep data are excluded from this exposure. The 2015 CVD-free landmark and
2018/2020 incident outcomes are unchanged.

`two_wave_available` uses all participants with observed 2011 and 2013 MDSH;
`three_wave_complete` restricts to the original three-wave-complete sleep group
for comparison with the primary three-wave analysis. Each model uses complete
Model 2 covariates and an observed outcome. Sample sizes may therefore differ
slightly between the analytic groups and across outcomes.

Reported effects are HRs per 1 point of a 0–6 two-wave score; these estimates
should not be compared numerically as if their scale and exposure window were
identical to the primary 0–9 three-wave score.

This analysis checks the association using older sleep assessments and does
not eliminate subclinical-disease confounding or prove causation.
