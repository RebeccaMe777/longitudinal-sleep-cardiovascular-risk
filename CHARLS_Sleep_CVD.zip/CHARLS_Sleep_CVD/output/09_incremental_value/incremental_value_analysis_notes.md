# Incremental value analysis

## Purpose
Compare a single 2015 MDSH assessment with repeated 2011, 2013, and 2015 MDSH assessments.

## Models
- Model A: 2015 MDSH score only, plus the prespecified Model 2 core covariates.
- Model B: 2011, 2013, and 2015 MDSH scores entered simultaneously, plus the same covariates.
- Descriptive comparator: cumulative 2011+2013+2015 MDSH score, plus the same covariates.

## Comparability
All models for a given outcome use the same person-period records, restricted to participants with complete MDSH scores at all three exposure waves and complete data for the full Model B formula. This ensures that the nested model comparison is not driven by different analytic samples.

## Primary incremental tests
- Likelihood-ratio test: Model A versus Model B.
- Cluster-robust joint Wald test: coefficients for the 2011 and 2013 MDSH scores jointly equal zero, conditional on the 2015 score.

## Interpretation
These analyses assess incremental association information and model fit. They do not, by themselves, establish improved clinical prediction or causal effects.
