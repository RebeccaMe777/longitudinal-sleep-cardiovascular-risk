# Data are not distributed with this repository

This repository intentionally excludes **all** participant-level CHARLS data.
Obtain the applicable CHARLS survey datasets through the authorized data-access
process and construct the harmonized v0.2 input separately.

Expected local filename (do not commit):
`charls_sleep_cvd_harmonized_v0.2.csv`

Place it in this folder, or set `SLEEP_CVD_DATA_FILE` to an absolute local path.
The input is a previously harmonized, participant-by-wave file, **not** raw CHARLS
questionnaire data. This repository does not reproduce the raw-to-harmonized
pipeline. Results depend on the exact v0.2 harmonization and variable coding.
